load('OptiFile.mat')
options = optimoptions('intlinprog','CutGeneration','advanced','HeuristicsMaxNodes',5000,'MaxTime',180);
[compactSolution, solutionValue, exitFlag] = intlinprog(f, 2 * nSecurities + 1: 4 * nSecurities, A, b, Aeq, beq, lb, ub, options);