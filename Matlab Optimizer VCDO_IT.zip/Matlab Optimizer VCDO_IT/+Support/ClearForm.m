function handles = ClearForm (handles, formName)
    
    % Default values
    handles.defaultDeviation = [0.10, 0.01, 0.020, 0.020, 0.020, 0.020,0.030,3,0.05,0.02,0.02];
    handles.defaultColumnIDs = [3, 4, 5, 6, 7, 9, 10, 15, 22, 23, 24, 25, 26, 27, 30];
    handles.defaultGroupDeviation = [0.05, 0.05];
    handles.defaultNBuckets = 4;
    handles.SolverMaxTime = 120;
    
        %%Intitialize Constraint 

handles.OptiConstraints.NoOfConstraints=0;
handles.OptiConstraints.InputTable=[];
handles.OptiConstraints.groupingTypePopupID=[];
handles.OptiConstraints.groupingTypePopupName=[];
handles.OptiConstraints.groupColumnID =[];
handles.OptiConstraints.groupColumnName =[];
handles.OptiConstraints.parameterColumnID = [];
handles.OptiConstraints.parameterColumnName =[];
handles.OptiConstraints.deviation_string = [];
handles.OptiConstraints.maxDeviation_string =[];
handles.OptiConstraints.nBuckets_string =[];
handles.OptiConstraints.minAllValue =[];
handles.OptiConstraints.maxAllValue =[];
handles.OptiConstraints.OptiSelectAllCons=[];    
handles.ApplyConst=0;
handles.WeightAutoOnOffVar=0;

%%%
    if strcmp(formName, 'All')
        handles = ClearImportPanel(handles);
        handles = ClearFilterPanel(handles);
        handles = ClearOptimizePanel(handles);
        handles = ClearResultsPanel(handles);
    elseif strcmp(formName, 'Filter')
        handles = ClearFilterPanel(handles);
        handles = ClearOptimizePanel(handles);
        handles = ClearResultsPanel(handles);
    elseif strcmp(formName, 'Optimize')
        handles = ClearOptimizePanel(handles);
        handles = ClearResultsPanel(handles);
    elseif strcmp(formName, 'Results')
        handles = ClearResultsPanel(handles);
    end
end

function handles = ClearImportPanel(handles)

    % Tables
    handles.benchmarkRawData = [];
    handles.portfolioRawData = [];
    handles.fileWeights = [];
    handles.currencySpotValues = [];
    handles.currencySpotCurrencies = [];
    handles.yieldValues = [];
    handles.SolverMaxTime = 120;
    set(handles.SolverTime,'String',num2str(120));
    
    % Arrays
    handles.allColumnNames = [];
    
    % Numeric values
    handles.currentPortfolioSize = 0;
    handles.newPortfolioSize = 0;
    
    % GUI tables
    set(handles.importedBenchmarkTable, 'Data', '', 'ColumnName', []);
    set(handles.importedPortfolioTable, 'Data', '', 'ColumnName', []);
    set(handles.weightsTable, 'Data', '', 'ColumnName', []);
    set(handles.savedTable, 'Data', '', 'ColumnName', []);
    
    % GUI Popups
    set(handles.maturityColumnPopup, 'Value', 1, 'String', ' ');
    set(handles.ISINColumnPopup, 'Value', 1, 'String', ' ');
    set(handles.GIM2SymbolColumnPopup, 'Value', 1, 'String', ' ');
    set(handles.tickerColumnPopup, 'Value', 1, 'String', ' ');
    set(handles.yieldColumnPopup, 'Value', 1, 'String', ' ');
    set(handles.durationColumnPopup, 'Value', 1, 'String', ' ');
    set(handles.spreadColumnPopup, 'Value', 1, 'String', ' ');
    set(handles.currencyColumnPopup, 'Value', 1, 'String', ' ');
    set(handles.KRD05ColumnPopup, 'Value', 1, 'String', ' ');
    set(handles.KRD2ColumnPopup, 'Value', 1, 'String', ' ');
    set(handles.KRD5ColumnPopup, 'Value', 1, 'String', ' ');
    set(handles.KRD10ColumnPopup, 'Value', 1, 'String', ' ');
    set(handles.KRD20ColumnPopup, 'Value', 1, 'String', ' ');
    set(handles.KRD30ColumnPopup, 'Value', 1, 'String', ' ');
    set(handles.weightColumnPopup, 'Value', 1, 'String', ' ');

    % GUI Listboxes
    set(handles.filterFieldsList, 'Value', 1, 'String', ' ');
    
    % GUI boxes
    set(handles.currentPortfolioSizeBox, 'String', 0);
    set(handles.newPortfolioSizeBox, 'String', 0);
    
end

function handles = ClearFilterPanel(handles)

    % Tables
    handles.unifiedStringTable = [];
    handles.unifiedNumericTable = [];
    handles.filteredStringTable = [];
    handles.filteredNumericTable = [];
    
    % Arrays
    handles.unifiedColumnNames = [];
    
    % GUI tables
    set(handles.selectedFieldsTable, 'Data', '', 'ColumnName', []);
    
    % GUI Popups
    set(handles.sortByPopup1, 'Value', 1, 'String', ' ');
    set(handles.sortByPopup2, 'Value', 1, 'String', ' ');
    set(handles.sortByPopup3, 'Value', 1, 'String', ' ');
    set(handles.filterPopup1, 'Value', 1, 'String', ' ');
    set(handles.filterPopup2, 'Value', 1, 'String', ' ');
    
    % GUI Listboxes
    set(handles.filterEqualsList1, 'Value', 1, 'String', ' ');
    set(handles.filterEqualsList2, 'Value', 1, 'String', ' ');
    
end

function handles = ClearOptimizePanel(handles)
    
    % Tables
    handles.characteristicsMatrix = [];
    handles.lastSolution = [];
    handles.optimizationFunctions = [];
    handles.currentSecurityGroupMapping = [];
    handles.groupConstraintAMatrix = [];
    handles.groupConstraintbVector = [];
    
    % GUI tables
    set(handles.groupingTable, 'Data', '', 'ColumnName', []);
    
    % GUI Popups
    set(handles.groupByPopup, 'Value', 1, 'String', ' ');
    set(handles.groupingTypePopup, 'Value', 1);
    set(handles.parameterPopup, 'Value', 1);
    set(handles.optimizePopup, 'Value', 1, 'String', ' ');
    set(handles.groupedByPopup, 'Value', 1, 'String', ' ');
    
    % GUI Listboxes
    set(handles.outOfOptimizationList, 'Value', 1, 'String', []);
    set(handles.usedFunctionsList, 'Value', 1, 'String', []);
    set(handles.constraintsList, 'Value', 1, 'String', []);
    
    % GUI boxes
    set(handles.benchWeightBox, 'String', 0);
    set(handles.benchDurationBox, 'String', 0);
    set(handles.benchKRD2Box, 'String', 0);
    set(handles.benchKRD5Box, 'String', 0);
    set(handles.benchKRD10Box, 'String', 0);
    set(handles.benchKRD20Box, 'String', 0);
    set(handles.benchKRD30Box, 'String', 0);
    set(handles.benchYieldBox, 'String', 0);
    set(handles.benchSpreadBox, 'String', 0);
    set(handles.benchDTSBox, 'String', 0);
    set(handles.portWeightBox, 'String', 0);
    set(handles.portDurationBox, 'String', 0);
    set(handles.portKRD2Box, 'String', 0);
    set(handles.portKRD5Box, 'String', 0);
    set(handles.portKRD10Box, 'String', 0);
    set(handles.portKRD20Box, 'String', 0);
    set(handles.portKRD30Box, 'String', 0);
    set(handles.portYieldBox, 'String', 0);
    set(handles.portSpreadBox, 'String', 0);
    set(handles.portDTSBox, 'String', 0);
    set(handles.maxWeightBox, 'String', 0);
    set(handles.maxDurationBox, 'String', 0);
    set(handles.maxKRD2Box, 'String', 0);
    set(handles.maxKRD5Box, 'String', 0);
    set(handles.maxKRD10Box, 'String', 0);
    set(handles.maxKRD20Box, 'String', 0);
    set(handles.maxKRD30Box, 'String', 0);
    set(handles.maxYieldBox, 'String', 0);
    set(handles.maxSpreadBox, 'String', 0);
    set(handles.maxDTSBox, 'String', 0);
    set(handles.minWeightBox, 'String', 0);
    set(handles.minDurationBox, 'String', 0);
    set(handles.minKRD2Box, 'String', 0);
    set(handles.minKRD5Box, 'String', 0);
    set(handles.minKRD10Box, 'String', 0);
    set(handles.minKRD20Box, 'String', 0);
    set(handles.minKRD30Box, 'String', 0);
    set(handles.minYieldBox, 'String', 0);
    set(handles.minSpreadBox, 'String', 0);
    set(handles.minDTSBox, 'String', 0);
  
    set(handles.nSecuritiesInPortfolioBox, 'String', 0);
    set(handles.nSecuritiesInBenchmarkBox, 'String', 0);
    set(handles.nSecuritiesOutOfBenchmarkBox, 'String', 0);
    set(handles.totalNumberOfSecuritiesBox, 'String', 0);
    set(handles.nMaxSecuritiesBox, 'String', 0);
    set(handles.nMinSecuritiesBox, 'String', 0);
    set(handles.minimumAmountBox, 'String', '');
    set(handles.weightBox, 'String', '');
    set(handles.maxTradeBox, 'String', '');
    
    % GUI boxes with default values
    set(handles.deviationWeightBox, 'String', sprintf('%.2f', handles.defaultDeviation(1)));
    set(handles.deviationDurationBox, 'String', sprintf('%.2f', handles.defaultDeviation(2)));
    set(handles.deviationKRD2Box, 'String', sprintf('%.3f', handles.defaultDeviation(3)));
    set(handles.deviationKRD5Box, 'String', sprintf('%.3f', handles.defaultDeviation(4)));
    set(handles.deviationKRD10Box, 'String', sprintf('%.3f', handles.defaultDeviation(5)));
    set(handles.deviationKRD20Box, 'String', sprintf('%.3f', handles.defaultDeviation(6)));
    set(handles.deviationKRD30Box, 'String', sprintf('%.3f', handles.defaultDeviation(6)));
    set(handles.deviationYieldBox, 'String', sprintf('%.2f', handles.defaultDeviation(7)));
    set(handles.deviationSpreadBox, 'String', sprintf('%.2f', handles.defaultDeviation(8)));
    set(handles.deviationDTSBox, 'String', sprintf('%.2f', handles.defaultDeviation(9)));
    set(handles.KRD0510, 'String', sprintf('%.3f', handles.defaultDeviation(10)));
    set(handles.KRD2030, 'String', sprintf('%.3f', handles.defaultDeviation(11)));
    
    set(handles.nBucketsBox, 'String', handles.defaultNBuckets);
    set(handles.deviationBox, 'String', handles.defaultGroupDeviation(1));
    set(handles.maxDeviationBox, 'String', handles.defaultGroupDeviation(2));

    % GUI checkboxes
    set(handles.constraintWeightCheck, 'Value', 1);
    set(handles.constraintDurationCheck, 'Value', 1);
    set(handles.constraintKRDCheck, 'Value', 1);
    set(handles.constraintYieldCheck, 'Value', 1);
    set(handles.constraintSpreadCheck, 'Value', 1);
    set(handles.constraintDTSCheck, 'Value', 1);
    set(handles.KRD0510Check, 'Value', 1);
    set(handles.KRD2030Check, 'Value', 1);
    
    set(handles.buyCheckbox, 'Value', 1);
    set(handles.sellCheckbox, 'Value', 1);
    set(handles.excludeOutBMCheck, 'Value', 0);
    set(handles.includeOnlyPortfolioSecuritiesCheck, 'Value', 0);
    set(handles.excludeTickersOutOfBenchmarkCheck, 'Value', 0);
    
end

function handles = ClearResultsPanel(handles)

    % Tables
    handles.lastSolution = [];
    
    % GUI tables
    set(handles.resultGroupingTable, 'Data', '', 'ColumnName', []);
    set(handles.resultsTable, 'Data', '', 'ColumnName', []);

    % GUI Popups
    set(handles.groupingBucketingPopup, 'Value', 1);
    set(handles.resultGroupByPopup, 'Value', 1, 'String', ' ');
    set(handles.resultParameterPopup, 'Value', 1);

    % GUI boxes
    set(handles.resultBenchWeightBox, 'String', 0);
    set(handles.resultBenchDurationBox, 'String', 0);
    set(handles.resultBenchKRD2Box, 'String', 0);
    set(handles.resultBenchKRD5Box, 'String', 0);
    set(handles.resultBenchKRD10Box, 'String', 0);
    set(handles.resultBenchKRD30Box, 'String', 0);
    set(handles.resultBenchYieldBox, 'String', 0);
    set(handles.resultBenchSpreadBox, 'String', 0);
    set(handles.resultBenchDTSBox, 'String', 0);
    set(handles.resultOrigPortWeightBox, 'String', 0);
    set(handles.resultOrigPortDurationBox, 'String', 0);
    set(handles.resultOrigPortKRD2Box, 'String', 0);
    set(handles.resultOrigPortKRD5Box, 'String', 0);
    set(handles.resultOrigPortKRD10Box, 'String', 0);
    set(handles.resultOrigPortKRD30Box, 'String', 0);
    set(handles.resultOrigPortYieldBox, 'String', 0);
    set(handles.resultOrigPortSpreadBox, 'String', 0);
    set(handles.resultOrigPortDTSBox, 'String', 0);
    set(handles.resultNewPortWeightBox, 'String', 0);
    set(handles.resultNewPortDurationBox, 'String', 0);
    set(handles.resultNewPortKRD2Box, 'String', 0);
    set(handles.resultNewPortKRD5Box, 'String', 0);
    set(handles.resultNewPortKRD10Box, 'String', 0);
    set(handles.resultNewPortKRD30Box, 'String', 0);
    set(handles.resultNewPortYieldBox, 'String', 0);
    set(handles.resultNewPortSpreadBox, 'String', 0);
    set(handles.resultNewPortDTSBox, 'String', 0);
    set(handles.resultNBucketsBox, 'String', handles.defaultNBuckets);
end
