% -------------------------------------------------------------------------
% --- GENERAL -------------------------------------------------------------
% -------------------------------------------------------------------------

% Initializator, do not change!
function varargout = OptimizationPanel(varargin)
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @OptimizationPanel_OpeningFcn, ...
                   'gui_OutputFcn',  @OptimizationPanel_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

function OptimizationPanel_OpeningFcn(hObject, eventdata, handles, ...
    varargin)

    set(handles.filterDataPanel, 'Visible', 'off');
    set(handles.optimizationPanel, 'Visible', 'off');
    set(handles.resultsPanel, 'Visible', 'off');
    set(handles.importedDataPanel, 'Visible', 'on');
    set(handles.aggsimnames, 'Value',1)
    
    readportfolionames(hObject,handles);
    
    handles = Support.ClearForm(handles, 'All');
    handles.defaultFolder = '.\';
    handles.savedResults = [];
    
    [rgbImage, cmap] = imread(fullfile(strcat(pwd, '\+Images\'), 'logo.bmp'));  
    handles.logoAxes = image(rgbImage);
    colormap(cmap);
    set(gca,'xtick',[], 'ytick', []);
    axis off;
    
    fileName = fullfile(strcat(pwd, '\+Configuration\'), 'yieldBBGSymbols.txt');
    if exist(fileName, 'file') ~= 2
        errordlg(strcar({'File ', fileName, ' not opened properly'}));
        error(strcar({'File ', fileName, ' not opened properly'}));
    else
        file = fopen(fileName);
        fileInfo = textscan(file, '%s %s', 'delimiter', ',');
        fclose(file);
        handles.yieldBBGSymbols = cell(size(fileInfo{1, 1}, 1), 2);
        handles.yieldBBGSymbols(:, 1) = fileInfo{1, 1};
        handles.yieldBBGSymbols(:, 2) = fileInfo{1, 2};
    end
    
    handles.output = hObject;

    guidata(hObject, handles);

function importButton_Callback(hObject, ~, handles)

    set(handles.filterDataPanel, 'Visible', 'off');
    set(handles.optimizationPanel, 'Visible', 'off');
    set(handles.resultsPanel, 'Visible', 'off');
    set(handles.importedDataPanel, 'Visible', 'on');

function filterButton_Callback(hObject, eventdata, handles)
    
    set(handles.importedDataPanel, 'Visible', 'off');
    set(handles.optimizationPanel, 'Visible', 'off');
    set(handles.resultsPanel, 'Visible', 'off');
    set(handles.filterDataPanel, 'Visible', 'on');
    
function optimizeButton_Callback(hObject, eventdata, handles)

    set(handles.importedDataPanel, 'Visible', 'off');
    set(handles.filterDataPanel, 'Visible', 'off');
    set(handles.resultsPanel, 'Visible', 'off');
    set(handles.optimizationPanel, 'Visible', 'on');

function resultsButton_Callback(hObject, eventdata, handles)

    set(handles.importedDataPanel, 'Visible', 'off');
    set(handles.filterDataPanel, 'Visible', 'off');
    set(handles.optimizationPanel, 'Visible', 'off');
    set(handles.resultsPanel, 'Visible', 'on');

% -------------------------------------------------------------------------
% --- IMPORT --------------------------------------------------------------
% -------------------------------------------------------------------------

function importFilesButton_Callback(hObject, eventdata, handles)
    
    handles = Import.ImportFiles(handles);
    guidata(hObject,handles);

function downloadBloombergDataButton_Callback(hObject, eventdata, handles)
    % Name , Bid , Ask, Min Piece, Amt Outstanding, Issue Date, Tkt Tot
    % Amount
    handles = Import.GetBBGData(handles);
    guidata(hObject,handles);
    
function continue1Button_Callback(hObject, eventdata, handles)

    handles = Import.Process(handles);
    guidata(hObject,handles);

function currentPortfolioSizeBox_Callback(hObject, eventdata, handles)

    set(handles.newPortfolioSizeBox, 'String', get(handles.currentPortfolioSizeBox, 'String'));
    guidata(hObject,handles);
    
% -------------------------------------------------------------------------
% --- FILTER --------------------------------------------------------------
% -------------------------------------------------------------------------

function sortByPopup1_Callback(hObject, eventdata, handles)
    if get(handles.sortByPopup1, 'Value') ==  1
        set(handles.sortByPopup2, 'Enable', 'off', 'Value', 1);
        set(handles.sortByPopup3, 'Enable', 'off', 'Value', 1);
    else
        set(handles.sortByPopup2, 'Enable', 'on');
    end
    
    handles = Filter.ApplyFilter(handles);
    guidata(hObject,handles);

function sortByPopup2_Callback(hObject, eventdata, handles)
    if get(handles.sortByPopup2, 'Value')  ==  1
        set(handles.sortByPopup3, 'Enable', 'off', 'Value', 1);
    else
        set(handles.sortByPopup3, 'Enable', 'on');
    end

    handles = Filter.ApplyFilter(handles);
    guidata(hObject,handles);

function sortByPopup3_Callback(hObject, eventdata, handles)

    handles = Filter.ApplyFilter(handles);
    guidata(hObject,handles);

function filterPopup1_Callback(hObject, eventdata, handles)
    choice = get(handles.filterPopup1,'Value') - 1;
    if choice ==  0
        set(handles.filterPopup2, 'Enable', 'off', 'Value', 1);
        set(handles.filterEqualsList1, 'Enable', 'off', 'String', '', 'Value', 1);
        set(handles.filterEqualsList2, 'Enable', 'off', 'String', '', 'Value', 1);
    else
        set(handles.filterPopup2, 'Value', 1);
        set(handles.filterEqualsList2, 'Enable', 'off', 'Value', 1, 'String', '');
        set(handles.filterEqualsList1, 'Enable', 'on', 'Value', 1, 'String', unique(handles.unifiedStringTable(:, choice + 3)), 'max', size(unique(handles.unifiedStringTable(:, choice+3)), 1));
        set(handles.filterPopup2, 'Enable', 'on');
    end
    handles = Filter.ApplyFilter(handles);
    guidata(hObject,handles);
    
function filterPopup2_Callback(hObject, eventdata, handles)
    choice = get(handles.filterPopup2,'Value') - 1;
    if choice ==  0
        set(handles.filterEqualsList2, 'Enable', 'off', 'Value', 1, 'String', '');
    else
        set(handles.filterEqualsList2, 'Enable', 'on', 'Value', 1, 'String', unique(handles.filteredStringTable(:, choice + 3)), 'max', size(unique(handles.filteredStringTable(:, choice+3)), 1));
    end
    handles = Filter.ApplyFilter(handles);
    guidata(hObject,handles);
    
function filterEqualsList1_Callback(hObject, eventdata, handles)
    set(handles.filterPopup2, 'Value', 1);
    set(handles.filterEqualsList2, 'Enable', 'off', 'Value', 1, 'String', '');
    handles = Filter.ApplyFilter(handles);
    guidata(hObject,handles);

function filterEqualsList2_Callback(hObject, eventdata, handles)
    
    handles = Filter.ApplyFilter(handles);
    guidata(hObject,handles);

function continue2Button_Callback(hObject, eventdata, handles)
    
    handles = Optimize.InitialSetup(handles);
    guidata(hObject,handles);
    
% -------------------------------------------------------------------------
% --- OPTIMIZATION --------------------------------------------------------
% -------------------------------------------------------------------------

% Deviation
function deviationWeightBox_Callback(hObject, eventdata, handles)
    set(handles.deviationWeightBox, 'String', sprintf('%.2f', str2double(get(handles.deviationWeightBox, 'String'))));
    set(handles.maxWeightBox, 'String', sprintf('%.2f%%', handles.characteristicsMatrix(1, 1) * 100 + str2double(get(handles.deviationWeightBox, 'String'))));
    set(handles.minWeightBox, 'String', sprintf('%.2f%%', max(handles.characteristicsMatrix(1, 1) * 100 - str2double(get(handles.deviationWeightBox, 'String')), 0)));
    guidata(hObject,handles);
    
function deviationDurationBox_Callback(hObject, eventdata, handles)
    set(handles.deviationDurationBox, 'String', sprintf('%.2f', str2double(get(handles.deviationDurationBox, 'String'))));
    set(handles.maxDurationBox, 'String', sprintf('%.2f', handles.characteristicsMatrix(1, 2) + str2double(get(handles.deviationDurationBox, 'String'))));
    set(handles.minDurationBox, 'String', sprintf('%.2f', max(handles.characteristicsMatrix(1, 2) - str2double(get(handles.deviationDurationBox, 'String')), 0)));
    guidata(hObject,handles);
    
function deviationKRD2Box_Callback(hObject, eventdata, handles)
    set(handles.deviationKRD2Box, 'String', sprintf('%.3f', str2double(get(handles.deviationKRD2Box, 'String'))));
    set(handles.maxKRD2Box, 'String', sprintf('%.3f', handles.characteristicsMatrix(1, 3) + str2double(get(handles.deviationKRD2Box, 'String'))));
    set(handles.minKRD2Box, 'String', sprintf('%.3f', max(handles.characteristicsMatrix(1, 3) - str2double(get(handles.deviationKRD2Box, 'String')), 0)));
    guidata(hObject,handles);

function deviationKRD5Box_Callback(hObject, eventdata, handles)
    set(handles.deviationKRD5Box, 'String', sprintf('%.3f', str2double(get(handles.deviationKRD5Box, 'String'))));
    set(handles.maxKRD5Box, 'String', sprintf('%.3f', handles.characteristicsMatrix(1, 4) + str2double(get(handles.deviationKRD5Box, 'String'))));
    set(handles.minKRD5Box, 'String', sprintf('%.3f', max(handles.characteristicsMatrix(1, 4) - str2double(get(handles.deviationKRD5Box, 'String')), 0)));
    guidata(hObject,handles);

function deviationKRD10Box_Callback(hObject, eventdata, handles)
    set(handles.deviationKRD10Box, 'String', sprintf('%.3f', str2double(get(handles.deviationKRD10Box, 'String'))));
    set(handles.maxKRD10Box, 'String', sprintf('%.3f', handles.characteristicsMatrix(1, 5) + str2double(get(handles.deviationKRD10Box, 'String'))));
    set(handles.minKRD10Box, 'String', sprintf('%.3f', max(handles.characteristicsMatrix(1, 5) - str2double(get(handles.deviationKRD10Box, 'String')), 0)));
    guidata(hObject,handles);

function deviationKRD20Box_Callback(hObject, eventdata, handles)
    set(handles.deviationKRD20Box, 'String', sprintf('%.3f', str2double(get(handles.deviationKRD20Box, 'String'))));
    set(handles.maxKRD20Box, 'String', sprintf('%.3f', handles.characteristicsMatrix(1, 6) + str2double(get(handles.deviationKRD20Box, 'String'))));
    set(handles.minKRD20Box, 'String', sprintf('%.3f', max(handles.characteristicsMatrix(1, 6) - str2double(get(handles.deviationKRD20Box, 'String')), 0)));
    guidata(hObject,handles);
    
function deviationKRD30Box_Callback(hObject, eventdata, handles)
    set(handles.deviationKRD30Box, 'String', sprintf('%.3f', str2double(get(handles.deviationKRD30Box, 'String'))));
    set(handles.maxKRD30Box, 'String', sprintf('%.3f', handles.characteristicsMatrix(1, 7) + str2double(get(handles.deviationKRD30Box, 'String'))));
    set(handles.minKRD30Box, 'String', sprintf('%.3f', max(handles.characteristicsMatrix(1, 7) - str2double(get(handles.deviationKRD30Box, 'String')), 0)));
    guidata(hObject,handles);

function deviationYieldBox_Callback(hObject, eventdata, handles)
    set(handles.deviationYieldBox, 'String', sprintf('%.2f', str2double(get(handles.deviationYieldBox, 'String'))));
    set(handles.maxYieldBox, 'String', sprintf('%.2f%%', handles.characteristicsMatrix(1, 8) * 100 + str2double(get(handles.deviationYieldBox, 'String'))));
    set(handles.minYieldBox, 'String', sprintf('%.2f%%', max(handles.characteristicsMatrix(1, 8) * 100 - str2double(get(handles.deviationYieldBox, 'String')), 0)));
    guidata(hObject,handles);

function deviationSpreadBox_Callback(hObject, eventdata, handles)
    set(handles.deviationSpreadBox, 'String', sprintf('%.2f', str2double(get(handles.deviationSpreadBox, 'String'))));
    set(handles.maxSpreadBox, 'String', sprintf('%.2f', handles.characteristicsMatrix(1, 9) + str2double(get(handles.deviationSpreadBox, 'String'))));
    set(handles.minSpreadBox, 'String', sprintf('%.2f', max(handles.characteristicsMatrix(1, 9) - str2double(get(handles.deviationSpreadBox, 'String')), 0)));
    guidata(hObject,handles);
    
    
function deviationDTSBox_Callback(hObject, eventdata, handles)
    set(handles.deviationDTSBox, 'String', sprintf('%.2f', str2double(get(handles.deviationDTSBox, 'String'))));
    set(handles.maxDTSBox, 'String', sprintf('%.2f', handles.characteristicsMatrix(1, 10) + str2double(get(handles.deviationDTSBox, 'String'))));
    set(handles.minDTSBox, 'String', sprintf('%.2f', max(handles.characteristicsMatrix(1, 10) - str2double(get(handles.deviationDTSBox, 'String')), 0)));
    guidata(hObject,handles);
    

% Group by
function groupByPopup_Callback(hObject, eventdata, handles)
    handles = Optimize.GroupData(handles, 'Constraint');
    guidata(hObject,handles);
    
function nBucketsBox_Callback(hObject, eventdata, handles)
    handles = Optimize.GroupData(handles, 'Constraint');
    guidata(hObject,handles);

function parameterPopup_Callback(hObject, eventdata, handles)
    handles = Optimize.GroupData(handles, 'Constraint');
    guidata(hObject,handles);
    
function groupingTypePopup_Callback(hObject, eventdata, handles)
    typeChoice = get(handles.groupingTypePopup, 'Value');
    nNumericColumns = size(handles.filteredNumericTable, 2);
    nStringColumns = size(handles.filteredStringTable, 2);
    if typeChoice == 1
        set(handles.groupByPopup, 'String', {''}, 'Value', 1);
    elseif typeChoice == 2
        set(handles.groupByPopup, 'String', [{''}, handles.unifiedColumnNames(4:nStringColumns)], 'Value', 1);
    elseif typeChoice == 3
        set(handles.groupByPopup, 'String', [{''}, handles.unifiedColumnNames(nStringColumns + 1:nNumericColumns + nStringColumns)], 'Value', 1);
    else
        set(handles.groupByPopup, 'String', {''}, 'Value', 1);
    end
    handles = Optimize.GroupData(handles, 'Constraint');
    guidata(hObject,handles);

function groupingTable_CellEditCallback(hObject, eventdata, handles)
	fullTable = get(handles.groupingTable, 'Data');
    choice = get(handles.parameterPopup, 'value') - 1;
    if choice == 1
        fullTable(:, 6) = strread(sprintf('%.3f%% ', str2double(strrep(fullTable(:, 6), '%', ''))), '%s', 'delimiter', ' ');
        fullTable(:, 7) = strread(sprintf('%.3f%% ', str2double(strrep(fullTable(:, 7), '%', ''))), '%s', 'delimiter', ' ');
    elseif choice == 8
        fullTable(:, 8) = strread(sprintf('%.3f%% ', str2double(strrep(fullTable(:, 8), '%', ''))), '%s', 'delimiter', ' ');
        fullTable(:, 9) = strread(sprintf('%.3f%% ', str2double(strrep(fullTable(:, 9), '%', ''))), '%s', 'delimiter', ' ');
    else
        fullTable(:, 8) = strread(sprintf('%.3f ', str2double(fullTable(:, 8))), '%s', 'delimiter', ' ');
        fullTable(:, 9) = strread(sprintf('%.3f ', str2double(fullTable(:, 9))), '%s', 'delimiter', ' ');
    end
    set(handles.groupingTable, 'Data', fullTable);
    guidata(hObject,handles);

function addConstraintButton_Callback(hObject, eventdata, handles)
    handles = Optimize.AddGroupConstraint(handles);
    guidata(hObject,handles);

function clearConstraintsButton_Callback(hObject, eventdata, handles)
    handles.groupConstraintAMatrix = [];
    handles.groupConstraintbVector = [];
    set(handles.constraintsList, 'string', []);%, 'value', 1;
    guidata(hObject,handles);
    
% Constraints
function deviationBox_Callback(hObject, eventdata, handles)
    handles = Optimize.GroupData(handles, 'Constraint');
    guidata(hObject,handles);
    
function maxDeviationBox_Callback(hObject, eventdata, handles)
    handles = Optimize.GroupData(handles, 'Constraint');
    guidata(hObject,handles);

% Optimize
function optimizePortfolioButton_Callback(hObject, eventdata, handles)
     ApplyAllConstraints_Callback(hObject, eventdata, handles);
     
     guidata(hObject,handles);
     handles = Optimize.Optimize(handles);
     guidata(hObject,handles);

% Max/Min Formatting
function maxWeightBox_Callback(hObject, eventdata, handles)
    set(handles.maxWeightBox, 'String', sprintf('%.2f%%', str2double(strrep(get(handles.maxWeightBox, 'String'), '%', ''))));
    guidata(hObject,handles);

function minWeightBox_Callback(hObject, eventdata, handles)
    set(handles.minWeightBox, 'String', sprintf('%.2f%%', str2double(strrep(get(handles.minWeightBox, 'String'), '%', ''))));
    guidata(hObject,handles);

function maxYieldBox_Callback(hObject, eventdata, handles)
    set(handles.maxYield, 'String', sprintf('%.2f%%', str2double(strrep(get(handles.maxYield, 'String'), '%', ''))));
    guidata(hObject,handles);

function minYieldBox_Callback(hObject, eventdata, handles)
    set(handles.minYieldBox, 'String', sprintf('%.2f%%', str2double(strrep(get(handles.minYieldBox, 'String'), '%', ''))));
    guidata(hObject,handles);

function maxKRD2Box_Callback(hObject, eventdata, handles)
    set(handles.maxKRD2Box, 'String', sprintf('%.2f', str2double(get(handles.maxKRD2Box, 'String'))));
    guidata(hObject,handles);
    
function minKRD2Box_Callback(hObject, eventdata, handles)
    set(handles.minKRD2Box, 'String', sprintf('%.2f', str2double(get(handles.minKRD2Box, 'String'))));
    guidata(hObject,handles);
    
function maxDurationBox_Callback(hObject, eventdata, handles)
    set(handles.maxDurationBox, 'String', sprintf('%.2f', str2double(get(handles.maxDurationBox, 'String'))));
    guidata(hObject,handles);
    
function minDurationBox_Callback(hObject, eventdata, handles)
    set(handles.minDurationBox, 'String', sprintf('%.2f', str2double(get(handles.minDurationBox, 'String'))));
    guidata(hObject,handles);
    
function maxKRD5Box_Callback(hObject, eventdata, handles)
    set(handles.maxKRD5Box, 'String', sprintf('%.2f', str2double(get(handles.maxKRD5Box, 'String'))));
    guidata(hObject,handles);
    
function minKRD5Box_Callback(hObject, eventdata, handles)
    set(handles.minKRD5Box, 'String', sprintf('%.2f', str2double(get(handles.minKRD5Box, 'String'))));
    guidata(hObject,handles);
    
function maxKRD10Box_Callback(hObject, eventdata, handles)
    set(handles.maxKRD10Box, 'String', sprintf('%.2f', str2double(get(handles.maxKRD10Box, 'String'))));
    guidata(hObject,handles);
    
function minKRD10Box_Callback(hObject, eventdata, handles)
    set(handles.maxKRD2Box, 'String', sprintf('%.2f', str2double(get(handles.maxKRD2Box, 'String'))));
    guidata(hObject,handles);
    
function maxKRD20Box_Callback(hObject, eventdata, handles)
    set(handles.maxKRD20Box, 'String', sprintf('%.2f', str2double(get(handles.maxKRD20Box, 'String'))));
    guidata(hObject,handles);
    
function minKRD20Box_Callback(hObject, eventdata, handles)
    set(handles.minKRD20Box, 'String', sprintf('%.2f', str2double(get(handles.minKRD20Box, 'String'))));
    guidata(hObject,handles);
    
function maxSpreadBox_Callback(hObject, eventdata, handles)
    set(handles.maxSpreadBox, 'String', sprintf('%.2f', str2double(get(handles.maxSpreadBox, 'String'))));
    guidata(hObject,handles);
    
function minSpreadBox_Callback(hObject, eventdata, handles)
    set(handles.minSpreadBox, 'String', sprintf('%.2f', str2double(get(handles.minSpreadBox, 'String'))));
    guidata(hObject,handles);

function maxTradeBox_Callback(hObject, eventdata, handles)
    value = strrep(get(handles.maxTradeBox, 'String'), '%', '');
    if isempty(value)
        set(handles.maxTradeBox, 'String', '');
    else
        set(handles.maxTradeBox, 'String', sprintf('%.2f%%', str2double(value)));
    end
    
    guidata(hObject,handles);
    
% Optimization function 

function removeFunctionButton_Callback(hObject, eventdata, handles)
    choice = get(handles.usedFunctionsList, 'value');
    originalGUI = get(handles.usedFunctionsList , 'String');
    originalFunctions = handles.optimizationFunctions;
    if isempty(originalGUI) == 0
        originalGUI(choice, :) = [];
        originalFunctions(choice, :) = [];

        set(handles.usedFunctionsList , 'String', originalGUI, 'value', 1);
        handles.optimizationFunctions = originalFunctions;
        guidata(hObject,handles);
    end
% Factor

function addFunctionButton_Callback(hObject, eventdata, handles)
    choice = get(handles.optimizePopup, 'value') - 1;
    group = get(handles.groupedByPopup, 'value') - 1;
    weight = str2double(get(handles.weightBox , 'String'));
    weight_change=get(handles.WeightAutoOnOff,'Value');
    
    if choice == 0 
        errordlg('Please select an optimization function');
        error('Please select an optimization function'); 
    end
    
    if (choice ~= 1 && choice ~= 2 && choice ~= 3 && choice ~= 4 && choice ~= 5 && choice ~= 6 && choice ~= 7) && group == 0
        errordlg('Please select a grouping');
        error('Please select a grouping'); 
    end
    
    newText = '';
    if choice == 1 
        newText = strcat({'Min_IndividialWeights - '}, sprintf('%.3f', weight));
    elseif choice == 2
        newText = strcat({'Max_Liquidity - '}, sprintf('%.3f', weight));
    elseif choice == 3
        newText = strcat({'Min_Costs - '}, sprintf('%.3f', weight));
    elseif choice == 4
        newText = strcat({'Max_Yield - '}, sprintf('%.3f', weight));
    elseif choice == 5
        newText = strcat({'Max_Spread/ ATY - '}, sprintf('%.3f', weight));
    elseif choice == 6
        newText = strcat({'# of securities - '}, sprintf('%.3f', weight));
    elseif choice == 7
        newText = strcat({'Out of portfolio securities - '}, sprintf('%.3f', weight));
    elseif choice == 8
        newText = strcat({'Grouped Weights | '}, handles.unifiedColumnNames(group + 3), sprintf(' - %.3f', weight));
    elseif choice == 9
        newText = strcat({'Duration | '}, handles.unifiedColumnNames(group + 3), sprintf(' - %.3f', weight));
    elseif choice == 10
        newText = strcat({'All KRD | '}, handles.unifiedColumnNames(group + 3), sprintf(' - %.3f', weight));
    elseif choice == 11
        newText = strcat({'KRD 0.5Y..2Y | '}, handles.unifiedColumnNames(group + 3), sprintf(' - %.3f', weight));
    elseif choice == 12
        newText = strcat({'KRD 5Y | '}, handles.unifiedColumnNames(group + 3), sprintf(' - %.3f', weight));
    elseif choice == 13
        newText = strcat({'KRD 10Y | '}, handles.unifiedColumnNames(group + 3), sprintf(' - %.3f', weight));
    elseif choice == 14
        newText = strcat({'KRD 20Y | '}, handles.unifiedColumnNames(group + 3), sprintf(' - %.3f', weight));
    elseif choice == 15
        newText = strcat({'KRD 30Y | '}, handles.unifiedColumnNames(group + 3), sprintf(' - %.3f', weight));
    elseif choice == 16
        newText = strcat({'Yield | '}, handles.unifiedColumnNames(group + 3), sprintf(' - %.3f', weight));
    elseif choice == 17
        newText = strcat({'Spread/ATY | '}, handles.unifiedColumnNames(group + 3), sprintf(' - %.3f', weight)); 
    elseif choice == 18
        newText = strcat({'DTS | '}, handles.unifiedColumnNames(group + 3), sprintf(' - %.3f', weight)); 
    elseif choice == 19
        newText = strcat({'MinMaxGrouped Weights | '}, handles.unifiedColumnNames(group + 3), sprintf(' - %.3f', weight));
    elseif choice == 20
        newText = strcat({'MinMaxGrouped Duration | '}, handles.unifiedColumnNames(group + 3), sprintf(' - %.3f', weight));
    elseif choice == 21
        newText = strcat({'MinMaxGrouped DTS | '}, handles.unifiedColumnNames(group + 3), sprintf(' - %.3f', weight));
    end 
    if isempty(handles.optimizationFunctions)
        handles.optimizationFunctions = [choice, group + 3, weight,weight_change];
        set(handles.usedFunctionsList , 'String', newText);
    else
        handles.optimizationFunctions = [handles.optimizationFunctions; [choice, group + 3, weight,weight_change]];
        set(handles.usedFunctionsList , 'String', [get(handles.usedFunctionsList , 'String'); newText]);
    end
     guidata(hObject,handles);

function optimizePopup_Callback(hObject, eventdata, handles)
    choice = get(handles.optimizePopup, 'value');
    handles.WeightAutoOnOffVar=0;
    set(handles.WeightAutoOnOff,'Value',0);
    nStringColumns = size(handles.filteredStringTable, 2);
    if choice == 1 
        set(handles.groupedByPopup, 'string', ' ', 'value', 1);
        set(handles.weightBox, 'String', '');
    elseif choice == 2 || choice == 3 || choice == 4 || choice == 5 || choice == 6 || choice == 7 || choice == 8
        set(handles.weightBox, 'String', sprintf('%.3f', 1));
        set(handles.groupedByPopup, 'string', ' ', 'value', 1);
    elseif choice == 9 %% Grouped Weight
        set(handles.weightBox, 'String', sprintf('%.3f',  1 / sum(handles.filteredNumericTable(:, 1))));
        set(handles.groupedByPopup, 'String', [{''}, handles.unifiedColumnNames(4:nStringColumns + 4)], 'Value', 1);
    elseif choice == 10 %% Grouped Duration
        set(handles.weightBox, 'String', sprintf('%.3f', 1 / sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 6))));
        set(handles.groupedByPopup, 'String', [{''}, handles.unifiedColumnNames(4:nStringColumns + 4)], 'Value', 1);        
    elseif choice == 11
        set(handles.weightBox, 'String', sprintf('%.3f', 1 / sum(handles.filteredNumericTable(:, 1) .* (handles.filteredNumericTable(:, 8) + handles.filteredNumericTable(:, 9) + handles.filteredNumericTable(:, 10) + handles.filteredNumericTable(:, 11)) / 4)));
        set(handles.groupedByPopup, 'String', [{''}, handles.unifiedColumnNames(4:nStringColumns + 4)], 'Value', 1);        
    elseif choice == 12
        set(handles.weightBox, 'String', sprintf('%.3f', 1 / sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 8))));
        set(handles.groupedByPopup, 'String', [{''}, handles.unifiedColumnNames(4:nStringColumns)], 'Value', 1);        
    elseif choice == 13
        set(handles.weightBox, 'String', sprintf('%.3f', 1 / sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 9))));
        set(handles.groupedByPopup, 'String', [{''}, handles.unifiedColumnNames(4:nStringColumns)], 'Value', 1);        
    elseif choice == 14
        set(handles.weightBox, 'String', sprintf('%.3f', 1 / sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 10))));
        set(handles.groupedByPopup, 'String', [{''}, handles.unifiedColumnNames(4:nStringColumns)], 'Value', 1);       
    elseif choice == 15
        set(handles.weightBox, 'String', sprintf('%.3f', 1 / sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 11))));
        set(handles.groupedByPopup, 'String', [{''}, handles.unifiedColumnNames(4:nStringColumns)], 'Value', 1);  
    elseif choice == 16
        set(handles.weightBox, 'String', sprintf('%.3f', 1 / sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 12))));
        set(handles.groupedByPopup, 'String', [{''}, handles.unifiedColumnNames(4:nStringColumns)], 'Value', 1);        
    elseif choice == 17
        set(handles.weightBox, 'String', sprintf('%.3f', 1 / sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 5))));
        set(handles.groupedByPopup, 'String', [{''}, handles.unifiedColumnNames(4:nStringColumns)], 'Value', 1);        
    elseif choice == 18
        set(handles.weightBox, 'String', sprintf('%.3f', 1 / sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 7))));
        set(handles.groupedByPopup, 'String', [{''}, handles.unifiedColumnNames(4:nStringColumns)], 'Value', 1);        
    elseif choice == 19
        set(handles.weightBox, 'String', sprintf('%.3f',  1 / sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 7).* handles.filteredNumericTable(:, 6)/100)));
        set(handles.groupedByPopup, 'String', [{''}, handles.unifiedColumnNames(4:nStringColumns)], 'Value', 1);
    elseif choice == 20
        set(handles.weightBox, 'String', sprintf('%.3f',  1 / sum(handles.filteredNumericTable(:, 1))));
        set(handles.groupedByPopup, 'String', [{''}, handles.unifiedColumnNames(4:nStringColumns)], 'Value', 1);
    elseif choice == 21
        set(handles.weightBox, 'String', sprintf('%.3f',  1 / sum(handles.filteredNumericTable(:, 1).*handles.filteredNumericTable(:, 6))));
        set(handles.groupedByPopup, 'String', [{''}, handles.unifiedColumnNames(4:nStringColumns)], 'Value', 1);
    elseif choice == 22
        set(handles.weightBox, 'String', sprintf('%.3f',  1 / sum(handles.filteredNumericTable(:, 1).*handles.filteredNumericTable(:, 6).*handles.filteredNumericTable(:, 7)/100)));
        set(handles.groupedByPopup, 'String', [{''}, handles.unifiedColumnNames(4:nStringColumns)], 'Value', 1);
    end
    guidata(hObject,handles);
        
% -------------------------------------------------------------------------
% --- RESULTS -------------------------------------------------------------
% -------------------------------------------------------------------------
    
function groupingBucketingPopup_Callback(hObject, eventdata, handles)    
    typeChoice = get(handles.groupingBucketingPopup, 'Value');
    nNumericColumns = size(handles.filteredNumericTable, 2);
    nStringColumns = size(handles.filteredStringTable, 2);
    if typeChoice == 2
        set(handles.resultGroupByPopup, 'String', [{''}, handles.unifiedColumnNames(4:nStringColumns)], 'Value', 1);
    elseif typeChoice == 3
        set(handles.resultGroupByPopup, 'String', [{''}, handles.unifiedColumnNames(nStringColumns + 1:nNumericColumns + nStringColumns)], 'Value', 1);
    else
        set(handles.resultGroupByPopup, 'String', {''}, 'Value', 1);
    end
    handles = Optimize.GroupData(handles, 'Result');
    guidata(hObject,handles);
    
function resultGroupByPopup_Callback(hObject, eventdata, handles)
    handles = Optimize.GroupData(handles, 'Result');
    guidata(hObject,handles);
    
function resultNBucketsBox_Callback(hObject, eventdata, handles)
    handles = Optimize.GroupData(handles, 'Result');
    guidata(hObject,handles);

function resultParameterPopup_Callback(hObject, eventdata, handles)
    handles = Optimize.GroupData(handles, 'Result');
    guidata(hObject,handles);
    
% Exporting data

function appendButton_Callback(hObject, eventdata, handles)
    previousTable = get(handles.savedTable, 'Data');
    if size(previousTable, 1) == 0
        set(handles.savedTable, 'ColumnName', {'Name', 'Weight', 'Buy Size','R. Buy Size', 'Min Size', 'ISIN', 'GIM2 Symbol'});
    end
    set(handles.savedTable, 'Data', [previousTable; get(handles.resultsTable, 'Data')]);
    guidata(hObject,handles);

function clearButton_Callback(hObject, eventdata, handles)
    set(handles.savedTable, 'Data', [], 'ColumnName', []);
    guidata(hObject,handles);

function exportButton_Callback(hObject, eventdata, handles)
    [fileName, pathName] = uiputfile({'*.xlsx', 'Excel Workbook'}, 'Save results');
    xlswrite(strcat(pathName, fileName), [{'Name', 'Weight', 'Buy Size','R. Buy Size', 'Min Size', 'ISIN', 'GIM2 Symbol'}; get(handles.savedTable, 'Data')]);
    msgbox('File saved');
    guidata(hObject,handles);
    
%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% FUNCTIONS NOT USED %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%

function varargout = OptimizationPanel_OutputFcn(hObject, eventdata, handles) 
    varargout{1} = handles.output;

function constraintWeightCheck_Callback(hObject, eventdata, handles)

function constraintDurationCheck_Callback(hObject, eventdata, handles)

function constraintKRDCheck_Callback(hObject, eventdata, handles)

function constraintYieldCheck_Callback(hObject, eventdata, handles)

function constraintSpreadCheck_Callback(hObject, eventdata, handles)

function optimizeButton_CreateFcn(hObject, eventdata, handles)

function outOfOptimizationList_Callback(hObject, eventdata, handles)

function excludeOutBMCheck_Callback(hObject, eventdata, handles)

function benchWeightBox_Callback(hObject, eventdata, handles)

function portWeightBox_Callback(hObject, eventdata, handles)

function benchDurationBox_Callback(hObject, eventdata, handles)

function portDurationBox_Callback(hObject, eventdata, handles)

function benchKRD2Box_Callback(hObject, eventdata, handles)

function portKRD2Box_Callback(hObject, eventdata, handles)

function benchKRD5Box_Callback(hObject, eventdata, handles)

function portKRD5Box_Callback(hObject, eventdata, handles)

function benchKRD10Box_Callback(hObject, eventdata, handles)

function portKRD10Box_Callback(hObject, eventdata, handles)

function benchKRD20Box_Callback(hObject, eventdata, handles)

function portKRD20Box_Callback(hObject, eventdata, handles)

function benchYieldBox_Callback(hObject, eventdata, handles)

function portYieldBox_Callback(hObject, eventdata, handles)

function benchSpreadBox_Callback(hObject, eventdata, handles)

function portSpreadBox_Callback(hObject, eventdata, handles)

function benchWeightBox_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function portWeightBox_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function maxWeightBox_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function minWeightBox_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function deviationWeightBox_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function benchDurationBox_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function portDurationBox_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function maxDurationBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to maxDurationBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function minDurationBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to minDurationBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function deviationDurationBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to deviationDurationBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function benchKRD2Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to benchKRD2Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function portKRD2Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to portKRD2Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function maxKRD2Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to maxKRD2Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function minKRD2Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to minKRD2Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function deviationKRD2Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to deviationKRD2Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function benchKRD5Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to benchKRD5Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function portKRD5Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to portKRD5Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function maxKRD5Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to maxKRD5Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function minKRD5Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to minKRD5Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function deviationKRD5Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to deviationKRD5Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function benchKRD10Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to benchKRD10Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function portKRD10Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to portKRD10Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function maxKRD10Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to maxKRD10Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function minKRD10Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to minKRD10Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function deviationKRD10Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to deviationKRD10Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function benchKRD20Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to benchKRD20Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function portKRD20Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to portKRD20Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function maxKRD20Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to maxKRD20Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function minKRD20Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to minKRD20Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function deviationKRD20Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to deviationKRD20Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function benchYieldBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to benchYieldBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function portYieldBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to portYieldBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function maxYieldBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to maxYieldBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function minYieldBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to minYieldBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function deviationYieldBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to deviationYieldBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function benchSpreadBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to benchSpreadBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function portSpreadBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to portSpreadBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function maxSpreadBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to maxSpreadBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function minSpreadBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to minSpreadBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function deviationSpreadBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to deviationSpreadBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function carryOverBox_Callback(hObject, eventdata, handles)
% hObject    handle to carryOverBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of carryOverBox as text
%        str2double(get(hObject,'String')) returns contents of carryOverBox as a double



function nCombinationsBox_Callback(hObject, eventdata, handles)
% hObject    handle to nCombinationsBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of nCombinationsBox as text
%        str2double(get(hObject,'String')) returns contents of nCombinationsBox as a double



function nRepetitionsBox_Callback(hObject, eventdata, handles)
% hObject    handle to nRepetitionsBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of nRepetitionsBox as text
%        str2double(get(hObject,'String')) returns contents of nRepetitionsBox as a double



function mutationsBox_Callback(hObject, eventdata, handles)
% hObject    handle to mutationsBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of mutationsBox as text
%        str2double(get(hObject,'String')) returns contents of mutationsBox as a double



function crossoverBox_Callback(hObject, eventdata, handles)
% hObject    handle to crossoverBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of crossoverBox as text
%        str2double(get(hObject,'String')) returns contents of crossoverBox as a double


% --- Executes during object creation, after setting all properties.
function carryOverBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to carryOverBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function nCombinationsBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to nCombinationsBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function nRepetitionsBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to nRepetitionsBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function mutationsBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to mutationsBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function crossoverBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to crossoverBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function nSecuritiesInPortfolioBox_Callback(hObject, eventdata, handles)
% hObject    handle to nSecuritiesInPortfolioBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of nSecuritiesInPortfolioBox as text
%        str2double(get(hObject,'String')) returns contents of nSecuritiesInPortfolioBox as a double



function nSecuritiesOutOfBenchmarkBox_Callback(hObject, eventdata, handles)
% hObject    handle to nSecuritiesOutOfBenchmarkBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of nSecuritiesOutOfBenchmarkBox as text
%        str2double(get(hObject,'String')) returns contents of nSecuritiesOutOfBenchmarkBox as a double



function nSecuritiesInBenchmarkBox_Callback(hObject, eventdata, handles)
% hObject    handle to nSecuritiesInBenchmarkBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of nSecuritiesInBenchmarkBox as text
%        str2double(get(hObject,'String')) returns contents of nSecuritiesInBenchmarkBox as a double



function nMaxSecuritiesBox_Callback(hObject, eventdata, handles)
% hObject    handle to nMaxSecuritiesBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of nMaxSecuritiesBox as text
%        str2double(get(hObject,'String')) returns contents of nMaxSecuritiesBox as a double


% --- Executes during object creation, after setting all properties.
function nSecuritiesInPortfolioBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to nSecuritiesInPortfolioBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function nSecuritiesOutOfBenchmarkBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to nSecuritiesOutOfBenchmarkBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function nSecuritiesInBenchmarkBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to nSecuritiesInBenchmarkBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function nMaxSecuritiesBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to nMaxSecuritiesBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function deviationBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to deviationBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function maxDeviationBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to maxDeviationBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function maxDeviationBucketingBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to maxDeviationBucketingBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function deviationBucketingBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to maxDeviationBucketingBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function currentPortfolioSizeBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to currentPortfolioSizeBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function groupByPopup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to groupByPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function groupingTypePopup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to groupingTypePopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function groupByBucketingPopup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to groupByBucketingPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function bucketingConstraintPopup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bucketingConstraintPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function sortByPopup1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sortByPopup1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function sortByPopup2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sortByPopup2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function sortByPopup3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sortByPopup3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function filterPopup1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to filterPopup1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function filterPopup2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to filterPopup2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in maturityColumnPopup.
function maturityColumnPopup_Callback(hObject, eventdata, handles)
% hObject    handle to maturityColumnPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns maturityColumnPopup contents as cell array
%        contents{get(hObject,'Value')} returns selected item from maturityColumnPopup


% --- Executes on selection change in ISINColumnPopup.
function ISINColumnPopup_Callback(hObject, eventdata, handles)
% hObject    handle to ISINColumnPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns ISINColumnPopup contents as cell array
%        contents{get(hObject,'Value')} returns selected item from ISINColumnPopup


% --- Executes on selection change in yieldColumnPopup.
function yieldColumnPopup_Callback(hObject, eventdata, handles)
% hObject    handle to yieldColumnPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns yieldColumnPopup contents as cell array
%        contents{get(hObject,'Value')} returns selected item from yieldColumnPopup


% --- Executes on selection change in durationColumnPopup.
function durationColumnPopup_Callback(hObject, eventdata, handles)
% hObject    handle to durationColumnPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns durationColumnPopup contents as cell array
%        contents{get(hObject,'Value')} returns selected item from durationColumnPopup


% --- Executes on selection change in spreadColumnPopup.
function spreadColumnPopup_Callback(hObject, eventdata, handles)
% hObject    handle to spreadColumnPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns spreadColumnPopup contents as cell array
%        contents{get(hObject,'Value')} returns selected item from spreadColumnPopup


% --- Executes on selection change in KRD05ColumnPopup.
function KRD05ColumnPopup_Callback(hObject, eventdata, handles)
% hObject    handle to KRD05ColumnPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns KRD05ColumnPopup contents as cell array
%        contents{get(hObject,'Value')} returns selected item from KRD05ColumnPopup


% --- Executes on selection change in KRD2ColumnPopup.
function KRD2ColumnPopup_Callback(hObject, eventdata, handles)
% hObject    handle to KRD2ColumnPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns KRD2ColumnPopup contents as cell array
%        contents{get(hObject,'Value')} returns selected item from KRD2ColumnPopup


% --- Executes on selection change in KRD5ColumnPopup.
function KRD5ColumnPopup_Callback(hObject, eventdata, handles)
% hObject    handle to KRD5ColumnPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns KRD5ColumnPopup contents as cell array
%        contents{get(hObject,'Value')} returns selected item from KRD5ColumnPopup


% --- Executes on selection change in KRD10ColumnPopup.
function KRD10ColumnPopup_Callback(hObject, eventdata, handles)
% hObject    handle to KRD10ColumnPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns KRD10ColumnPopup contents as cell array
%        contents{get(hObject,'Value')} returns selected item from KRD10ColumnPopup


% --- Executes on selection change in KRD20ColumnPopup.
function KRD20ColumnPopup_Callback(hObject, eventdata, handles)
% hObject    handle to KRD20ColumnPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns KRD20ColumnPopup contents as cell array
%        contents{get(hObject,'Value')} returns selected item from KRD20ColumnPopup


% --- Executes on selection change in KRD30ColumnPopup.
function KRD30ColumnPopup_Callback(hObject, eventdata, handles)
% hObject    handle to KRD30ColumnPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns KRD30ColumnPopup contents as cell array
%        contents{get(hObject,'Value')} returns selected item from KRD30ColumnPopup


% --- Executes on selection change in weightColumnPopup.
function weightColumnPopup_Callback(hObject, eventdata, handles)
% hObject    handle to weightColumnPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns weightColumnPopup contents as cell array
%        contents{get(hObject,'Value')} returns selected item from weightColumnPopup


% --- Executes during object creation, after setting all properties.
function maturityColumnPopup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to maturityColumnPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function ISINColumnPopup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ISINColumnPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function yieldColumnPopup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to yieldColumnPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function durationColumnPopup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to durationColumnPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function spreadColumnPopup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to spreadColumnPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function KRD05ColumnPopup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to KRD05ColumnPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function KRD2ColumnPopup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to KRD2ColumnPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function KRD5ColumnPopup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to KRD5ColumnPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function KRD10ColumnPopup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to KRD10ColumnPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function KRD20ColumnPopup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to KRD20ColumnPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function KRD30ColumnPopup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to KRD30ColumnPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function weightColumnPopup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to weightColumnPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





% --- Executes during object creation, after setting all properties.
function outOfOptimizationList_CreateFcn(hObject, eventdata, handles)
% hObject    handle to outOfOptimizationList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





% --- Executes during object creation, after setting all properties.
function filterEqualsList1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to filterEqualsList1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function filterEqualsList2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to filterEqualsList2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in filterFieldsList.
function filterFieldsList_Callback(hObject, eventdata, handles)
% hObject    handle to filterFieldsList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns filterFieldsList contents as cell array
%        contents{get(hObject,'Value')} returns selected item from filterFieldsList


% --- Executes during object creation, after setting all properties.
function filterFieldsList_CreateFcn(hObject, eventdata, handles)
% hObject    handle to filterFieldsList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function optimizationPanel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to optimizationPanel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function characteristicsPanel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to characteristicsPanel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function weightsText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to weightsText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function durationText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to durationText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function KRD2Text_CreateFcn(hObject, eventdata, handles)
% hObject    handle to KRD2Text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function KRD5Text_CreateFcn(hObject, eventdata, handles)
% hObject    handle to KRD5Text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function KRD10Text_CreateFcn(hObject, eventdata, handles)
% hObject    handle to KRD10Text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function KRD30Text_CreateFcn(hObject, eventdata, handles)
% hObject    handle to KRD30Text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function yieldText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to yieldText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function spreadText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to spreadText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function BenchmarkText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to benchmarkText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function PortfolioText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to portfolioText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function maximumText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to maximumText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function minimumText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to minimumText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function deviationText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to deviationText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function constraintText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to constraintText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function constraintWeightCheck_CreateFcn(hObject, eventdata, handles)
% hObject    handle to constraintWeightCheck (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function constraintDurationCheck_CreateFcn(hObject, eventdata, handles)
% hObject    handle to constraintDurationCheck (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function constraintKRDCheck_CreateFcn(hObject, eventdata, handles)
% hObject    handle to constraintKRDCheck (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function constraintYieldCheck_CreateFcn(hObject, eventdata, handles)
% hObject    handle to constraintYieldCheck (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function constraintSpreadCheck_CreateFcn(hObject, eventdata, handles)
% hObject    handle to constraintSpreadCheck (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function securityOptimizationPanel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to securityOptimizationPanel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function nCombinationsText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to nCombinationsText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function nRepetitionsText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to nRepetitionsText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function carryOverText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to carryOverText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function mutationText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to mutationText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function crossoverText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to crossoverText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function groupingTable_CreateFcn(hObject, eventdata, handles)
% hObject    handle to groupingTable (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% --- Executes during object creation, after setting all properties.
function groupByText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to groupByText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function typeText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to typeText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function bucketingTable_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bucketingTable (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function groupByBucketingText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to groupByBucketingText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function constraintBucketingText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to constraintBucketingText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% --- Executes during object creation, after setting all properties.
function groupingBucketingText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to groupingBucketingText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function bucketingText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bucketingText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function nSecuritiesPanel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to nSecuritiesPanel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function portfolioText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to portfoliotext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function outBenchText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to outBenchText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function benchText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to benchmarkText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function excludeOutBMCheck_CreateFcn(hObject, eventdata, handles)
% hObject    handle to excludeOutBMCheck (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function securitiesOutText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to securitiesOutText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function securitiesToModelText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to maximumText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function groupingConstraintsTable_CreateFcn(hObject, eventdata, handles)
% hObject    handle to groupingConstraintsTable (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function deviationGroupingText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to deviationText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function bucketingConstraintsTable_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bucketingConstraintsTable (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function maxDeviationBucketingText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to maxDeviationBucketingText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns calle

% --- Executes during object creation, after setting all properties.
function importFilesButton_CreateFcn(hObject, eventdata, handles)
% hObject    handle to importFilesButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function filterButton_CreateFcn(hObject, eventdata, handles)
% hObject    handle to filterButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function optimizePortfolioButton_CreateFcn(hObject, eventdata, handles)
% hObject    handle to optimizePortfolioButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function resultsPanel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultsPanel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function resultsTable_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultsTable (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function savedTable_CreateFcn(hObject, eventdata, handles)
% hObject    handle to savedTable (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function appendButton_CreateFcn(hObject, eventdata, handles)
% hObject    handle to appendButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function clearButton_CreateFcn(hObject, eventdata, handles)
% hObject    handle to removeFunctionButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function exportButton_CreateFcn(hObject, eventdata, handles)
% hObject    handle to exportButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function optimizationResultsText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to optimizationResultsText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function savedResultsText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to savedResultsText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function filterDataPanel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to filterDataPanel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function selectedFieldsTable_CreateFcn(hObject, eventdata, handles)
% hObject    handle to selectedFieldsTable (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function sortByPanel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sortByPanel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function sortByText1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sortByText1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function sortByText2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sortByText2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function sortByText3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sortByText3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function filterPanel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to filterPanel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function equalsText1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to equalsText1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function filterText1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to filterText1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function equalsText2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to equalsText2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function filterText2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to filterText2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function applyButton_CreateFcn(hObject, eventdata, handles)
% hObject    handle to applyButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function continue2Button_CreateFcn(hObject, eventdata, handles)
% hObject    handle to continue2Button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function importedDataPanel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to importedDataPanel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function importedBenchmarkTable_CreateFcn(hObject, eventdata, handles)
% hObject    handle to importedBenchmarkTable (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function importedPortfolioTable_CreateFcn(hObject, eventdata, handles)
% hObject    handle to importedPortfolioTable (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function continue1Button_CreateFcn(hObject, eventdata, handles)
% hObject    handle to continue1Button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function importedFileConfigurationPanel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to importedFileConfigurationPanel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function spreadColumnText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to spreadColumnText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function ISINColumnText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ISINColumnText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function maturityColumnText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to maturityColumnText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function KDR5YColumnText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to KDR5YColumnText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function KDR2YColumnText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to KDR2YColumnText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function KDR05YColumnText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to KDR05YColumnText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function KDR30YColumnText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to KDR30YColumnText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function KDR20YColumnText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to KDR20YColumnText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function KDR10YColumnText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to KDR10YColumnText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function weightColumnText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to weightColumnText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function durationColumnText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to durationColumnText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function yieldColumnText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to yieldColumnText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function additionalParametersPanel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to additionalParametersPanel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function filterFieldsText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to filterFieldsText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function weightsTable_CreateFcn(hObject, eventdata, handles)
% hObject    handle to weightsTable (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function currentPortfolioSizeText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to currentPortfolioSizeText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function benchmarkText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to benchmarktext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function downloadBloombergDataButton_CreateFcn(hObject, eventdata, handles)
% hObject    handle to downloadBloombergDataButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function resultsButton_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultsButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function importButton_CreateFcn(hObject, eventdata, handles)
% hObject    handle to importButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called



function totalNumberOfSecuritiesBox_Callback(hObject, eventdata, handles)
% hObject    handle to totalNumberOfSecuritiesBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of totalNumberOfSecuritiesBox as text
%        str2double(get(hObject,'String')) returns contents of totalNumberOfSecuritiesBox as a double


% --- Executes during object creation, after setting all properties.
function totalNumberOfSecuritiesBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to totalNumberOfSecuritiesBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in includeOnlyPortfolioSecuritiesCheck.
function includeOnlyPortfolioSecuritiesCheck_Callback(hObject, eventdata, handles)
% hObject    handle to includeOnlyPortfolioSecuritiesCheck (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of includeOnlyPortfolioSecuritiesCheck

% --- Executes during object creation, after setting all properties.
function nBucketsBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to nBucketsBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function resultBenchWeightBox_Callback(hObject, eventdata, handles)
% hObject    handle to resultBenchWeightBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resultBenchWeightBox as text
%        str2double(get(hObject,'String')) returns contents of resultBenchWeightBox as a double


% --- Executes during object creation, after setting all properties.
function resultBenchWeightBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultBenchWeightBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function resultBenchDurationBox_Callback(hObject, eventdata, handles)
% hObject    handle to resultBenchDurationBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resultBenchDurationBox as text
%        str2double(get(hObject,'String')) returns contents of resultBenchDurationBox as a double


% --- Executes during object creation, after setting all properties.
function resultBenchDurationBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultBenchDurationBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function resultBenchKRD2Box_Callback(hObject, eventdata, handles)
% hObject    handle to resultBenchKRD2Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resultBenchKRD2Box as text
%        str2double(get(hObject,'String')) returns contents of resultBenchKRD2Box as a double


% --- Executes during object creation, after setting all properties.
function resultBenchKRD2Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultBenchKRD2Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function resultBenchKRD5Box_Callback(hObject, eventdata, handles)
% hObject    handle to resultBenchKRD5Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resultBenchKRD5Box as text
%        str2double(get(hObject,'String')) returns contents of resultBenchKRD5Box as a double


% --- Executes during object creation, after setting all properties.
function resultBenchKRD5Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultBenchKRD5Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function resultBenchKRD10Box_Callback(hObject, eventdata, handles)
% hObject    handle to resultBenchKRD10Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resultBenchKRD10Box as text
%        str2double(get(hObject,'String')) returns contents of resultBenchKRD10Box as a double


% --- Executes during object creation, after setting all properties.
function resultBenchKRD10Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultBenchKRD10Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function resultBenchKRD20Box_Callback(hObject, eventdata, handles)
% hObject    handle to resultBenchKRD20Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resultBenchKRD20Box as text
%        str2double(get(hObject,'String')) returns contents of resultBenchKRD20Box as a double


% --- Executes during object creation, after setting all properties.
function resultBenchKRD20Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultBenchKRD20Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function resultBenchYieldBox_Callback(hObject, eventdata, handles)
% hObject    handle to resultBenchYieldBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resultBenchYieldBox as text
%        str2double(get(hObject,'String')) returns contents of resultBenchYieldBox as a double


% --- Executes during object creation, after setting all properties.
function resultBenchYieldBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultBenchYieldBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function resultBenchSpreadBox_Callback(hObject, eventdata, handles)
% hObject    handle to resultBenchSpreadBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resultBenchSpreadBox as text
%        str2double(get(hObject,'String')) returns contents of resultBenchSpreadBox as a double


% --- Executes during object creation, after setting all properties.
function resultBenchSpreadBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultBenchSpreadBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function resultOrigPortWeightBox_Callback(hObject, eventdata, handles)
% hObject    handle to resultOrigPortWeightBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resultOrigPortWeightBox as text
%        str2double(get(hObject,'String')) returns contents of resultOrigPortWeightBox as a double


% --- Executes during object creation, after setting all properties.
function resultOrigPortWeightBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultOrigPortWeightBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function resultOrigPortDurationBox_Callback(hObject, eventdata, handles)
% hObject    handle to resultOrigPortDurationBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resultOrigPortDurationBox as text
%        str2double(get(hObject,'String')) returns contents of resultOrigPortDurationBox as a double


% --- Executes during object creation, after setting all properties.
function resultOrigPortDurationBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultOrigPortDurationBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function resultOrigPortKRD2Box_Callback(hObject, eventdata, handles)
% hObject    handle to resultOrigPortKRD2Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resultOrigPortKRD2Box as text
%        str2double(get(hObject,'String')) returns contents of resultOrigPortKRD2Box as a double


% --- Executes during object creation, after setting all properties.
function resultOrigPortKRD2Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultOrigPortKRD2Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function resultOrigPortKRD5Box_Callback(hObject, eventdata, handles)
% hObject    handle to resultOrigPortKRD5Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resultOrigPortKRD5Box as text
%        str2double(get(hObject,'String')) returns contents of resultOrigPortKRD5Box as a double


% --- Executes during object creation, after setting all properties.
function resultOrigPortKRD5Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultOrigPortKRD5Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function resultOrigPortKRD10Box_Callback(hObject, eventdata, handles)
% hObject    handle to resultOrigPortKRD10Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resultOrigPortKRD10Box as text
%        str2double(get(hObject,'String')) returns contents of resultOrigPortKRD10Box as a double


% --- Executes during object creation, after setting all properties.
function resultOrigPortKRD10Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultOrigPortKRD10Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function resultOrigPortKRD20Box_Callback(hObject, eventdata, handles)
% hObject    handle to resultOrigPortKRD20Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resultOrigPortKRD20Box as text
%        str2double(get(hObject,'String')) returns contents of resultOrigPortKRD20Box as a double


% --- Executes during object creation, after setting all properties.
function resultOrigPortKRD20Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultOrigPortKRD20Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function resultOrigPortYieldBox_Callback(hObject, eventdata, handles)
% hObject    handle to resultOrigPortYieldBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resultOrigPortYieldBox as text
%        str2double(get(hObject,'String')) returns contents of resultOrigPortYieldBox as a double


% --- Executes during object creation, after setting all properties.
function resultOrigPortYieldBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultOrigPortYieldBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function resultOrigPortSpreadBox_Callback(hObject, eventdata, handles)
% hObject    handle to resultOrigPortSpreadBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resultOrigPortSpreadBox as text
%        str2double(get(hObject,'String')) returns contents of resultOrigPortSpreadBox as a double


% --- Executes during object creation, after setting all properties.
function resultOrigPortSpreadBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultOrigPortSpreadBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function resultNewPortWeightBox_Callback(hObject, eventdata, handles)
% hObject    handle to resultNewPortWeightBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resultNewPortWeightBox as text
%        str2double(get(hObject,'String')) returns contents of resultNewPortWeightBox as a double


% --- Executes during object creation, after setting all properties.
function resultNewPortWeightBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultNewPortWeightBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function resultNewPortDurationBox_Callback(hObject, eventdata, handles)
% hObject    handle to resultNewPortDurationBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resultNewPortDurationBox as text
%        str2double(get(hObject,'String')) returns contents of resultNewPortDurationBox as a double


% --- Executes during object creation, after setting all properties.
function resultNewPortDurationBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultNewPortDurationBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function resultNewPortKRD2Box_Callback(hObject, eventdata, handles)
% hObject    handle to resultNewPortKRD2Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resultNewPortKRD2Box as text
%        str2double(get(hObject,'String')) returns contents of resultNewPortKRD2Box as a double


% --- Executes during object creation, after setting all properties.
function resultNewPortKRD2Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultNewPortKRD2Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function resultNewPortKRD5Box_Callback(hObject, eventdata, handles)
% hObject    handle to resultNewPortKRD5Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resultNewPortKRD5Box as text
%        str2double(get(hObject,'String')) returns contents of resultNewPortKRD5Box as a double


% --- Executes during object creation, after setting all properties.
function resultNewPortKRD5Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultNewPortKRD5Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function resultNewPortKRD10Box_Callback(hObject, eventdata, handles)
% hObject    handle to resultNewPortKRD10Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resultNewPortKRD10Box as text
%        str2double(get(hObject,'String')) returns contents of resultNewPortKRD10Box as a double


% --- Executes during object creation, after setting all properties.
function resultNewPortKRD10Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultNewPortKRD10Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function resultNewPortKRD20Box_Callback(hObject, eventdata, handles)
% hObject    handle to resultNewPortKRD20Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resultNewPortKRD20Box as text
%        str2double(get(hObject,'String')) returns contents of resultNewPortKRD20Box as a double


% --- Executes during object creation, after setting all properties.
function resultNewPortKRD20Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultNewPortKRD20Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function resultNewPortYieldBox_Callback(hObject, eventdata, handles)
% hObject    handle to resultNewPortYieldBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resultNewPortYieldBox as text
%        str2double(get(hObject,'String')) returns contents of resultNewPortYieldBox as a double


% --- Executes during object creation, after setting all properties.
function resultNewPortYieldBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultNewPortYieldBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function resultNewPortSpreadBox_Callback(hObject, eventdata, handles)
% hObject    handle to resultNewPortSpreadBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resultNewPortSpreadBox as text
%        str2double(get(hObject,'String')) returns contents of resultNewPortSpreadBox as a double


% --- Executes during object creation, after setting all properties.
function resultNewPortSpreadBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultNewPortSpreadBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes during object creation, after setting all properties.
function groupingBucketingPopup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to groupingBucketingPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function resultGroupByPopup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultGroupByPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function resultNBucketsBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultNBucketsBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in GIM2SymbolColumnPopup.
function GIM2SymbolColumnPopup_Callback(hObject, eventdata, handles)
% hObject    handle to GIM2SymbolColumnPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns GIM2SymbolColumnPopup contents as cell array
%        contents{get(hObject,'Value')} returns selected item from GIM2SymbolColumnPopup


% --- Executes during object creation, after setting all properties.
function GIM2SymbolColumnPopup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to GIM2SymbolColumnPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function newPortfolioSizeBox_Callback(hObject, eventdata, handles)
% hObject    handle to newPortfolioSizeBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of newPortfolioSizeBox as text
%        str2double(get(hObject,'String')) returns contents of newPortfolioSizeBox as a double


% --- Executes during object creation, after setting all properties.
function newPortfolioSizeBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to newPortfolioSizeBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in buyCheckbox.
function buyCheckbox_Callback(hObject, eventdata, handles)
% hObject    handle to buyCheckbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of buyCheckbox


% --- Executes on button press in sellCheckbox.
function sellCheckbox_Callback(hObject, eventdata, handles)
% hObject    handle to sellCheckbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of sellCheckbox



function nMinSecuritiesBox_Callback(hObject, eventdata, handles)
% hObject    handle to nMinSecuritiesBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of nMinSecuritiesBox as text
%        str2double(get(hObject,'String')) returns contents of nMinSecuritiesBox as a double


% --- Executes during object creation, after setting all properties.
function nMinSecuritiesBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to nMinSecuritiesBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in minimizeGroupWeightCheck.
function minimizeGroupWeightCheck_Callback(hObject, eventdata, handles)

function minimizeGroupDurationCheck_Callback(hObject, eventdata, handles)
% hObject    handle to minimizeGroupDurationCheck (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of minimizeGroupDurationCheck


% --- Executes on button press in minimizeGroupKRDCheck.
function minimizeGroupKRDCheck_Callback(hObject, eventdata, handles)
% hObject    handle to minimizeGroupKRDCheck (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of minimizeGroupKRDCheck


% --- Executes on button press in minimizeGroupYieldCheck.
function minimizeGroupYieldCheck_Callback(hObject, eventdata, handles)
% hObject    handle to minimizeGroupYieldCheck (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of minimizeGroupYieldCheck


% --- Executes on button press in minimizeGroupSpreadCheck.
function minimizeGroupSpreadCheck_Callback(hObject, eventdata, handles)
% hObject    handle to minimizeGroupSpreadCheck (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of minimizeGroupSpreadCheck

% --- Executes during object creation, after setting all properties.
function groupLevelGroupingPopup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to groupLevelGroupingPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on selection change in usedFunctionsList.
function usedFunctionsList_Callback(hObject, eventdata, handles)
% hObject    handle to usedFunctionsList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns usedFunctionsList contents as cell array
%        contents{get(hObject,'Value')} returns selected item from usedFunctionsList


% --- Executes during object creation, after setting all properties.
function usedFunctionsList_CreateFcn(hObject, eventdata, handles)
% hObject    handle to usedFunctionsList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in removeFunctionButton.
function pushbutton35_Callback(hObject, eventdata, handles)
% hObject    handle to removeFunctionButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function removeFunctionButton_CreateFcn(hObject, eventdata, handles)
% hObject    handle to removeFunctionButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% --- Executes during object creation, after setting all properties.
function groupOptimizationCharacteristicPopup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to groupOptimizationCharacteristicPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function minimumAmountBox_Callback(hObject, eventdata, handles)
% hObject    handle to minimumAmountBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of minimumAmountBox as text
%        str2double(get(hObject,'String')) returns contents of minimumAmountBox as a double


% --- Executes during object creation, after setting all properties.
function minimumAmountBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to minimumAmountBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in currencyColumnPopup.
function currencyColumnPopup_Callback(hObject, eventdata, handles)
% hObject    handle to currencyColumnPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns currencyColumnPopup contents as cell array
%        contents{get(hObject,'Value')} returns selected item from currencyColumnPopup


% --- Executes during object creation, after setting all properties.
function currencyColumnPopup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to currencyColumnPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in excludeTickersOutOfBenchmarkCheck.
function excludeTickersOutOfBenchmarkCheck_Callback(hObject, eventdata, handles)
% hObject    handle to excludeTickersOutOfBenchmarkCheck (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of excludeTickersOutOfBenchmarkCheck


% --- Executes on selection change in tickerColumnPopup.
function tickerColumnPopup_Callback(hObject, eventdata, handles)
% hObject    handle to tickerColumnPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns tickerColumnPopup contents as cell array
%        contents{get(hObject,'Value')} returns selected item from tickerColumnPopup


% --- Executes during object creation, after setting all properties.
function tickerColumnPopup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tickerColumnPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function weightBox_Callback(hObject, eventdata, handles)
% hObject    handle to weightBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of weightBox as text
%        str2double(get(hObject,'String')) returns contents of weightBox as a double
set(handles.WeightAutoOnOff,'Value',1);
handles.WeightAutoOnOffVar=1;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function weightBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to weightBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function constraintsList_CreateFcn(hObject, eventdata, handles)
% hObject    handle to constraintsList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in availableFunctionsList.
function availableFunctionsList_Callback(hObject, eventdata, handles)
% hObject    handle to availableFunctionsList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns availableFunctionsList contents as cell array
%        contents{get(hObject,'Value')} returns selected item from availableFunctionsList


% --- Executes during object creation, after setting all properties.
function availableFunctionsList_CreateFcn(hObject, eventdata, handles)
% hObject    handle to availableFunctionsList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function optimizePopup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to optimizePopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function parameterPopup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to parameterPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in groupedByPopup.
function groupedByPopup_Callback(hObject, eventdata, handles)
% hObject    handle to groupedByPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns groupedByPopup contents as cell array
%        contents{get(hObject,'Value')} returns selected item from groupedByPopup
%optimizePopup_Callback(hObject, eventdata, handles);
%guidata(hObject, handles);
    

% --- Executes during object creation, after setting all properties.
function groupedByPopup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to groupedByPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function resultParameterPopup_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultParameterPopup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function maxTradeBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to maxTradeBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over importButton.
function importButton_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to importButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in ChooseSolver.
function ChooseSolver_Callback(hObject, eventdata, handles)
% hObject    handle to ChooseSolver (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns ChooseSolver contents as cell array
%        contents{get(hObject,'Value')} returns selected item from ChooseSolver
vt=get(handles.ChooseSolver, 'Value');
set(handles.ChooseSolver,'value',vt);
guidata(hObject, handles);
    
% --- Executes during object creation, after setting all properties.
function ChooseSolver_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ChooseSolver (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in LiquidityCalcType.
function LiquidityCalcType_Callback(hObject, eventdata, handles)
% hObject    handle to LiquidityCalcType (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of LiquidityCalcType
vt=get(handles.LiquidityCalcType, 'Value');
set(handles.LiquidityCalcType,'value',vt);
guidata(hObject, handles);


% --- Executes on selection change in OptiPanelMinSizeType.
function OptiPanelMinSizeType_Callback(hObject, eventdata, handles)
% hObject    handle to OptiPanelMinSizeType (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns OptiPanelMinSizeType contents as cell array
%        contents{get(hObject,'Value')} returns selected item from OptiPanelMinSizeType


% --- Executes during object creation, after setting all properties.
function OptiPanelMinSizeType_CreateFcn(hObject, eventdata, handles)
% hObject    handle to OptiPanelMinSizeType (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in OptiSelectAllCons.
function OptiSelectAllCons_Callback(hObject, eventdata, handles)
% hObject    handle to OptiSelectAllCons (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of OptiSelectAllCons
 handles = Optimize.GroupData(handles, 'Constraint');
 guidata(hObject,handles)



function MinConstraintAll_Callback(hObject, eventdata, handles)
% hObject    handle to MinConstraintAll (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of MinConstraintAll as text
%        str2double(get(hObject,'String')) returns contents of MinConstraintAll as a double
 handles = Optimize.GroupData(handles, 'Constraint');
 guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function MinConstraintAll_CreateFcn(hObject, eventdata, handles)
% hObject    handle to MinConstraintAll (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function MaxConstraintAll_Callback(hObject, eventdata, handles)
% hObject    handle to MaxConstraintAll (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of MaxConstraintAll as text
%        str2double(get(hObject,'String')) returns contents of MaxConstraintAll as a double
 handles = Optimize.GroupData(handles, 'Constraint');
 guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function MaxConstraintAll_CreateFcn(hObject, eventdata, handles)
% hObject    handle to MaxConstraintAll (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function portDTSBox_Callback(hObject, eventdata, handles)
% hObject    handle to portDTSBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of portDTSBox as text
%        str2double(get(hObject,'String')) returns contents of portDTSBox as a double


% --- Executes during object creation, after setting all properties.
function portDTSBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to portDTSBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function maxDTSBox_Callback(hObject, eventdata, handles)
% hObject    handle to maxDTSBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of maxDTSBox as text
%        str2double(get(hObject,'String')) returns contents of maxDTSBox as a double


% --- Executes during object creation, after setting all properties.
function maxDTSBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to maxDTSBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function minDTSBox_Callback(hObject, eventdata, handles)
% hObject    handle to minDTSBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of minDTSBox as text
%        str2double(get(hObject,'String')) returns contents of minDTSBox as a double


% --- Executes during object creation, after setting all properties.
function minDTSBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to minDTSBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





% --- Executes during object creation, after setting all properties.
function deviationDTSBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to deviationDTSBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function benchDTSBox_Callback(hObject, eventdata, handles)
% hObject    handle to benchDTSBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of benchDTSBox as text
%        str2double(get(hObject,'String')) returns contents of benchDTSBox as a double


% --- Executes during object creation, after setting all properties.
function benchDTSBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to benchDTSBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in constraintDTSCheck.
function constraintDTSCheck_Callback(hObject, eventdata, handles)
% hObject    handle to constraintDTSCheck (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of constraintDTSCheck



function resultBenchDTSBox_Callback(hObject, eventdata, handles)
% hObject    handle to resultBenchDTSBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resultBenchDTSBox as text
%        str2double(get(hObject,'String')) returns contents of resultBenchDTSBox as a double


% --- Executes during object creation, after setting all properties.
function resultBenchDTSBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultBenchDTSBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function resultOrigPortDTSBox_Callback(hObject, eventdata, handles)
% hObject    handle to resultOrigPortDTSBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resultOrigPortDTSBox as text
%        str2double(get(hObject,'String')) returns contents of resultOrigPortDTSBox as a double


% --- Executes during object creation, after setting all properties.
function resultOrigPortDTSBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultOrigPortDTSBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function resultNewPortDTSBox_Callback(hObject, eventdata, handles)
% hObject    handle to resultNewPortDTSBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resultNewPortDTSBox as text
%        str2double(get(hObject,'String')) returns contents of resultNewPortDTSBox as a double


% --- Executes during object creation, after setting all properties.
function resultNewPortDTSBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultNewPortDTSBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ResultsRounding_Callback(hObject, eventdata, handles)
% hObject    handle to ResultsRounding (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ResultsRounding as text
%        str2double(get(hObject,'String')) returns contents of ResultsRounding as a double


% --- Executes during object creation, after setting all properties.
function ResultsRounding_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ResultsRounding (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in AfterTaxYield.
function AfterTaxYield_Callback(hObject, eventdata, handles)
% hObject    handle to AfterTaxYield (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of AfterTaxYield


% --- Executes on button press in aggsimnames.
function aggsimnames_Callback(hObject, eventdata, handles)
% hObject    handle to aggsimnames (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of aggsimnames



function benchKRD30Box_Callback(hObject, eventdata, handles)
% hObject    handle to benchKRD30Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of benchKRD30Box as text
%        str2double(get(hObject,'String')) returns contents of benchKRD30Box as a double


% --- Executes during object creation, after setting all properties.
function benchKRD30Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to benchKRD30Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function portKRD30Box_Callback(hObject, eventdata, handles)
% hObject    handle to portKRD30Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of portKRD30Box as text
%        str2double(get(hObject,'String')) returns contents of portKRD30Box as a double


% --- Executes during object creation, after setting all properties.
function portKRD30Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to portKRD30Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function maxKRD30Box_Callback(hObject, eventdata, handles)
% hObject    handle to maxKRD30Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of maxKRD30Box as text
%        str2double(get(hObject,'String')) returns contents of maxKRD30Box as a double


% --- Executes during object creation, after setting all properties.
function maxKRD30Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to maxKRD30Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function minKRD30Box_Callback(hObject, eventdata, handles)
% hObject    handle to minKRD30Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of minKRD30Box as text
%        str2double(get(hObject,'String')) returns contents of minKRD30Box as a double


% --- Executes during object creation, after setting all properties.
function minKRD30Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to minKRD30Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function deviationKRD30Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to deviationKRD30Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function resultBenchKRD30Box_Callback(hObject, eventdata, handles)
% hObject    handle to resultBenchKRD30Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resultBenchKRD30Box as text
%        str2double(get(hObject,'String')) returns contents of resultBenchKRD30Box as a double


% --- Executes during object creation, after setting all properties.
function resultBenchKRD30Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultBenchKRD30Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function resultOrigPortKRD30Box_Callback(hObject, eventdata, handles)
% hObject    handle to resultOrigPortKRD30Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resultOrigPortKRD30Box as text
%        str2double(get(hObject,'String')) returns contents of resultOrigPortKRD30Box as a double


% --- Executes during object creation, after setting all properties.
function resultOrigPortKRD30Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultOrigPortKRD30Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function resultNewPortKRD30Box_Callback(hObject, eventdata, handles)
% hObject    handle to resultNewPortKRD30Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of resultNewPortKRD30Box as text
%        str2double(get(hObject,'String')) returns contents of resultNewPortKRD30Box as a double


% --- Executes during object creation, after setting all properties.
function resultNewPortKRD30Box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to resultNewPortKRD30Box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in KRD2030Check.
function KRD2030Check_Callback(hObject, eventdata, handles)
% hObject    handle to KRD2030Check (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of KRD2030Check


% --- Executes on button press in KRD0510Check.
function KRD0510Check_Callback(hObject, eventdata, handles)
% hObject    handle to KRD0510Check (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of KRD0510Check



function KRD2030_Callback(hObject, eventdata, handles)
% hObject    handle to KRD2030 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of KRD2030 as text
%        str2double(get(hObject,'String')) returns contents of KRD2030 as a double
ValueB=get(handles.KRD2030,'String');
set(handles.KRD2030, 'String', sprintf('%.3f', str2double(ValueB)));
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function KRD2030_CreateFcn(hObject, eventdata, handles)
% hObject    handle to KRD2030 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function KRD0510_Callback(hObject, eventdata, handles)
% hObject    handle to KRD0510 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of KRD0510 as text
%        str2double(get(hObject,'String')) returns contents of KRD0510 as a double
ValueB=get(handles.KRD0510,'String');
set(handles.KRD0510, 'String', sprintf('%.3f', str2double(ValueB)));
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function KRD0510_CreateFcn(hObject, eventdata, handles)
% hObject    handle to KRD0510 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function SolverTime_Callback(hObject, eventdata, handles)
% hObject    handle to SolverTime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of SolverTime as text
%        str2double(get(hObject,'String')) returns contents of SolverTime as a double
ValueB=get(handles.SolverTime,'String');
handles.SolverMaxTime=str2double(ValueB);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function SolverTime_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SolverTime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in PortfolioList.
function PortfolioList_Callback(hObject, eventdata, handles)
% hObject    handle to PortfolioList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns PortfolioList contents as cell array
%        contents{get(hObject,'Value')} returns selected item from PortfolioList


% --- Executes during object creation, after setting all properties.
function PortfolioList_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PortfolioList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





% --- Executes on button press in AddMultipleConstraints.
function AddMultipleConstraints_Callback(hObject, eventdata, handles)
% hObject    handle to AddMultipleConstraints (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% Step 1 Save the data a display it
%% Step 2 go through the constraint tables
%% compare them and for each ticker enter the correct constraints
%% give a list of added and removed fields
%% call add constraint function

constraintsTable=get(handles.groupingTable,'Data');
if (handles.OptiConstraints.NoOfConstraints==0)
ListofCons=[];
else
ListofCons=get(handles.constraintsList, 'String');
end
if isempty(constraintsTable)
        errordlg('No Group Constraints To Add');
        error('No Group Constraints To Add'); 
else
    
 maxPortfolioWeight = str2double(strrep(get(handles.maxWeightBox, 'String'), '%', '')) / 100 + 0.00001;
 minPortfolioWeight = str2double(strrep(get(handles.minWeightBox, 'String'), '%', '')) / 100 - 0.00001;
 benchWeightBox =str2double(strrep(get(handles.benchWeightBox, 'String'), '%', '')) / 100 - 0.00001;
handles.OptiConstraints.maxWDev=[-maxPortfolioWeight+benchWeightBox];
handles.OptiConstraints.minWDev=[-minPortfolioWeight+benchWeightBox];



handles.OptiConstraints.NoOfConstraints=handles.OptiConstraints.NoOfConstraints+1;
handles.OptiConstraints.InputTable=[handles.OptiConstraints.InputTable {get(handles.groupingTable,'Data')}];
handles.OptiConstraints.groupingTypePopupID=[handles.OptiConstraints.groupingTypePopupID get(handles.groupingTypePopup, 'Value') - 1];
TSt1=get(handles.groupingTypePopup, 'String');
TSt1=TSt1(get(handles.groupingTypePopup, 'Value'));
handles.OptiConstraints.groupingTypePopupName=[handles.OptiConstraints.groupingTypePopupName {TSt1}];
handles.OptiConstraints.groupColumnID = [handles.OptiConstraints.groupColumnID get(handles.groupByPopup, 'Value') - 1];
TSt1=get(handles.groupByPopup, 'String');
TSt1=TSt1(get(handles.groupByPopup, 'Value'));
handles.OptiConstraints.groupColumnName = [handles.OptiConstraints.groupColumnName {TSt1}];
handles.OptiConstraints.parameterColumnID = [handles.OptiConstraints.parameterColumnID get(handles.parameterPopup, 'Value') - 1];
TSt1=get(handles.parameterPopup, 'String');
TSt1=TSt1(get(handles.parameterPopup, 'Value'));
handles.OptiConstraints.parameterColumnName =[handles.OptiConstraints.parameterColumnName {TSt1}];
handles.OptiConstraints.deviation_string = [handles.OptiConstraints.deviation_string {(get(handles.deviationBox, 'String'))}];
handles.OptiConstraints.maxDeviation_string =[handles.OptiConstraints.maxDeviation_string {(get(handles.maxDeviationBox, 'String'))}];
handles.OptiConstraints.nBuckets_string =[handles.OptiConstraints.nBuckets_string {get(handles.nBucketsBox, 'String')}];
handles.OptiConstraints.minAllValue =[handles.OptiConstraints.minAllValue {(get(handles.MinConstraintAll, 'String'))}];
handles.OptiConstraints.maxAllValue =[handles.OptiConstraints.maxAllValue {(get(handles.MaxConstraintAll, 'String'))}];
handles.OptiConstraints.OptiSelectAllCons=[handles.OptiConstraints.OptiSelectAllCons get(handles.OptiSelectAllCons, 'Value')];


 

%% Create Constraint Text
Type_No=get(handles.groupingTypePopup, 'Value');
Type_List=get(handles.groupingTypePopup, 'String');
S1=Type_List(Type_No,:);
Group_No=get(handles.groupByPopup, 'Value');
Group_List=get(handles.groupByPopup, 'String');
S2=Group_List(Group_No,:);
Para_No=get(handles.parameterPopup, 'Value');
Para_List=get(handles.parameterPopup, 'String');
S3=Para_List(Para_No,:);
Cons_String=['C-' num2str(handles.OptiConstraints.NoOfConstraints) '|T-' S1{:} '|G-' S2{:} '|P-' S3{:}];
ListofCons=[ListofCons;{Cons_String}];
set(handles.constraintsList, 'String',ListofCons);
%get(handles.groupingTypePopup, 'String') ' P' get(handles.groupingTypePopup, 'String')] 
end
set(handles.constraintsList,'Value',size(get(handles.constraintsList,'String'),1));
constraintsList_Callback(hObject, eventdata, handles);
guidata(hObject, handles); 

%handles=CheckConstraints(hObject, handles);
%mk=handles.OptiConstraints.InputTable(1)
%mk{:}
%handles.OptiConstraints.InputTable(1)
%mk{:}

% --- Executes on button press in DeleteConstraint.
function DeleteConstraint_Callback(hObject, eventdata, handles)
% hObject    handle to DeleteConstraint (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Cons_Del_No=get(handles.constraintsList,'Value');
kk=Cons_Del_No;
Disp_String=[];
initial_no_of_constraints=handles.OptiConstraints.NoOfConstraints;

if initial_no_of_constraints>=1
    handles.OptiConstraints.NoOfConstraints=handles.OptiConstraints.NoOfConstraints-1;
    handles.OptiConstraints.InputTable(kk)=[];
    handles.OptiConstraints.groupingTypePopupID(kk)=[];
    handles.OptiConstraints.groupingTypePopupName(kk)=[];
    handles.OptiConstraints.groupColumnID(kk)=[];
    handles.OptiConstraints.groupColumnName(kk)=[];
    handles.OptiConstraints.parameterColumnID(kk)=[];
    handles.OptiConstraints.parameterColumnName(kk)=[];
    handles.OptiConstraints.deviation_string(kk)=[];
    handles.OptiConstraints.maxDeviation_string(kk)=[];
    handles.OptiConstraints.nBuckets_string(kk)=[];
    handles.OptiConstraints.minAllValue(kk)=[];
    handles.OptiConstraints.maxAllValue(kk)=[];
    handles.OptiConstraints.OptiSelectAllCons(kk)=[];
else
   h = msgbox('No Constraint To Delete', 'Constraint','error');
end

if (initial_no_of_constraints<=1)
    Disp_String='Add Constraints';
else
    for kks=1:1:handles.OptiConstraints.NoOfConstraints
        Type_Name=handles.OptiConstraints.groupingTypePopupName(kks);
        S1=Type_Name{:};
        Group_Name= handles.OptiConstraints.groupColumnName(kks);
        S2=Group_Name{:};
        Para_Name=handles.OptiConstraints.parameterColumnName(kks);
        S3=Para_Name{:};
        Cons_String=['C-' num2str(kks) '|T-' S1{:} '|G-' S2{:} '|P-' S3{:}];
        Disp_String=[Disp_String;{Cons_String}];
    end;
end;
if Cons_Del_No>1
    set(handles.constraintsList, 'Value',Cons_Del_No-1);
else
    set(handles.constraintsList, 'Value',1);
end
set(handles.constraintsList, 'String',Disp_String);
constraintsList_Callback(hObject, eventdata, handles);
guidata(hObject, handles);

% --- Executes on button press in CheckConstraintList.
function CheckConstraintList_Callback(hObject, eventdata, handles)
% hObject    handle to CheckConstraintList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%%handles.OptiConstraints
handles.ApplyConst=0;
handles=CheckConstraints(hObject, handles);
guidata(hObject, handles);

function handles=CheckConstraints(hObject, handles);
if handles.OptiConstraints.NoOfConstraints>=1
for kk=1:1:handles.OptiConstraints.NoOfConstraints  
    % %InputTable=handles.OptiConstraints.InputTable(kk,1)
    set(handles.constraintsList,'Value',kk);
    groupingTypePopupID=handles.OptiConstraints.groupingTypePopupID(kk);
    set(handles.groupingTypePopup,'Value',groupingTypePopupID+1);
    groupingTypePopupName=handles.OptiConstraints.groupingTypePopupName(kk);
    
    groupColumnID =handles.OptiConstraints.groupColumnID(kk);
    set(handles.groupByPopup,'Value',groupColumnID+1);
    groupColumnName = handles.OptiConstraints.groupColumnName(kk);
    
    parameterColumnID = handles.OptiConstraints.parameterColumnID(kk);
    set(handles.parameterPopup,'Value',parameterColumnID+1);
    parameterColumnName =handles.OptiConstraints.parameterColumnName(kk);
    
    deviation_string = handles.OptiConstraints.deviation_string(kk);
    set(handles.deviationBox,'String',deviation_string{:});
    
    maxDeviation_string =handles.OptiConstraints.maxDeviation_string(kk);
    set(handles.maxDeviationBox,'String',maxDeviation_string{:});
    
    nBuckets_string =handles.OptiConstraints.nBuckets_string(kk);
    set(handles.nBucketsBox,'String',nBuckets_string{:});
    
    minAllValue =handles.OptiConstraints.minAllValue(kk);
    set(handles.MinConstraintAll,'String',minAllValue{:});
    
    maxAllValue =handles.OptiConstraints.maxAllValue(kk);
    set(handles.MaxConstraintAll,'String',maxAllValue{:});
    
    OptiSelectAllCons=handles.OptiConstraints.OptiSelectAllCons(kk);
    set(handles.OptiSelectAllCons,'Value',OptiSelectAllCons);
    
    T_Data=handles.OptiConstraints.InputTable(kk);
    handles = Optimize.GroupData(handles, 'Constraint'); %% Only to set the formatting of the table to the correct
    %set(handles.groupingTable,'Data',T_Data{:});
    
    %% Compare the leftmost column of the two tables
    T_OldData=T_Data{:};
    %T_OldData(2,:)=[];
    %T_OldData(7,:)=[];
    handles = Optimize.GroupData(handles, 'Constraint');
    T_ActualData=get(handles.groupingTable,'Data');
    %T_ActualData(4,:)=[];
    [as df]=ismember(T_OldData(:,1), T_ActualData(:,1));
    ds=logical(1-as);
    [as1 df1]=ismember(T_ActualData(:,1),T_OldData(:,1));
    ds1=logical(1-as1);
    
    disp('********************************||<<<<<<<<<<<<<<<<+>>>>>>>>>>>>>>>>||********************************')
    disp(['Analyzing Constraint No:-' num2str(int64(kk))])
    disp('Removed IDs: IDs in the the previous constraint but not in the new constraint')
    disp(T_OldData(ds,1));
    disp('New IDs: IDs in the the new constraint but not in the old constraint')
    disp(T_ActualData(ds1,1));
    
    %%% Generating Constrint Table
    %%%%Case 1 - Weight Then We Have %
    if parameterColumnID==1
        Co1=4;
        Co2=6;
        Co3=7;
        Co4=8;
    else
        Co1=6;
        Co2=8;
        Co3=9;
        Co4=10;
    end
    
    if (parameterColumnID==1 || parameterColumnID==8);
        NewCons_Value=str2double(strrep(T_ActualData(:,Co1), '%', ''))/100;
        NewCons_MinValue=str2double(strrep(T_ActualData(:,Co2), '%', ''))/100;
        NewCons_MaxValue=str2double(strrep(T_ActualData(:,Co3), '%', ''))/100;
        OldCons_Value=str2double(strrep(T_OldData(:,Co1), '%', ''))/100;
        OldCons_MinValue=str2double(strrep(T_OldData(:,Co2), '%', ''))/100;
        OldCons_MaxValue=str2double(strrep(T_OldData(:,Co3), '%', ''))/100;
    else
        NewCons_Value=str2double(T_ActualData(:,Co1));
        NewCons_MinValue=str2double(T_ActualData(:,Co2));
        NewCons_MaxValue=str2double(T_ActualData(:,Co3));
        OldCons_Value=str2double(T_OldData(:,Co1));
        OldCons_MinValue=str2double(T_OldData(:,Co2));
        OldCons_MaxValue=str2double(T_OldData(:,Co3));
    end
    
    NewCons_ResetLogicals=logical(cell2mat(T_ActualData(:,Co4))*0);
    OldCons_Logicals=logical(cell2mat(T_OldData(:,Co4)));
    Min_diff=OldCons_Value-OldCons_MinValue;
    Max_diff=OldCons_MaxValue-OldCons_Value;
    
    df(ds)=[];
    Min_diff(ds)=[];
    Max_diff(ds)=[];
    OldCons_Logicals(ds)=[];
    
    NewCons_MaxValue(df,:)=NewCons_Value(df,:)+Max_diff;
    NewCons_MinValue(df,:)=NewCons_Value(df,:)-Min_diff;
    NewCons_ResetLogicals(df,:)=OldCons_Logicals;
    
    if (parameterColumnID==1 || parameterColumnID==8)
        NewCons_MaxValue_s=strread(sprintf(' %.3f%%', NewCons_MaxValue * 100), '%s', 'delimiter', ' ');
        NewCons_MinValue_s=strread(sprintf(' %.3f%%', NewCons_MinValue * 100), '%s', 'delimiter', ' ');
    else
        NewCons_MaxValue_s=strread(sprintf(' %.3f\t', NewCons_MaxValue), '%s', 'delimiter', '\t');
        NewCons_MinValue_s=strread(sprintf(' %.3f\t', NewCons_MinValue), '%s', 'delimiter', '\t');
    end
    
    
    NewCons_ResetLogicals_s=num2cell(NewCons_ResetLogicals);
    
    T_ActualData(:,Co2)=NewCons_MinValue_s;
    T_ActualData(:,Co3)=NewCons_MaxValue_s;
    T_ActualData(:,Co4)=NewCons_ResetLogicals_s;
    %% Set this into the table now
    set(handles.groupingTable,'Data',T_ActualData);
    %% Update this table in the constraint structure
    handles.OptiConstraints.InputTable(kk)={T_ActualData};
    
    if handles.ApplyConst==1
    handles = Optimize.AddGroupConstraint(handles);
    guidata(hObject, handles);
    disp('Applying Constraint');
    else
     disp('Constraint Not Applied');   
    end
    guidata(hObject, handles);
end
disp('********************************||<<<<<<<<<<<<<<<<|>>>>>>>>>>>>>>>>||********************************')

benchWeightBox =str2double(strrep(get(handles.benchWeightBox, 'String'), '%', '')) / 100 - 0.00001;
maxPortfolioWeight = benchWeightBox-handles.OptiConstraints.maxWDev;
minPortfolioWeight = benchWeightBox-handles.OptiConstraints.minWDev;
set(handles.maxWeightBox,'String', sprintf('%3.2f%%',maxPortfolioWeight*100));
set(handles.minWeightBox,'String', sprintf('%3.2f%%',minPortfolioWeight*100));
end
%% Reset the flag to apply constraint.
handles.ApplyConst=0;
guidata(hObject,handles);

% --- Executes on selection change in constraintsList.
function constraintsList_Callback(hObject, eventdata, handles)
% hObject    handle to constraintsList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns constraintsList contents as cell array
%        contents{get(hObject,'Value')} returns selected item from constraintsList
% %InputTable=handles.OptiConstraints.InputTable(kk,1)

initial_no_of_constraints=handles.OptiConstraints.NoOfConstraints;
if initial_no_of_constraints>=1
Cons_No=get(handles.constraintsList,'Value');
kk=Cons_No;
groupingTypePopupID=handles.OptiConstraints.groupingTypePopupID(kk);
set(handles.groupingTypePopup,'Value',groupingTypePopupID+1);
groupingTypePopup_Callback(hObject, eventdata, handles)

groupColumnID =handles.OptiConstraints.groupColumnID(kk);
set(handles.groupByPopup,'Value',groupColumnID+1);

parameterColumnID = handles.OptiConstraints.parameterColumnID(kk);
set(handles.parameterPopup,'Value',parameterColumnID+1);

deviation_string = handles.OptiConstraints.deviation_string(kk);
set(handles.deviationBox,'String',deviation_string{:});

maxDeviation_string =handles.OptiConstraints.maxDeviation_string(kk);
set(handles.maxDeviationBox,'String',maxDeviation_string{:});

nBuckets_string =handles.OptiConstraints.nBuckets_string(kk);
set(handles.nBucketsBox,'String',nBuckets_string{:});

minAllValue =handles.OptiConstraints.minAllValue(kk);
set(handles.MinConstraintAll,'String',minAllValue{:});

maxAllValue =handles.OptiConstraints.maxAllValue(kk);
set(handles.MaxConstraintAll,'String',maxAllValue{:});

OptiSelectAllCons=handles.OptiConstraints.OptiSelectAllCons(kk);
set(handles.OptiSelectAllCons,'Value',OptiSelectAllCons);

T_Data=handles.OptiConstraints.InputTable(kk);
handles = Optimize.GroupData(handles, 'Constraint'); %% Only to set the formatting of the table to the correct format
set(handles.groupingTable,'Data',T_Data{:});
end;
guidata(hObject,handles);

% --- Executes on button press in ApplyAllConstraints.
function ApplyAllConstraints_Callback(hObject, eventdata, handles)
% hObject    handle to ApplyAllConstraints (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.ApplyConst=1;
guidata(hObject, handles);
handles.groupConstraintAMatrix = [];
handles.groupConstraintbVector = [];
guidata(hObject, handles);
handles=CheckConstraints(hObject, handles);
guidata(hObject, handles);


% --- Executes on button press in WeightAutoOnOff.
function WeightAutoOnOff_Callback(hObject, eventdata, handles)
% hObject    handle to WeightAutoOnOff (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of WeightAutoOnOff


function readportfolionames(hObject,handles)
%K=readtable('PortfolioList.txt','ReadVariableNames',false);
PortfolioList=['Portfolio1', 'Portfolio2', 'Portfolio3']%K.Var1;
set(handles.PortfolioList,'String',PortfolioList);
guidata(hObject,handles);



% --- Executes on button press in UpdatePortfolioConsOptims.
function UpdatePortfolioConsOptims_Callback(hObject, eventdata, handles)
% hObject    handle to UpdatePortfolioConsOptims (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
PortfolioNumber=get(handles.PortfolioList,'value');
PortfolioString=get(handles.PortfolioList,'string');
PortfolioName=PortfolioString(PortfolioNumber,:);
PortfolioName=[PortfolioName{:} '.mat'];
OptimConst=handles.OptiConstraints;
usedFunctionsList=get(handles.usedFunctionsList , 'String');
OptimObjectList=usedFunctionsList;
OptimObjectFunc=handles.optimizationFunctions;
if(size(OptimObjectFunc,1)==0)
h = msgbox('No Objectives: Please Add One', 'Saving Workspace','error');
else
   button_i = questdlg(['Saving Workspace:',PortfolioName],'Workspace','Yes','No','No');
   if strcmp(button_i,'Yes')
save(PortfolioName,'OptimConst','OptimObjectList','OptimObjectFunc');
[cdata, cmap] = imread(fullfile(strcat(pwd, '\+Images\'), 'correct.bmp')); 
h = msgbox('Work Space Saved', 'Saving Workspace','custom',cdata,cmap);
   end;
end
guidata(hObject,handles);


% --- Executes on button press in LoadPortConstOptims.
function LoadPortConstOptims_Callback(hObject, eventdata, handles)
% hObject    handle to LoadPortConstOptims (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% Load Portfolio Constraints and Display Them

PortfolioNumber=get(handles.PortfolioList,'value');
PortfolioString=get(handles.PortfolioList,'string');
PortfolioName=PortfolioString(PortfolioNumber,:);
PortfolioName=[PortfolioName{:} '.mat'];
load(PortfolioName);
handles.OptiConstraints=OptimConst;

Disp_String=[];
%%% Step Generate Constraint List and Show it
if handles.OptiConstraints.NoOfConstraints>=1
    for kks=1:1:handles.OptiConstraints.NoOfConstraints
        Type_Name=handles.OptiConstraints.groupingTypePopupName(kks);
        S1=Type_Name{:};
        Group_Name= handles.OptiConstraints.groupColumnName(kks);
        S2=Group_Name{:};
        Para_Name=handles.OptiConstraints.parameterColumnName(kks);
        S3=Para_Name{:};
        Cons_String=['C-' num2str(kks) '|T-' S1{:} '|G-' S2{:} '|P-' S3{:}];
        Disp_String=[Disp_String;{Cons_String}];
    end;
    set(handles.constraintsList, 'String',Disp_String);
    set(handles.constraintsList, 'Value',1);
    constraintsList_Callback(hObject, eventdata, handles);
end

usedFunctionsList=OptimObjectList;
optimizationFunctions=OptimObjectFunc;

%% Check and Update Weights based on Flag
for kks=1:1:size(optimizationFunctions,1)
    choice=optimizationFunctions(kks,1)+1;
    Flag_Manual_Entry=optimizationFunctions(kks,4);
    if Flag_Manual_Entry==false
        if choice == 1
            new_weight=sprintf('%.3f',  1 );
        elseif choice == 2 || choice == 3 || choice == 4 || choice == 5 || choice == 6 || choice == 7 || choice == 8
            new_weight=sprintf('%.3f',  1 );
        elseif choice == 9 %% Grouped Weight
            new_weight=sprintf('%.3f',  1 / sum(handles.filteredNumericTable(:, 1)));
        elseif choice == 10 %% Grouped Duration
            new_weight=sprintf('%.3f', 1 / sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 6)));
        elseif choice == 11
            new_weight=sprintf('%.3f', 1 / sum(handles.filteredNumericTable(:, 1) .* (handles.filteredNumericTable(:, 8) + handles.filteredNumericTable(:, 9) + handles.filteredNumericTable(:, 10) + handles.filteredNumericTable(:, 11)) / 4));
        elseif choice == 12
            new_weight=sprintf('%.3f', 1 / sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 8)));
        elseif choice == 13
            new_weight=sprintf('%.3f', 1 / sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 9)));
        elseif choice == 14
            new_weight=sprintf('%.3f', 1 / sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 10)))
        elseif choice == 15
            new_weight= sprintf('%.3f', 1 / sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 11)));
        elseif choice == 16
            new_weight= sprintf('%.3f', 1 / sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 12)));
        elseif choice == 17
            new_weight= sprintf('%.3f', 1 / sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 5)));
        elseif choice == 18
            new_weight=sprintf('%.3f', 1 / sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 7)));
        elseif choice == 19
            new_weight=sprintf('%.3f',  1 / sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 7).* handles.filteredNumericTable(:, 6)/100));
        elseif choice == 20
            new_weight= sprintf('%.3f',  1 / sum(handles.filteredNumericTable(:, 1)));
        elseif choice == 21
            new_weight=sprintf('%.3f',  1 / sum(handles.filteredNumericTable(:, 1).*handles.filteredNumericTable(:, 6)));
        elseif choice == 22
            new_weight= sprintf('%.3f',  1 / sum(handles.filteredNumericTable(:, 1).*handles.filteredNumericTable(:, 6).*handles.filteredNumericTable(:, 7)/100));
        end
        %%new_weight
        %% Change string
        uf=usedFunctionsList(kks);
        uf=uf{:};
        ufl= strfind(uf,'-');
        %%for checking %% new_weight=sprintf('%.3f',  1.9999 );
        ufk=[uf(1,1:ufl),new_weight];
        usedFunctionsList(kks,:)={ufk};
        optimizationFunctions(kks,3)=str2double(new_weight);       
    else
        disp(['Using old weight for Objective No: ' num2str(int64(kks))])
    end
end
set(handles.usedFunctionsList , 'String', usedFunctionsList, 'value', 1);
handles.optimizationFunctions=optimizationFunctions;

[cdata, cmap] = imread(fullfile(strcat(pwd, '\+Images\'), 'correct.bmp')); 
h = msgbox('Work Space Loaded: Please Check Constraints', 'Load Work Space','custom',cdata,cmap);

guidata(hObject, handles);


% --- Executes on button press in pushbutton43.
function pushbutton43_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton43 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
