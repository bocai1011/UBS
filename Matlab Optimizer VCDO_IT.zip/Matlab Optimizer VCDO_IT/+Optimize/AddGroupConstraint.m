function handles = AddGroupConstraint(handles)

% Get selected information
constraintsTable = get(handles.groupingTable, 'data');

if isempty(constraintsTable)
    errordlg('No group constraints to add');
    error('No group constraints to add');
else
    groupColumnID = get(handles.groupByPopup, 'Value') - 1;
    groupColumnName = get(handles.groupByPopup, 'String');
    parameterColumnID = get(handles.parameterPopup, 'Value') - 1;
    parameterColumnName = get(handles.parameterPopup, 'String');
    
    switch parameterColumnID
        case 1
            originalParameterColumnID = 1;
        case 2
            originalParameterColumnID = 6;
        case 3
            originalParameterColumnID = 8;
        case 4
            originalParameterColumnID = 9;
        case 5
            originalParameterColumnID = 10;
        case 6
            originalParameterColumnID = 11;
        case 7
            originalParameterColumnID = 12;
        case 8
            originalParameterColumnID = 5;
        case 9
            originalParameterColumnID = 7;
        case 10
            originalParameterColumnID = 800;%% this if for contraints on the number of trades
        case 11
            originalParameterColumnID = 6;
            originalParameterColumnID_S =7;
    end
    
    nColumns = size(constraintsTable, 2);
    selectedGroups = cell2mat(constraintsTable(:, nColumns));
    if parameterColumnID == 1
        portfolioValues = (handles.currentSecurityGroupMapping * handles.filteredNumericTable(:, 2));
        coefficients = handles.currentSecurityGroupMapping(selectedGroups, :);
    elseif parameterColumnID == 10
        portfolioValues = zeros(size(handles.currentSecurityGroupMapping * handles.filteredNumericTable(:, 2)));
        coefficients = zeros(size(handles.currentSecurityGroupMapping(selectedGroups, :)));
        coefficientsBin = (handles.currentSecurityGroupMapping(selectedGroups, :));
    elseif parameterColumnID == 11
        
        portfolioValues = handles.currentSecurityGroupMapping * (handles.filteredNumericTable(:, originalParameterColumnID_S).*handles.filteredNumericTable(:, originalParameterColumnID) .* handles.filteredNumericTable(:, 2)/100);
        coefficients = bsxfun(@times, (handles.filteredNumericTable(:, originalParameterColumnID_S).*handles.filteredNumericTable(:, originalParameterColumnID)/100)' ,handles.currentSecurityGroupMapping(selectedGroups, :));
        
    else
        portfolioValues = handles.currentSecurityGroupMapping * (handles.filteredNumericTable(:, originalParameterColumnID) .* handles.filteredNumericTable(:, 2));
        coefficients = bsxfun(@times, handles.filteredNumericTable(:, originalParameterColumnID)' ,handles.currentSecurityGroupMapping(selectedGroups, :));
    end
    if parameterColumnID == 1 || parameterColumnID == 8
        minParamValues = str2double(strrep(constraintsTable(selectedGroups, nColumns - 2), '%', '')) / 100 - 0.00001 - portfolioValues(selectedGroups);
        maxParamValues = str2double(strrep(constraintsTable(selectedGroups, nColumns - 1), '%', '')) / 100 + 0.00001 - portfolioValues(selectedGroups);
    else
        minParamValues = str2double(strrep(constraintsTable(selectedGroups, nColumns - 2), '%', '')) - 0.00001 - portfolioValues(selectedGroups);
        maxParamValues = str2double(strrep(constraintsTable(selectedGroups, nColumns - 1), '%', '')) + 0.00001 - portfolioValues(selectedGroups);
    end
  
    if parameterColumnID == 10
        handles.groupConstraintAMatrix = [handles.groupConstraintAMatrix; coefficients, -coefficients, coefficientsBin, coefficientsBin; -coefficients, coefficients, - coefficientsBin, - coefficientsBin];
        handles.groupConstraintbVector = [handles.groupConstraintbVector; maxParamValues; -minParamValues];
    else
  
        handles.groupConstraintAMatrix = [handles.groupConstraintAMatrix; coefficients, -coefficients, zeros(sum(selectedGroups), 2 * size(coefficients, 2)); -coefficients, coefficients, zeros(sum(selectedGroups), 2 * size(coefficients, 2))];
        handles.groupConstraintbVector = [handles.groupConstraintbVector; maxParamValues; -minParamValues];
    end
    % constraintsList = get(handles.constraintsList, 'string');
    %if isempty(constraintsList)
    %    set(handles.constraintsList, 'string', strcat(groupColumnName(groupColumnID + 1), {' - '}, parameterColumnName(parameterColumnID + 1)));
    %else
    %    set(handles.constraintsList, 'string', [constraintsList; strcat(groupColumnName(groupColumnID + 1), {' - '}, parameterColumnName(parameterColumnID + 1))]);
    %end
end

end

