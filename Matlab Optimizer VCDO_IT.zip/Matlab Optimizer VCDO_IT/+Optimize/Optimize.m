function handles = Optimize(handles)

    Support.ClearForm (handles, 'Results');

    selectedSecurities = ModelFilter(handles);
    [handles.lastSolution , ~, flag] = CreateOptimization(handles, selectedSecurities);

    if flag == 1 || flag == 2
        ShowResults(handles);
    elseif flag == -4
        errordlg('Please check the Bloomberg downloaded data for errors');
        error('Please check the Bloomberg downloaded data for errors');
    else
        errordlg('No solutions, please relax the constraints');
        error('No solutions, please relax the constraints');
    end

end

function [solution, solutionValue, exitFlag] = CreateOptimization(handles, selectedSecurities)

disp('****Finding Missing Values In Data****')
ddnan=isnan(handles.filteredNumericTable);
ddnan=(sum(ddnan'))';
[mnan ~]=find(ddnan>0)
handles.filteredNumericTable(mnan,:);
handles.filteredStringTable(mnan,:)
disp('****||||||||||||||||||||||||||||||****')

    % Get the securities that were excluded from the optimization
    excludedSecurities = find(selectedSecurities == 0);
    save('excludedSecurities','excludedSecurities');
    %load('excludedSecurities');
    % Get parameters
    nSecurities = size(handles.filteredNumericTable, 1);
    maxPortfolioWeight = str2double(strrep(get(handles.maxWeightBox, 'String'), '%', '')) / 100 + 0.00001;
    minPortfolioWeight = str2double(strrep(get(handles.minWeightBox, 'String'), '%', '')) / 100 - 0.00001;
    maxPortfolioDuration = str2double(get(handles.maxDurationBox, 'String')) + 0.001;
    minPortfolioDuration = str2double(get(handles.minDurationBox, 'String')) - 0.001;
    maxPortfolioKRD2 = str2double(get(handles.maxKRD2Box, 'String')) + 0.0001;
    minPortfolioKRD2 = str2double(get(handles.minKRD2Box, 'String')) - 0.0001;
    maxPortfolioKRD5 = str2double(get(handles.maxKRD5Box, 'String')) + 0.0001;
    minPortfolioKRD5 = str2double(get(handles.minKRD5Box, 'String')) - 0.0001;
    maxPortfolioKRD10 = str2double(get(handles.maxKRD10Box, 'String')) + 0.0001;
    minPortfolioKRD10 = str2double(get(handles.minKRD10Box, 'String')) - 0.0001;
    maxPortfolioKRD20 = str2double(get(handles.maxKRD20Box, 'String')) + 0.0001;
    minPortfolioKRD20 = str2double(get(handles.minKRD20Box, 'String')) - 0.0001;
    maxPortfolioKRD30 = str2double(get(handles.maxKRD30Box, 'String')) + 0.0001;
    minPortfolioKRD30 = str2double(get(handles.minKRD30Box, 'String')) - 0.0001;
    maxPortfolioYield = str2double(strrep(get(handles.maxYieldBox, 'String'), '%', '')) / 100 + 0.00001;
    minPortfolioYield = str2double(strrep(get(handles.minYieldBox, 'String'), '%', '')) / 100 - 0.00001;
    maxPortfolioSpread = str2double(get(handles.maxSpreadBox, 'String')) + 0.001;
    minPortfolioSpread = str2double(get(handles.minSpreadBox, 'String')) - 0.001;
    maxPortfolioDTS = str2double(get(handles.maxDTSBox, 'String')) + 0.001;
    minPortfolioDTS = str2double(get(handles.minDTSBox, 'String')) - 0.001;
    minNSecurities = str2double(get(handles.nMinSecuritiesBox, 'String'));
    maxNSecurities = str2double(get(handles.nMaxSecuritiesBox, 'String'));
    onlyPortSecurities = get(handles.includeOnlyPortfolioSecuritiesCheck, 'Value');
    buyingCheckBox = get(handles.buyCheckbox, 'Value');
    sellingCheckBox = get(handles.sellCheckbox, 'Value');
    minValue = str2double(get(handles.minimumAmountBox, 'String')) * 1000;
    if get(handles.OptiPanelMinSizeType, 'Value')==1
    minValue = str2double(strrep(get(handles.minimumAmountBox, 'String'), '%', '')) / 100
    else
    minValue = str2double(get(handles.minimumAmountBox, 'String')) * 1000;
    end
    maxValue = str2double(strrep(get(handles.maxTradeBox, 'String'), '%', '')) / 100;

    % Increases stack size, may be problematic...
    if nSecurities > 500
        set(0,'RecursionLimit', nSecurities);
    end

    % Checks if there is at least one optimizationn function selected
    if isempty(handles.optimizationFunctions)
        errordlg('No optimization function selected');
        error('No optimization function selected');
    end

    % Mins
    if isnan(minValue) == 0
        %
        if get(handles.OptiPanelMinSizeType, 'Value')==1
        wmin = max(handles.filteredNumericTable(:, 15) / handles.newPortfolioSize.* handles.filteredNumericTable(:, 18),minValue);
        else
        wmin = max(handles.filteredNumericTable(:, 15) ,minValue)/ handles.newPortfolioSize.* handles.filteredNumericTable(:, 18);
        end
    else
        wmin = handles.filteredNumericTable(:, 15) / handles.newPortfolioSize .* handles.filteredNumericTable(:, 18);
    end

    % Maxes
    if isnan(maxValue) == 0
        wmax = maxValue;
    else
        wmax = maxPortfolioWeight;
    end

    temkdele=handles.filteredNumericTable(:, 18);

    % Lower and upper bounds: 0 <= w_i <= maxPortfolioWeight, 0 <= w_j <= port, 0 <= b_i <= 1, 0 <= b_j <= 1
    lb = zeros(nSecurities * 4, 1);
    ub = [zeros(nSecurities, 1) + wmax; handles.filteredNumericTable(:, 2); ones(1 * nSecurities, 1);2*ones(1 * nSecurities, 1)];

    % If there is a constraint only on buying of selling
    if sellingCheckBox == 0
        ub(nSecurities + 1:2 * nSecurities) = 0;
        ub(3 * nSecurities + 1:4 * nSecurities) = 0;
    end
    if buyingCheckBox == 0
        ub(1:nSecurities) = 0;
        ub(2 * nSecurities + 1:3 * nSecurities) = 0;
    end
    A = [];
    b = [];


    % Individual cases
    for i=1:nSecurities

        % Include only port securities: w_i = 0, w_j = 0, b_i = 0 and b_j = 0 for out of portfolio securities
        if onlyPortSecurities && handles.filteredNumericTable(i, 2) == 0
            ub(i) = 0;
            ub(i + nSecurities) = 0;
            ub(i + 2 * nSecurities) = 0;
            ub(i + 3 * nSecurities) = 0;
        end

        % Force selling: w_i = 0, w_j = port, b_i = 0, b_j = 1
        if ismember(i, excludedSecurities)
            ub(i, 1) = 0;
            lb(i + nSecurities, 1) = handles.filteredNumericTable(i, 2);
            ub(i + 2 * nSecurities, 1) = 0;
            if handles.filteredNumericTable(i, 2) ~= 0
                lb(i + 3 * nSecurities, 1) = 1;
            end
        end

        % Case there is nothing to be sold, b_j = 0
        if handles.filteredNumericTable(i, 2) == 0
            ub(i + 3 * nSecurities, 1) = 0;
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        constraintRow = zeros(8, 4 * nSecurities);
        % (w_i - w_j) + port >= 0
        constraintRow(1, i) = -1;
        constraintRow(1, nSecurities + i) = 1;
        % min * b_i <= w_i
        constraintRow(2, i) = -1;
        constraintRow(2, 2 * nSecurities + i) = round(wmin(i)*1e6)/1e6;
        % w_i <= w_max * b_i
        constraintRow(3, i) = 1;
        constraintRow(3, 2 * nSecurities + i) = -wmax;
        % w_j <= port * b_j
        %%%%%constraintRow(4, nSecurities + i) = 1;
        %%%%%constraintRow(4, 3 * nSecurities + i) = -handles.filteredNumericTable(i, 2);
        % 0 <= b_i + b_j
       % constraintRow(7, 2 * nSecurities + i) = -1;
       % constraintRow(7, 3 * nSecurities + i) = -1;
        % w_j >= min * b_i
        %%%%%constraintRow(5,nSecurities+i)=-1;
        %%%%%if (abs(handles.filteredNumericTable(i,2)-wmin(i))/handles.filteredNumericTable(i,2)) <0.02
        %%%%%constraintRow(5,3*nSecurities+i)=handles.filteredNumericTable(i,2);
        %%%%%else
        %%%%%constraintRow(5,3*nSecurities+i)=min(handles.filteredNumericTable(i,2),round(wmin(i)*1e6)/1e6);
        %%%%%end

        % b_i + b_j <= 1
        constraintRow(4, 2 * nSecurities + i) = 1;
        constraintRow(4, 3 * nSecurities + i) = 0.5;

        % Depending on the values, the portfolio weight can be less than
        % the minimum, we need to take care of this

        % In the case where we don't need to worry
        if 2 * wmin(i) >= handles.filteredNumericTable(i, 2)
             constraintRow(5, nSecurities + i) = 1;
             constraintRow(5, 3 * nSecurities + i) = -handles.filteredNumericTable(i, 2);
             constraintRow(6,nSecurities+i)=-1;
             constraintRow(6,3*nSecurities+i)=handles.filteredNumericTable(i,2);
             const7N=0;
             const8N=0;
             if ub(3 * nSecurities+i, 1)==2
                 ub(3 * nSecurities+i, 1)=1;
             end;
        else
            % port * b_j <= w_j
             constraintRow(5, nSecurities + i) = 1;
             constraintRow(5, 3 * nSecurities + i) = -(handles.filteredNumericTable(i,2)-wmin(i));
             constraintRow(6,nSecurities+i)=-1;
             constraintRow(6,3*nSecurities+i)=wmin(i);
             Mbig=2;%%100
             constraintRow(7, nSecurities + i) = 1;
             constraintRow(7, 3 * nSecurities + i) = Mbig;
             const7N=2*Mbig+handles.filteredNumericTable(i,2);
             constraintRow(8,nSecurities+i)=-1;
             constraintRow(8,3*nSecurities+i)=Mbig;
             const8N=2*Mbig-handles.filteredNumericTable(i,2);
        end

     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        A = [A; constraintRow];
        b = [b; handles.filteredNumericTable(i, 2); zeros(2, 1); 1; zeros(2, 1);const7N;const8N];

    end

    Aeq = [];
    beq = [];

    % Weight contraint
    if get(handles.constraintWeightCheck, 'Value') ~= 0
        A = [A; ones(1, nSecurities), -ones(1, nSecurities), zeros(1, 2 * nSecurities); -ones(1, nSecurities), ones(1, nSecurities), zeros(1, 2 * nSecurities)];
        b = [b; maxPortfolioWeight - handles.characteristicsMatrix(2, 1); -minPortfolioWeight + handles.characteristicsMatrix(2, 1)];
    end


    % Duration sum constraint
    if get(handles.constraintDurationCheck, 'Value') ~= 0
        A = [A; handles.filteredNumericTable(:, 6)', -handles.filteredNumericTable(:, 6)', zeros(1, 2 * nSecurities); -handles.filteredNumericTable(:, 6)', handles.filteredNumericTable(:, 6)', zeros(1, 2 * nSecurities)];
        b = [b; maxPortfolioDuration - handles.characteristicsMatrix(2, 2); -minPortfolioDuration + handles.characteristicsMatrix(2, 2)];
    end

    % KRD sum constraint
    if get(handles.constraintKRDCheck, 'Value') ~= 0
        A = [A; handles.filteredNumericTable(:, 8)', -handles.filteredNumericTable(:, 8)', zeros(1, 2 * nSecurities); -handles.filteredNumericTable(:, 8)', handles.filteredNumericTable(:, 8)', zeros(1, 2 * nSecurities)];
        b = [b; maxPortfolioKRD2 - handles.characteristicsMatrix(2, 3); -minPortfolioKRD2 + handles.characteristicsMatrix(2, 3)];
        A = [A; handles.filteredNumericTable(:, 9)', -handles.filteredNumericTable(:, 9)', zeros(1, 2 * nSecurities); -handles.filteredNumericTable(:, 9)', handles.filteredNumericTable(:, 9)', zeros(1, 2 * nSecurities)];
        b = [b; maxPortfolioKRD5 - handles.characteristicsMatrix(2, 4); -minPortfolioKRD5 + handles.characteristicsMatrix(2, 4)];
        A = [A; handles.filteredNumericTable(:, 10)', -handles.filteredNumericTable(:, 10)', zeros(1, 2 * nSecurities); -handles.filteredNumericTable(:, 10)', handles.filteredNumericTable(:, 10)', zeros(1, 2 * nSecurities)];
        b = [b; maxPortfolioKRD10 - handles.characteristicsMatrix(2, 5); -minPortfolioKRD10 + handles.characteristicsMatrix(2, 5)];
        A = [A; handles.filteredNumericTable(:, 11)', -handles.filteredNumericTable(:, 11)', zeros(1, 2 * nSecurities); -handles.filteredNumericTable(:, 11)', handles.filteredNumericTable(:, 11)', zeros(1, 2 * nSecurities)];
        b = [b; maxPortfolioKRD20 - handles.characteristicsMatrix(2, 6); -minPortfolioKRD20 + handles.characteristicsMatrix(2, 6)];
        A = [A; handles.filteredNumericTable(:, 12)', -handles.filteredNumericTable(:, 12)', zeros(1, 2 * nSecurities); -handles.filteredNumericTable(:, 12)', handles.filteredNumericTable(:, 12)', zeros(1, 2 * nSecurities)];
        b = [b; maxPortfolioKRD30 - handles.characteristicsMatrix(2, 7); -minPortfolioKRD30 + handles.characteristicsMatrix(2, 7)];
    end

        % KRD Pair constraint 5y+10y
    if get(handles.KRD0510Check, 'Value') ~= 0
        A = [A; handles.filteredNumericTable(:, 9)'+handles.filteredNumericTable(:, 10)', -handles.filteredNumericTable(:, 9)'-handles.filteredNumericTable(:, 10)',...
            zeros(1, 2 * nSecurities);...
            -handles.filteredNumericTable(:, 9)'-handles.filteredNumericTable(:, 10)', handles.filteredNumericTable(:, 9)'+handles.filteredNumericTable(:, 10)',...
            zeros(1, 2 * nSecurities)];
        maxPortfolioKRD0510 = str2double(get(handles.benchKRD5Box, 'String')) + str2double(get(handles.benchKRD10Box, 'String'))...
            +str2double(get(handles.KRD0510, 'String'))+ 0.0001;
        minPortfolioKRD0510 = str2double(get(handles.benchKRD5Box, 'String')) + str2double(get(handles.benchKRD10Box, 'String'))...
            -str2double(get(handles.KRD0510, 'String'))- 0.0001;
        b = [b; maxPortfolioKRD0510 - handles.characteristicsMatrix(2, 4)- handles.characteristicsMatrix(2, 5);...
            -minPortfolioKRD0510 + handles.characteristicsMatrix(2, 4)+ handles.characteristicsMatrix(2, 5)];
    end
       % KRD Pair constraint 20y+30y
    if get(handles.KRD2030Check, 'Value') ~= 0
        A = [A; handles.filteredNumericTable(:, 11)'+handles.filteredNumericTable(:, 12)', -handles.filteredNumericTable(:, 11)'-handles.filteredNumericTable(:, 12)',...
            zeros(1, 2 * nSecurities);...
            -handles.filteredNumericTable(:, 11)'-handles.filteredNumericTable(:, 12)', handles.filteredNumericTable(:, 11)'+handles.filteredNumericTable(:, 12)',...
            zeros(1, 2 * nSecurities)];
        maxPortfolioKRD2030 = str2double(get(handles.benchKRD20Box, 'String')) + str2double(get(handles.benchKRD30Box, 'String'))...
            +str2double(get(handles.KRD2030, 'String'))+ 0.0001;
        minPortfolioKRD2030 = str2double(get(handles.benchKRD20Box, 'String')) + str2double(get(handles.benchKRD30Box, 'String'))...
            -str2double(get(handles.KRD2030, 'String'))- 0.0001;
        b = [b; maxPortfolioKRD2030 - handles.characteristicsMatrix(2, 6)- handles.characteristicsMatrix(2, 7);...
            -minPortfolioKRD2030 + handles.characteristicsMatrix(2, 6)+ handles.characteristicsMatrix(2, 7)];
    end

    % Yield sum constraint
    if get(handles.constraintYieldCheck, 'Value') ~= 0
        A = [A; handles.filteredNumericTable(:, 5)', -handles.filteredNumericTable(:, 5)', zeros(1, 2 * nSecurities); -handles.filteredNumericTable(:, 5)', handles.filteredNumericTable(:, 5)', zeros(1, 2 * nSecurities)];
        b = [b; maxPortfolioYield - handles.characteristicsMatrix(2, 8); -minPortfolioYield + handles.characteristicsMatrix(2, 8)];
    end

    % Spread sum constraint
    if get(handles.constraintSpreadCheck, 'Value') ~= 0
        A = [A; handles.filteredNumericTable(:, 7)', -handles.filteredNumericTable(:, 7)', zeros(1, 2 * nSecurities); -handles.filteredNumericTable(:, 7)', handles.filteredNumericTable(:, 7)', zeros(1, 2 * nSecurities)];
        b = [b; maxPortfolioSpread - handles.characteristicsMatrix(2, 9); -minPortfolioSpread + handles.characteristicsMatrix(2, 9)];
    end

    % DTS Constraint
    if get(handles.constraintDTSCheck, 'Value') ~= 0
        A = [A; handles.filteredNumericTable(:, 7)'.*handles.filteredNumericTable(:, 6)'/100, -handles.filteredNumericTable(:, 7)'.*handles.filteredNumericTable(:, 6)'/100, zeros(1, 2 * nSecurities); -handles.filteredNumericTable(:, 7)'.*handles.filteredNumericTable(:, 6)'/100, handles.filteredNumericTable(:, 7)'.*handles.filteredNumericTable(:, 6)'/100, zeros(1, 2 * nSecurities)];
        b = [b; maxPortfolioDTS - handles.characteristicsMatrix(2, 10); -minPortfolioDTS + handles.characteristicsMatrix(2, 10)];
    end

    % Limit on the number of securities
    if maxNSecurities == minNSecurities
        Aeq = [Aeq; zeros(1, 2 * nSecurities), ones(1, 2 * nSecurities)];
        beq = [beq; maxNSecurities];
    else
        A = [A; zeros(1, 2 * nSecurities), ones(1, 2 * nSecurities); zeros(1, 2 * nSecurities), -ones(1, 2 * nSecurities)];
        b = [b; maxNSecurities; -minNSecurities];
    end

    % Grouping constraints
    A = [A; handles.groupConstraintAMatrix];
    b = [b; handles.groupConstraintbVector];

    nts=size(A,2);

    % Utility function on security level
    f = [];
    for i=1:size(handles.optimizationFunctions, 1)
        weight = handles.optimizationFunctions(i, 3);
        switch handles.optimizationFunctions(i, 1)
            case 1
                f = [f, [ones(nSecurities * 2, 1) * weight; zeros(nSecurities * 2, 1)]];
            case 2 %% Max Liquidity
                SeriesAmtOutX=handles.filteredNumericTable(:, 16);
                MatDatex=handles.filteredNumericTable(:, 17);
                SeriesNamesX=handles.filteredStringTable(:, 4);
                UseOnlyOutAmt=get(handles.LiquidityCalcType, 'Value');
                LC=LiqCalculation(SeriesNamesX,SeriesAmtOutX,MatDatex,UseOnlyOutAmt);
                %emissionSizeParameter = 1 - (handles.filteredNumericTable(:, 15) - min(handles.filteredNumericTable(:, 15))) / (max(handles.filteredNumericTable(:, 15)) - min(handles.filteredNumericTable(:, 15)));
                %emissionDateParameter = 1 - (handles.filteredNumericTable(:, 16) - min(handles.filteredNumericTable(:, 16))) / (max(handles.filteredNumericTable(:, 16)) - min(handles.filteredNumericTable(:, 16)));
                %% Buy Liquid Bond// Sell Less Liquid Bonds
                f = [f, [LC * weight;-LC * weight; zeros(nSecurities * 2, 1)]];
            case 3 %% Min Trans Cost
                tcosts=mean([handles.filteredNumericTable(:, 13) handles.filteredNumericTable(:, 14)]')';
                f = [f, [weight * abs(handles.filteredNumericTable(:, 13)-handles.filteredNumericTable(:, 14))./tcosts;...
                    weight * abs(handles.filteredNumericTable(:, 13)-handles.filteredNumericTable(:, 14))./tcosts; zeros(nSecurities * 2, 1)]];
            case 4 %% Max Yield
                f = [f, [-weight*handles.filteredNumericTable(:, 5); weight * handles.filteredNumericTable(:, 5); zeros(nSecurities * 2, 1)]];
            case 5 %% Max spread
                f = [f, [-weight*handles.filteredNumericTable(:, 7); weight * handles.filteredNumericTable(:, 7); zeros(nSecurities * 2, 1)]];
            case 6 %% No Of Securities
                f = [f, [zeros(nSecurities * 2, 1); weight * ones(nSecurities * 2, 1)]];
            case 7 %% No Of Securities out of the BM
                f = [f, [zeros(nSecurities * 2, 1); weight * repmat(handles.filteredNumericTable(:, 2) == 0, 2, 1)]];
        end
    end
    if isempty(f)
        f = zeros(nSecurities * 4, 1);
        ft=f;
    else
        ft=f;
        f = sum(f, 2);
    end

    % Utility function on group level
    for i=1:size(handles.optimizationFunctions, 1)
        weight = handles.optimizationFunctions(i, 3);
        groupingColumn = handles.optimizationFunctions(i, 2);
        switch handles.optimizationFunctions(i, 1)
            case 8
                [A, b, f, lb, ub, Aeq] = addObjectiveFunction(handles, ones(nSecurities, 1), weight, groupingColumn, A, b, f, lb, ub, Aeq);
        	case 9
                [A, b, f, lb, ub, Aeq] = addObjectiveFunction(handles, handles.filteredNumericTable(:, 6), weight, groupingColumn,  A, b, f, lb, ub, Aeq);
        	case 10
                [A, b, f, lb, ub, Aeq] = addObjectiveFunction(handles, handles.filteredNumericTable(:, 8), weight, groupingColumn,  A, b, f, lb, ub, Aeq);
                [A, b, f, lb, ub, Aeq] = addObjectiveFunction(handles, handles.filteredNumericTable(:, 9), weight, groupingColumn,  A, b, f, lb, ub, Aeq);
                [A, b, f, lb, ub, Aeq] = addObjectiveFunction(handles, handles.filteredNumericTable(:, 10), weight, groupingColumn,  A, b, f, lb, ub, Aeq);
                [A, b, f, lb, ub, Aeq] = addObjectiveFunction(handles, handles.filteredNumericTable(:, 11), weight, groupingColumn,  A, b, f, lb, ub, Aeq);
                [A, b, f, lb, ub, Aeq] = addObjectiveFunction(handles, handles.filteredNumericTable(:, 12), weight, groupingColumn,  A, b, f, lb, ub, Aeq);
            case 11
                [A, b, f, lb, ub, Aeq] = addObjectiveFunction(handles, handles.filteredNumericTable(:, 8), weight, groupingColumn,  A, b, f, lb, ub, Aeq);
        	case 12
                [A, b, f, lb, ub, Aeq] = addObjectiveFunction(handles, handles.filteredNumericTable(:, 9), weight, groupingColumn,  A, b, f, lb, ub, Aeq);
        	case 13
                [A, b, f, lb, ub, Aeq] = addObjectiveFunction(handles, handles.filteredNumericTable(:, 10), weight, groupingColumn,  A, b, f, lb, ub, Aeq);
            case 14
                [A, b, f, lb, ub, Aeq] = addObjectiveFunction(handles, handles.filteredNumericTable(:, 11), weight, groupingColumn,  A, b, f, lb, ub, Aeq);
            case 15
                [A, b, f, lb, ub, Aeq] = addObjectiveFunction(handles, handles.filteredNumericTable(:, 12), weight, groupingColumn,  A, b, f, lb, ub, Aeq);
        	case 16
                [A, b, f, lb, ub, Aeq] = addObjectiveFunction(handles, handles.filteredNumericTable(:, 5), weight, groupingColumn,  A, b, f, lb, ub, Aeq);
        	case 17
                [A, b, f, lb, ub, Aeq] = addObjectiveFunction(handles, handles.filteredNumericTable(:, 7), weight, groupingColumn,  A, b, f, lb, ub, Aeq);
        	case 18
                [A, b, f, lb, ub, Aeq] = addObjectiveFunction(handles, handles.filteredNumericTable(:, 6).*handles.filteredNumericTable(:, 7)/100, weight, groupingColumn,  A, b, f, lb, ub, Aeq);
            case 19
                [A, b, f, lb, ub, Aeq] = addMinMaxObjectiveFunction(handles, ones(nSecurities, 1), weight, groupingColumn, A, b, f, lb, ub, Aeq);
            case 20
                [A, b, f, lb, ub, Aeq] = addMinMaxObjectiveFunction(handles, handles.filteredNumericTable(:, 6), weight, groupingColumn, A, b, f, lb, ub, Aeq);
            case 21
                [A, b, f, lb, ub, Aeq] = addMinMaxObjectiveFunction(handles, handles.filteredNumericTable(:, 6).*handles.filteredNumericTable(:, 7)/100, weight, groupingColumn, A, b, f, lb, ub, Aeq);
        end
    end
csvwrite('csv_A_45.dat',A);
ATemp=abs(round(A(:,1:nts)*1e6)/1e6);
STemps=sum(ATemp')';
kss=find(not(STemps));
A(kss,:)=[];
b(kss,:)=[];
    % Solve
    ver = version('-release');
    if str2double(ver(1:4)) >= 2014
        choicesolver = get(handles.ChooseSolver, 'value');
        choicesolvers = get(handles.ChooseSolver, 'string');
        choicesolvers=choicesolvers(choicesolver,:);
        if choicesolver==1
        options = optimoptions('intlinprog','CutGeneration','advanced','HeuristicsMaxNodes',5000,'MaxTime',handles.SolverMaxTime);
        save('OptiFile','f','nSecurities','A','b','Aeq','beq','lb','ub')
        [compactSolution, solutionValue, exitFlag] = intlinprog(f, 2 * nSecurities + 1: 4 * nSecurities, A, b, Aeq, beq, lb, ub);%, options);
        else
        choicesolvers=choicesolvers{:};
        xtype=[2 * nSecurities + 1: 4 * nSecurities];

        opts = optiset('solver',choicesolvers,'display','iter','maxtime',handles.SolverMaxTime,'maxiter',60000,'maxnodes',1000000);
        Opt = opti('f',f,'ineq',A,b,'bounds',lb,ub,'xtype',xtype,'options',opts);
        %%%Solve the MILP problem
        [compactSolution, solutionValue, exitFlag,info] = solve(Opt);
        exitFlag=2;
        info
        end
    else
        disp('Matlab 2014a or higher not found, using branch and cut');
        [compactSolution, solutionValue, exitFlag] = BranchAndCut(f, 2 * nSecurities + 1: 4 * nSecurities, A, b, Aeq, beq, lb, ub);
    end

    % Organizing Output
    %% Create Modified Fxt from f : Binary elements for buy and sell elements (0 1 2) mapped to 0 and 1 > decision 2 mapped to 1
    solution = zeros(size(handles.filteredNumericTable, 1), 1);
    mcompactSolution=compactSolution;
    mcompactSolution(2 * nSecurities+1:4 * nSecurities)=((round(mcompactSolution(2 * nSecurities+1:4 * nSecurities)*1e3)/1e3)>=1);
    if isempty(solutionValue)
        solutionValue = 0;
    else
        disp('Total Security Level Function Value:');
        disp(sum(f(1:4 * nSecurities) .* mcompactSolution(1:4 * nSecurities)));
        disp('Security Level Individual Function Values:');
        disp(ft'* mcompactSolution(1:4 * nSecurities));
        nStart = 4 * nSecurities;
        for i=1:size(handles.optimizationFunctions, 1)
            if handles.optimizationFunctions(i, 1) ~= 1 && handles.optimizationFunctions(i, 1) ~= 2 && handles.optimizationFunctions(i, 1) ~= 3 && handles.optimizationFunctions(i, 1) ~= 4 && handles.optimizationFunctions(i, 1) ~= 5 && handles.optimizationFunctions(i, 1) ~= 6 && handles.optimizationFunctions(i, 1) ~= 7
                disp(strcat({'Group Level Function Value(s): '}, num2str(i)));
                [~, ~, index] = unique(handles.filteredStringTable(:, handles.optimizationFunctions(i, 2)));
                if handles.optimizationFunctions(i, 1) == 10
                    nGroups = max(index) * 4;
                else
                    if (handles.optimizationFunctions(i, 1) == 18 | handles.optimizationFunctions(i, 1) == 19)
                    nGroups = 1;
                    else
                    nGroups = max(index);
                    end
                end
                disp(sum(f(nStart + 1:nStart + nGroups) .* compactSolution(nStart + 1:nStart + nGroups)));
                nStart = nStart + nGroups;
            end
        end
        solution = mcompactSolution(1:nSecurities, 1) .* mcompactSolution(2 * nSecurities + 1:3 * nSecurities, 1) - (mcompactSolution(nSecurities + 1:2 * nSecurities, 1)) .* (mcompactSolution(3 * nSecurities + 1:4 * nSecurities, 1)>=1);
        disp(strcat({'Number of selected securities is: '}, num2str(sum(mcompactSolution(2 * nSecurities + 1:3 * nSecurities, 1)) + sum(mcompactSolution(3 * nSecurities + 1:4 * nSecurities, 1)))));
    end
end

% Adds new parameters to objective function
function [A, b, f, lb, ub, Aeq] = addObjectiveFunction(handles, multiplicationFactors, normalizationFactor, groupingColumn, A, b, f, lb, ub, Aeq)

%if sum(abs(multiplicationFactors'))~=0
    [~, ~, index] = unique(handles.filteredStringTable(:, groupingColumn));
    nGroups = max(index);
    groupedTable = zeros(nGroups, size(index, 1));
    for group=1:nGroups
        groupedTable(group, :) = (index == group)';
    end
    % New Rows
    temp = bsxfun(@times, multiplicationFactors' , groupedTable);
    A = [A; temp, -temp, zeros(nGroups, size(A, 2) - 2 * size(temp, 2)); -temp, temp, zeros(nGroups, size(A, 2) - 2 * size(temp, 2))];
    % New columns
    A = [A, [zeros(size(A, 1) - 2 * nGroups, nGroups); -eye(nGroups); -eye(nGroups)]];
    b = [b; temp * (handles.filteredNumericTable(:, 1) - handles.filteredNumericTable(:, 2)); -temp * (handles.filteredNumericTable(:, 1) - handles.filteredNumericTable(:, 2))];
    % Scaling
    if mean(multiplicationFactors) ~= 0
        f = [f; ones(nGroups, 1) * normalizationFactor];
    else
        f = [f; ones(nGroups, 1)];
    end
    lb = [lb; zeros(nGroups, 1)];
    ub = [ub; zeros(nGroups, 1) + Inf];

    if isempty(Aeq) == 0
        Aeq = [Aeq, zeros(size(Aeq, 1), nGroups)];
    end
%else
%A=A;
%b=b;
%f=f;
%lb=lb;
%ub=ub;
%Aeq=Aeq;
%end
end


% Adds new parameters to objective function
function [A, b, f, lb, ub, Aeq] = addMinMaxObjectiveFunction(handles, multiplicationFactors, normalizationFactor, groupingColumn, A, b, f, lb, ub, Aeq)

%if sum(abs(multiplicationFactors'))~=0
    [~, ~, index] = unique(handles.filteredStringTable(:, groupingColumn));
    nGroups = max(index);
    groupedTable = zeros(nGroups, size(index, 1));
    for group=1:nGroups
        groupedTable(group, :) = (index == group)';
    end
    % New Rows
    temp = bsxfun(@times, multiplicationFactors' , groupedTable);
    dt = size(A, 2) - 2 * size(temp, 2);



    A = [A , zeros(size(A, 1),1) ; temp, -temp, zeros(size(temp,1),dt) ,-1*ones(size(temp,1),1); -temp, temp, zeros(size(temp,1),dt), -1*ones(size(temp,1),1)];
    % New columns
    %A = [A, [zeros(size(A, 1) - 2 * nGroups, nGroups); -eye(nGroups); -eye(nGroups)]];
    b = [b; temp * (handles.filteredNumericTable(:, 1) - handles.filteredNumericTable(:, 2)); -temp * (handles.filteredNumericTable(:, 1) - handles.filteredNumericTable(:, 2))];
    % Scaling
    if mean(multiplicationFactors) ~= 0
        f = [f; 1 * normalizationFactor];
    else
        f = [f; 1];
    end
    lb = [lb; zeros(1, 1)];
    ub = [ub; zeros(1, 1) + Inf];
    if isempty(Aeq) == 0
        Aeq = [Aeq, zeros(size(Aeq, 1), 1)];
    end
end

% Until de 8th parameter is mandatory, the 9th sould not be inputted
function [solution, z, exitFlag] = BranchAndCut(f, integers, A, b, Aeq, beq, lb, ub, hiddenParameters)

    % Setting for the initial run
    if nargin < 9
        hiddenParameters = struct('lastZ', inf, 'startTime', tic);
        tic;
        disp('Starting branch and cut algorithm');
    end
    
    % Tries to solve
    [solution, z, exitFlag] = linprog(f, A, b, Aeq, beq, lb, ub, [], optimset('Display', 'iter','maxiter',100));

    % If there is already a better solution
    if hiddenParameters.lastZ < z
        exitFlag = -10;
    else
        if exitFlag == 1
            % Solving a rounding bug
            solution(integers) = round(solution(integers) * 10000000000) / 10000000000;
            % If a solution was found and there are still non integers
            if sum((floor(solution(integers)) == solution(integers)) == 0) ~= 0
                [~, index] = sortrows(abs(solution(integers) - floor(solution(integers)) - 0.5));
                integerI = integers(index(1));
                solutionI = solution(integerI);
                tempUb = ub;
                tempUb(integerI) = floor(solutionI);

                [tempSolution1, tempZ1, tempExitFlag1] = BranchAndCut(f, integers, A, b, Aeq, beq, lb, tempUb, hiddenParameters);

                % If solution was found and we want to exit
                if tempExitFlag1 == 2
                    solution = tempSolution1;
                    z = tempZ1;
                    exitFlag = tempExitFlag1;
                else
                    tempLb = lb;
                    tempLb(integerI) = ceil(solutionI);
                    if hiddenParameters.lastZ > tempZ1
                        hiddenParameters.lastZ = tempZ1;
                    end
                    [tempSolution2, tempZ2, tempExitFlag2] = BranchAndCut(f, integers, A, b, Aeq, beq, tempLb, ub, hiddenParameters);

                    % If solution was found and we want to exit
                    if tempExitFlag2 == 2
                        solution = tempSolution2;
                        z = tempZ2;
                        exitFlag = tempExitFlag2;
                    % If both branches found solutions
                    elseif tempExitFlag1 == 1 && tempExitFlag2 == 1
                        % If the first solution is better
                        if tempZ1 <= tempZ2
                            solution = tempSolution1;
                            z = tempZ1;
                            exitFlag = tempExitFlag1;
                        % If the second solution is better
                        else
                            solution = tempSolution2;
                            z = tempZ2;
                            exitFlag = tempExitFlag2;
                        end
                    % If the first branch only found a solution
                    elseif tempExitFlag1 == 1 && tempExitFlag2 ~= 1
                        solution = tempSolution1;
                        z = tempZ1;
                        exitFlag = tempExitFlag1;
                    % If the second branch only found a solution
                    elseif tempExitFlag1 ~= 1 && tempExitFlag2 == 1
                        solution = tempSolution2;
                        z = tempZ2;
                        exitFlag = tempExitFlag2;
                    % If no branches found solutions
                    else
                        exitFlag = -10;
                    end
                end
            else
                disp(['Improved solution found, z = ', num2str(z)]);
                toc;
                if toc(hiddenParameters.startTime) > 60
                    if strcmp(questdlg('Solution found and time limit reached, do you want to stop?','Solution found'), 'Yes')
                        exitFlag = 2;
                    end
                end
            end
        end
    end
    if nargin < 9
        toc;
    end
end

function includeMatrix = ModelFilter(handles)

    % Getting info
    outOfPortfolioSecurities = get(handles.outOfOptimizationList, 'Value') - 1;
    outOfPortfolioSecurities = outOfPortfolioSecurities(outOfPortfolioSecurities ~= 0);
    excludeOutOfBM = get(handles.excludeOutBMCheck, 'Value');
    excludeTickersOutOfBM = get(handles.excludeTickersOutOfBenchmarkCheck, 'Value');
    nTotalSecs = size(handles.filteredNumericTable, 1);

    % Allocating matrix
    includeMatrix = ones(nTotalSecs, 1);

    % Removing excluded securities
    includeMatrix(outOfPortfolioSecurities) = 0;

    % if 'Exclude out of BM' is selected
    if excludeOutOfBM
        includeMatrix(handles.filteredNumericTable(:, 1) == 0 & handles.filteredNumericTable(:, 2) ~= 0) = 0;
        excludedSecurities = handles.filteredStringTable(handles.filteredNumericTable(:, 1) == 0 & handles.filteredNumericTable(:, 2) ~= 0, 1);
        if isempty(excludedSecurities) == 0
            msgbox(['Excluding the securities out of benchmark:'; excludedSecurities], 'Out of benchmark');
        end
    end

    % If we should exclude tickers out of BM
    if excludeTickersOutOfBM
        tickersInBenchmark = unique(handles.filteredStringTable(handles.filteredNumericTable(:, 1) ~= 0, 4));
        includeMatrix(ismember(handles.filteredStringTable(:, 4), tickersInBenchmark) == 0) = 0;
        excludedSecurities = handles.filteredStringTable(ismember(handles.filteredStringTable(:, 4), tickersInBenchmark) == 0, [1, 4]);
        if isempty(excludedSecurities) == 0
            msgbox(['Excluding the securities out of benchmark:'; excludedSecurities(:, 1); 'due to the exclusion of the tickers:'; unique(excludedSecurities(:, 2))], 'Out of benchmark');
        end
    end

end

function ShowResults(handles)

    % Parameters calculation
    changedWeights = (round(handles.lastSolution(:, 1) * 1000000000) / 1000000000) ~= 0;

    nSecurities = sum(changedWeights);
    newWeights = handles.lastSolution(:, 1) + handles.filteredNumericTable(:, 2);

    % Weights
    set(handles.resultBenchWeightBox, 'String', sprintf('%.2f%%', sum(handles.filteredNumericTable(:, 1)) *  100));
    set(handles.resultOrigPortWeightBox, 'String', sprintf('%.2f%%', sum(handles.filteredNumericTable(:, 2)) *  100));
    set(handles.resultNewPortWeightBox, 'String', sprintf('%.2f%%', sum(newWeights) *  100));

    % Duration
    set(handles.resultBenchDurationBox, 'String', sprintf('%.2f', sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 6))));
    set(handles.resultOrigPortDurationBox, 'String', sprintf('%.2f', sum(handles.filteredNumericTable(:, 2) .* handles.filteredNumericTable(:, 6))));
    set(handles.resultNewPortDurationBox, 'String', sprintf('%.2f', sum(newWeights .* handles.filteredNumericTable(:, 6))));

    % KRD 2
    set(handles.resultBenchKRD2Box, 'String', sprintf('%.3f', sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 8))));
    set(handles.resultOrigPortKRD2Box, 'String', sprintf('%.3f', sum(handles.filteredNumericTable(:, 2) .* handles.filteredNumericTable(:, 8))));
    set(handles.resultNewPortKRD2Box, 'String', sprintf('%.3f', sum(newWeights .* handles.filteredNumericTable(:, 8))));

    % KRD 5
    set(handles.resultBenchKRD5Box, 'String', sprintf('%.3f', sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 9))));
    set(handles.resultOrigPortKRD5Box, 'String', sprintf('%.3f', sum(handles.filteredNumericTable(:, 2) .* handles.filteredNumericTable(:, 9))));
    set(handles.resultNewPortKRD5Box, 'String', sprintf('%.3f', sum(newWeights .* handles.filteredNumericTable(:, 9))));

    % KRD 10
    set(handles.resultBenchKRD10Box, 'String', sprintf('%.3f', sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 10))));
    set(handles.resultOrigPortKRD10Box, 'String', sprintf('%.3f', sum(handles.filteredNumericTable(:, 2) .* handles.filteredNumericTable(:, 10))));
    set(handles.resultNewPortKRD10Box, 'String', sprintf('%.3f', sum(newWeights .* handles.filteredNumericTable(:, 10))));

    % KRD 20
    set(handles.resultBenchKRD20Box, 'String', sprintf('%.3f', sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 11))));
    set(handles.resultOrigPortKRD20Box, 'String', sprintf('%.3f', sum(handles.filteredNumericTable(:, 2) .* handles.filteredNumericTable(:, 11))));
    set(handles.resultNewPortKRD20Box, 'String', sprintf('%.3f', sum(newWeights .* handles.filteredNumericTable(:, 11))));

    % KRD 30
    set(handles.resultBenchKRD30Box, 'String', sprintf('%.3f', sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 12))));
    set(handles.resultOrigPortKRD30Box, 'String', sprintf('%.3f', sum(handles.filteredNumericTable(:, 2) .* handles.filteredNumericTable(:, 12))));
    set(handles.resultNewPortKRD30Box, 'String', sprintf('%.3f', sum(newWeights .* handles.filteredNumericTable(:, 12))));

    % Yield
    set(handles.resultBenchYieldBox, 'String', sprintf('%.2f%%', sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 5)) * 100));
    set(handles.resultOrigPortYieldBox, 'String', sprintf('%.2f%%', sum(handles.filteredNumericTable(:, 2) .* handles.filteredNumericTable(:, 5)) * 100));
    set(handles.resultNewPortYieldBox, 'String', sprintf('%.2f%%', sum(newWeights .* handles.filteredNumericTable(:, 5)) * 100));

    % Spread
    set(handles.resultBenchSpreadBox, 'String', sprintf('%.2f', sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 7))));
    set(handles.resultOrigPortSpreadBox, 'String', sprintf('%.2f', sum(handles.filteredNumericTable(:, 2) .* handles.filteredNumericTable(:, 7))));
    set(handles.resultNewPortSpreadBox, 'String', sprintf('%.2f', sum(newWeights .* handles.filteredNumericTable(:, 7))));

    % DTS
    set(handles.resultBenchDTSBox, 'String', sprintf('%.2f', sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 7).* handles.filteredNumericTable(:, 6)/100)));
    set(handles.resultOrigPortDTSBox, 'String', sprintf('%.2f', sum(handles.filteredNumericTable(:, 2) .* handles.filteredNumericTable(:, 7).* handles.filteredNumericTable(:, 6)/100)));
    set(handles.resultNewPortDTSBox, 'String', sprintf('%.2f', sum(newWeights .* handles.filteredNumericTable(:, 7).* handles.filteredNumericTable(:, 6)/100)));

    % Calculate conversion rate
    [~, index] = ismember(handles.filteredStringTable(:, 5), handles.currencySpotCurrencies);
    conversion = handles.currencySpotValues(index);

    % Results
    results = cell(nSecurities, 6);
    results(:, 1) = handles.filteredStringTable(changedWeights, 1);
    results(:, 2) = strread(sprintf(' %.2f%%', handles.lastSolution(changedWeights, 1) * 100), '%s', 'delimiter', ' ');
    amt_to_buy=round(handles.lastSolution(changedWeights, 1) .* handles.newPortfolioSize ./ handles.filteredNumericTable(changedWeights, 18));
    min_size=handles.filteredNumericTable(changedWeights, 15) .* conversion(changedWeights);

    amt_to_buy_a=amt_to_buy./min_size;
    amt_to_buy_b=round(amt_to_buy/str2double(get(handles.ResultsRounding, 'String')))*str2double(get(handles.ResultsRounding, 'String'));
    for kkta=1:1:length(amt_to_buy_a)
        if amt_to_buy_a(kkta,1)<=0.95
            amt_to_buy_f(kkta,1)=amt_to_buy(kkta,1);
        else
            amt_to_buy_f(kkta,1)=amt_to_buy_b(kkta,1);
        end
    end
    results(:, 3) = arrayfun(@(x) Support.separatethousands(x, ',', 0), round(handles.lastSolution(changedWeights, 1) .* handles.newPortfolioSize ./ handles.filteredNumericTable(changedWeights, 18)), 'UniformOutput', 0);
    results(:, 4) = arrayfun(@(x) Support.separatethousands(x, ',', 0), amt_to_buy_f, 'UniformOutput', 0);
    results(:, 5) = arrayfun(@(x) Support.separatethousands(x, ',', 0), handles.filteredNumericTable(changedWeights, 15) .* conversion(changedWeights), 'UniformOutput', 0);
    results(:, 6) = handles.filteredStringTable(changedWeights, 2);
    results(:, 7) = handles.filteredStringTable(changedWeights, 3);

    set(handles.resultsTable, 'Data', results, 'ColumnName', {'Name', 'Weight', 'Buy Size', 'R. Buy Size', 'Min Size', 'ISIN', 'GIM2 Symbol'});

    % Hide all
    set(handles.importedDataPanel, 'Visible', 'off');
    set(handles.optimizationPanel, 'Visible', 'off');
    set(handles.filterDataPanel, 'Visible', 'off');
    set(handles.resultsPanel, 'Visible', 'on');

end

function LiqCalc = LiqCalculation(SeriesNames,AmtOut,MatDate,UseOnlyAmtOut)
Series1S=AmtOut;
Series2S= MatDate;
[UNames UIndex]=unique(SeriesNames);
LiqM=[];
for kks=1:1:length(UNames)
    UNamesI=UNames(kks,:);
    UNamesI=UNamesI{:};
    ix = find(strcmp(SeriesNames, UNamesI));
    [~,~,Rnk1]=unique(Series1S(ix,:));
    [~,~,Rnk2]=unique(Series2S(ix,:));
    if UseOnlyAmtOut==1
        LiqM1=Rnk1;
    else
        LiqM1=Rnk1.*Rnk2;
    end
        LiqM2=-LiqM1/sum(LiqM1);
        LiqM=[LiqM;LiqM2];
end
LiqCalc=LiqM;
end


function [x, fval, exitflag] = intlinprogx(f, intcon, A, b, Aeq, beq, lb, ub)
%INTLINPROG A mixed integer linear programming example using the
%   Gurobi MATLAB interface
%
%   This example is based on the intlinprog interface defined in the
%   MATLAB Optimization Toolbox. The Optimization Toolbox
%   is a registered trademark of The MathWorks, Inc.
%
%   x = INTLINPROG(f,intcon,A,b) solves the problem:
%
%   minimize     f'*x
%   subject to   A*x <= b
%                x(j) integer, when j is in the vector
%                intcon of integer constraints
%
%   x = INTLINPROG(f,intcon,A,b,Aeq,beq) solves the problem:
%
%   minimize     f'*x
%   subject to     A*x <= b,
%                Aeq*x == beq
%                x(j) integer, where j is in the vector
%                intcon of integer constraints
%
%   x = INTLINPROG(f,intcon,A,b,Aeq,beq,lb,ub) solves the problem:
%
%   minimize     f'*x
%   subject to     A*x <= b,
%                Aeq*x == beq,
%          lb <=     x <= ub.
%                x(j) integer, where j is in the vector
%                intcon of integer constraints
%
%   You can set lb(j) = -inf, if x(j) has no lower bound,
%   and ub(j) = inf, if x(j) has no upper bound.
%
%   [x, fval] = INTLINPROG(f, intcon, A, b) returns the objective value
%   at the solution. That is, fval = f'*x.
%
%   [x, fval, exitflag] = INTLINPROG(f, intcon, A, b) returns an exitflag
%   containing the status of the optimization. The values for
%   exitflag and corresponding status codes are:
%    2 - Solver stopped prematurely. Integer feasible point found.
%    1 - Optimal solution found.
%    0 - Solver stopped prematurely. No integer feasible point found.
%   -2 - No feasible point found.
%   -3 - Problem is unbounded.

if nargin < 4
    error('intlinprog(f, intcon, A, b)')
end

if nargin > 8
    error('intlinprog(f, intcon, A, b, Aeq, beq, lb, ub)');
end

if ~isempty(A)
    n = size(A, 2);
elseif nargin > 5 && ~isempty(Aeq)
    n = size(Aeq, 2);
else
    error('No linear constraints specified')
end

if ~issparse(A)
    A = sparse(A);
end

if nargin > 4 && ~issparse(Aeq)
    Aeq = sparse(Aeq);
end

model.obj = f;
model.vtype = repmat('C', n, 1);
model.vtype(intcon) = 'I';

if nargin < 5
    model.A = A;
    model.rhs = b;
    model.sense = '<';
else
    model.A = [A; Aeq];
    model.rhs = [b; beq];
    model.sense = [repmat('<', size(A,1), 1); repmat('=', size(Aeq,1), 1)];
end

if nargin < 7
    model.lb = -inf(n,1);
else
    model.lb = lb;
end

if nargin == 8
   model.ub = ub;
end

params.outputflag = 1;
result = gurobi(model, params);


if strcmp(result.status, 'OPTIMAL')
    exitflag = 1;
elseif strcmp(result.status, 'INTERRUPTED')
    if isfield(result, 'x')
        exitflag = 2;
    else
        exitflag = 0;
    end
elseif strcmp(result.status, 'INF_OR_UNBD')
    params.dualreductions = 0;
    result = gurobi(model, params);
    if strcmp(result.status, 'INFEASIBLE')
        exitflag = -2;
    elseif strcmp(result.status, 'UNBOUNDED')
        exitflag = -3;
    else
        exitflag = nan;
    end
else
    exitflag = nan;
end


if isfield(result, 'x')
    x = result.x;
else
    x = nan(n,1);
end

if isfield(result, 'objval')
    fval = result.objval;
else
    fval = nan;
end
end
