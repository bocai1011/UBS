function handles = InitialSetup(handles)

    handles = Support.ClearForm(handles, 'Optimize');
   
    % Allocate basic info
    handles.characteristicsMatrix = zeros(2, 8);
    
    % Calculates info
    % Weights
    handles.characteristicsMatrix(1, 1) = sum(handles.filteredNumericTable(:, 1));
    handles.characteristicsMatrix(2, 1) = sum(handles.filteredNumericTable(:, 2));
    % Duration
    handles.characteristicsMatrix(1, 2) = sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 6));
    handles.characteristicsMatrix(2, 2) = sum(handles.filteredNumericTable(:, 2) .* handles.filteredNumericTable(:, 6));
    % KRD 2Y
    handles.characteristicsMatrix(1, 3) = sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 8));
    handles.characteristicsMatrix(2, 3) = sum(handles.filteredNumericTable(:, 2) .* handles.filteredNumericTable(:, 8));
    % KRD 5Y
    handles.characteristicsMatrix(1, 4) = sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 9));
    handles.characteristicsMatrix(2, 4) = sum(handles.filteredNumericTable(:, 2) .* handles.filteredNumericTable(:, 9));
    % KRD 10Y
    handles.characteristicsMatrix(1, 5) = sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 10));
    handles.characteristicsMatrix(2, 5) = sum(handles.filteredNumericTable(:, 2) .* handles.filteredNumericTable(:, 10));
    % KRD 20Y
    handles.characteristicsMatrix(1, 6) = sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 11));
    handles.characteristicsMatrix(2, 6) = sum(handles.filteredNumericTable(:, 2) .* handles.filteredNumericTable(:, 11));
    % KRD 30Y
    handles.characteristicsMatrix(1, 7) = sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 12));
    handles.characteristicsMatrix(2, 7) = sum(handles.filteredNumericTable(:, 2) .* handles.filteredNumericTable(:, 12));
    % Yield
    handles.characteristicsMatrix(1, 8) = sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 5));
    handles.characteristicsMatrix(2, 8) = sum(handles.filteredNumericTable(:, 2) .* handles.filteredNumericTable(:, 5));
    % Spread
    handles.characteristicsMatrix(1, 9) = sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 7));
    handles.characteristicsMatrix(2, 9) = sum(handles.filteredNumericTable(:, 2) .* handles.filteredNumericTable(:, 7));
   % DTS
    handles.characteristicsMatrix(1, 10) = sum(handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, 7).* handles.filteredNumericTable(:, 6)/100);
    handles.characteristicsMatrix(2, 10) = sum(handles.filteredNumericTable(:, 2) .* handles.filteredNumericTable(:, 7).* handles.filteredNumericTable(:, 6)/100);
    
    % Put info in the form
    % Weights
    set(handles.benchWeightBox, 'String', sprintf('%.2f%%', handles.characteristicsMatrix(1, 1) *  100));
    set(handles.portWeightBox, 'String', sprintf('%.2f%%', handles.characteristicsMatrix(2, 1) *  100));
    set(handles.maxWeightBox, 'String', sprintf('%.2f%%', handles.characteristicsMatrix(1, 1) * 100));
    set(handles.minWeightBox, 'String', sprintf('%.2f%%', max(handles.characteristicsMatrix(1, 1) * 100 - str2double(get(handles.deviationWeightBox, 'String')), 0)));
    % Duration
    set(handles.benchDurationBox, 'String', sprintf('%.2f', handles.characteristicsMatrix(1, 2)));
    set(handles.portDurationBox, 'String', sprintf('%.2f', handles.characteristicsMatrix(2, 2)));
    set(handles.maxDurationBox, 'String', sprintf('%.2f', handles.characteristicsMatrix(1, 2) + str2double(get(handles.deviationDurationBox, 'String'))));
    set(handles.minDurationBox, 'String', sprintf('%.2f', max(handles.characteristicsMatrix(1, 2) - str2double(get(handles.deviationDurationBox, 'String')), 0)));
    % KRD 2Y
    set(handles.benchKRD2Box, 'String', sprintf('%.3f', handles.characteristicsMatrix(1, 3)));
    set(handles.portKRD2Box, 'String', sprintf('%.3f', handles.characteristicsMatrix(2, 3)));
    set(handles.maxKRD2Box, 'String', sprintf('%.3f', handles.characteristicsMatrix(1, 3) + str2double(get(handles.deviationKRD2Box, 'String'))));
    set(handles.minKRD2Box, 'String', sprintf('%.3f', max(handles.characteristicsMatrix(1, 3) - str2double(get(handles.deviationKRD2Box, 'String')), 0)));
    % KRD 5Y
    set(handles.benchKRD5Box, 'String', sprintf('%.3f', handles.characteristicsMatrix(1, 4)));
    set(handles.portKRD5Box, 'String', sprintf('%.3f', handles.characteristicsMatrix(2, 4)));
    set(handles.maxKRD5Box, 'String', sprintf('%.3f', handles.characteristicsMatrix(1, 4) + str2double(get(handles.deviationKRD5Box, 'String'))));
    set(handles.minKRD5Box, 'String', sprintf('%.3f', max(handles.characteristicsMatrix(1, 4) - str2double(get(handles.deviationKRD5Box, 'String')), 0)));
    % KRD 10Y
    set(handles.benchKRD10Box, 'String', sprintf('%.3f', handles.characteristicsMatrix(1, 5)));
    set(handles.portKRD10Box, 'String', sprintf('%.3f', handles.characteristicsMatrix(2, 5)));
    set(handles.maxKRD10Box, 'String', sprintf('%.3f', handles.characteristicsMatrix(1, 5) + str2double(get(handles.deviationKRD10Box, 'String'))));
    set(handles.minKRD10Box, 'String', sprintf('%.3f', max(handles.characteristicsMatrix(1, 5) - str2double(get(handles.deviationKRD10Box, 'String')), 0)));
    % KRD 20Y
    set(handles.benchKRD20Box, 'String', sprintf('%.3f', handles.characteristicsMatrix(1, 6)));
    set(handles.portKRD20Box, 'String', sprintf('%.3f', handles.characteristicsMatrix(2, 6)));
    set(handles.maxKRD20Box, 'String', sprintf('%.3f', handles.characteristicsMatrix(1, 6) + str2double(get(handles.deviationKRD20Box, 'String'))));
    set(handles.minKRD20Box, 'String', sprintf('%.3f', max(handles.characteristicsMatrix(1, 6) - str2double(get(handles.deviationKRD20Box, 'String')), 0)));
    % KRD 30Y
    set(handles.benchKRD30Box, 'String', sprintf('%.3f', handles.characteristicsMatrix(1, 7)));
    set(handles.portKRD30Box, 'String', sprintf('%.3f', handles.characteristicsMatrix(2, 7)));
    set(handles.maxKRD30Box, 'String', sprintf('%.3f', handles.characteristicsMatrix(1, 7) + str2double(get(handles.deviationKRD30Box, 'String'))));
    set(handles.minKRD30Box, 'String', sprintf('%.3f', max(handles.characteristicsMatrix(1, 7) - str2double(get(handles.deviationKRD30Box, 'String')), 0)));
    % Yield
    set(handles.benchYieldBox, 'String', sprintf('%.2f%%', handles.characteristicsMatrix(1, 8) *  100));
    set(handles.portYieldBox, 'String', sprintf('%.2f%%', handles.characteristicsMatrix(2, 8) *  100));
    set(handles.maxYieldBox, 'String', sprintf('%.2f%%', handles.characteristicsMatrix(1, 8) * 100 + str2double(get(handles.deviationYieldBox, 'String'))));
    set(handles.minYieldBox, 'String', sprintf('%.2f%%', max(handles.characteristicsMatrix(1, 8) * 100 - str2double(get(handles.deviationYieldBox, 'String')), 0)));
    % Spread
    set(handles.benchSpreadBox, 'String', sprintf('%.2f', handles.characteristicsMatrix(1, 9)));
    set(handles.portSpreadBox, 'String', sprintf('%.2f', handles.characteristicsMatrix(2, 9)));
    set(handles.maxSpreadBox, 'String', sprintf('%.2f', handles.characteristicsMatrix(1, 9) + str2double(get(handles.deviationSpreadBox, 'String'))));
    set(handles.minSpreadBox, 'String', sprintf('%.2f', max(handles.characteristicsMatrix(1, 9) - str2double(get(handles.deviationSpreadBox, 'String')), 0)));
    %DTS
    set(handles.benchDTSBox, 'String', sprintf('%.2f', handles.characteristicsMatrix(1, 10)));
    set(handles.portDTSBox, 'String', sprintf('%.2f', handles.characteristicsMatrix(2, 10)));
    set(handles.maxDTSBox, 'String', sprintf('%.2f', handles.characteristicsMatrix(1, 10) + str2double(get(handles.deviationDTSBox, 'String'))));
    set(handles.minDTSBox, 'String', sprintf('%.2f', max(handles.characteristicsMatrix(1, 10) - str2double(get(handles.deviationDTSBox, 'String')), 0)));  
    % Number of securities panel
    set(handles.nSecuritiesInPortfolioBox, 'String', sum(handles.filteredNumericTable(:, 2) ~= 0));
    set(handles.nSecuritiesInBenchmarkBox, 'String', sum(handles.filteredNumericTable(:, 1) ~= 0));
    set(handles.nSecuritiesOutOfBenchmarkBox, 'String', sum(handles.filteredNumericTable(:, 1) == 0 & handles.filteredNumericTable(:, 2) ~= 0));
    set(handles.totalNumberOfSecuritiesBox, 'String', size(handles.filteredNumericTable, 1));
    set(handles.nMaxSecuritiesBox, 'String', size(handles.filteredNumericTable, 1));
    set(handles.nMinSecuritiesBox, 'String', 1);
    set(handles.outOfOptimizationList, 'String', ['(None)'; handles.filteredStringTable(:,1)], 'max', size(handles.filteredStringTable, 1));
    
    % Fills Popup box
    optimFunctionsText = {'', 'Min-Individual Weights', 'Max-Liquidity', 'Min-Trans Cost', 'Max-Yield', 'Max-Spread/ATY', 'Min Number of Securities', 'Min Out of portfolio securities', 'Grouped Weights', 'Grouped Duration', 'Grouped KRDs', 'Grouped KRD 0.5Y/2Y', 'Grouped KRD 5Y', 'Grouped KRD 10Y', 'Grouped KRD 20Y', 'Grouped KRD30Y', 'Grouped Yield', 'Grouped Spread','Grouped DTS','Min( Max Grouped Wts)','Min( Max Grouped Durs)','Min( Max Grouped DTS)'};
    set(handles.optimizePopup, 'String', optimFunctionsText);
    
    % Fills Popup Box
    optimizersL={'Matlab','CBC','xxxx','LP_SOLVE','GLPK'};
    set(handles.ChooseSolver,'String',optimizersL);
    set(handles.ChooseSolver,'value',2);
    set(handles.LiquidityCalcType,'value',0);
    
    % Show windows
    set(handles.importedDataPanel, 'Visible', 'off');
    set(handles.filterDataPanel, 'Visible', 'off');
    set(handles.resultsPanel, 'Visible', 'off');
    set(handles.optimizationPanel, 'Visible', 'on');
    

end