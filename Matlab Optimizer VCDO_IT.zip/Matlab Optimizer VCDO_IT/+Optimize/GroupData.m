function handles = GroupData(handles, type)

% Constraint
if strcmp(type, 'Constraint')
    
    handles.currentSecurityGroupMapping = [];
    typeColumnID = get(handles.groupingTypePopup, 'Value');
    groupColumnID = get(handles.groupByPopup, 'Value') - 1;
    groupColumnName = get(handles.groupByPopup, 'String');
    parameterColumnID = get(handles.parameterPopup, 'Value') - 1;
    parameterColumnName = get(handles.parameterPopup, 'String');
    deviation = str2double(get(handles.deviationBox, 'String'));
    maxDeviation = str2double(get(handles.maxDeviationBox, 'String'));
    nBuckets = str2double(get(handles.nBucketsBox, 'String'));
    nSecurities = size(handles.filteredNumericTable, 1);
    
elseif strcmp(type, 'Result')
    
    typeColumnID = get(handles.groupingBucketingPopup, 'Value');
    groupColumnID = get(handles.resultGroupByPopup, 'Value') - 1;
    groupColumnName = get(handles.resultGroupByPopup, 'String');
    parameterColumnID = get(handles.resultParameterPopup, 'Value') - 1;
    parameterColumnName = get(handles.resultParameterPopup, 'String');
    nBuckets = str2double(get(handles.resultNBucketsBox, 'String'));
    nSecurities = size(handles.filteredNumericTable, 1);
end

if typeColumnID ~= 1 && groupColumnID ~= 0 && parameterColumnID ~= 0
    % Grouping
    if typeColumnID == 2
        
        % Groups information
        [names, ~, index] = unique(handles.filteredStringTable(:, groupColumnID + 3));
        
        % Bucketing
    elseif typeColumnID == 3
        
        % Checks if there is at least one bucket defined
        if nBuckets <= 0
            errordlg('There should be at least one bucket');
            error('There should be at least one bucket');
        end
        
        % Calculate index for the buckets
        index = ones(nSecurities, 1) * nBuckets;
        names = cell(nBuckets, 1);
        maxValue = max(handles.filteredNumericTable(:, groupColumnID));
        minValue = min(handles.filteredNumericTable(:, groupColumnID));
        bucketSize = (maxValue - minValue) / nBuckets;
        
        for bucket=1:nBuckets
            minTreshold = minValue + bucketSize * (bucket - 1);
            maxTreshold = minValue + bucketSize * bucket;
            if groupColumnID == 3 || groupColumnID == 17
                names(bucket) = {[datestr(minTreshold, 'mm/dd/yyyy'), ' to ', datestr(maxTreshold, 'mm/dd/yyyy')]};
            else
                names(bucket) = {[sprintf(' %.2f', minTreshold), ' to ', sprintf(' %.2f', maxTreshold)]};
            end
            if bucket < nBuckets
                index(handles.filteredNumericTable(:, groupColumnID) >= minTreshold  & handles.filteredNumericTable(:, groupColumnID) < maxTreshold) =  bucket;
            end
        end
    end
    
    % Get the column used on each parameter
    switch parameterColumnID
        case 1
            originalParameterColumnID = 1;
        case 2
            originalParameterColumnID = 6;
        case 3
            originalParameterColumnID = 8;
        case 4
            originalParameterColumnID = 9;
        case 5
            originalParameterColumnID = 10;
        case 6
            originalParameterColumnID = 11;
        case 7
            originalParameterColumnID = 12;
        case 8
            originalParameterColumnID = 5;
        case 9
            originalParameterColumnID = 7;
        case 10
            originalParameterColumnID = 800;
        case 11
            originalParameterColumnID = 6;
            originalParameterColumnID_S =7;
    end
    
    % Initialize variables
    nGroups = max(index);
    groupedTable = zeros(nGroups, 6);
    if (parameterColumnID == 1)
        formattedGroupedTable = cell(nGroups, 5);
    else
        formattedGroupedTable = cell(nGroups, 7);
    end
    
    % Name
    formattedGroupedTable(:, 1) = names;
    
    % Buy size
    groupedTable(:, 5) = accumarray(index, handles.filteredNumericTable(:, 4)) ./ accumarray(index, handles.filteredNumericTable(:, 18),[],@min);
    
    % Min size
    groupedTable(:, 6) = accumarray(index, handles.filteredNumericTable(:, 15),[],@min);
    
    %
    padding = 0;
    if strcmp(type, 'Result')
        padding = 1;
    end
    
    % BM/Port Weights and parameters
    groupedTable(:, 1) = accumarray(index, handles.filteredNumericTable(:, 1));
    groupedTable(:, 2) = accumarray(index, handles.filteredNumericTable(:, 2));
    if parameterColumnID == 1
        groupedTable(:, 3) = accumarray(index, handles.filteredNumericTable(:, 1));
        groupedTable(:, 4) = accumarray(index, handles.filteredNumericTable(:, 2));
        groupedTable(isnan(groupedTable)) = 0;
        formattedGroupedTable(:, 4) = strread(sprintf(' %.2f%%', groupedTable(:, 1) * 100), '%s', 'delimiter', ' ');
        formattedGroupedTable(:, 5) = strread(sprintf(' %.2f%%', groupedTable(:, 2) * 100), '%s', 'delimiter', ' ');
        if strcmp(type, 'Result')
            formattedGroupedTable(:, 6) = strread(sprintf(' %.2f%%', accumarray(index, handles.lastSolution + handles.filteredNumericTable(:, 2)) * 100), '%s', 'delimiter', ' ');
        end
        
        groupedTable(:, 3) = accumarray(index, ones(length(index),1));
        groupedTable(:, 4) = accumarray(index, ones(length(index),1));
    else
        if parameterColumnID==10
            groupedTable(:, 3) = accumarray(index, ones(length(index),1).*(handles.filteredNumericTable(:, 1)>0));
            groupedTable(:, 4) = accumarray(index, ones(length(index),1).*(handles.filteredNumericTable(:, 2)>0));
        else
            if parameterColumnID==11
                groupedTable(:, 3) = accumarray(index, handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, originalParameterColumnID).* handles.filteredNumericTable(:, originalParameterColumnID_S)/100);
                groupedTable(:, 4) = accumarray(index, handles.filteredNumericTable(:, 2) .* handles.filteredNumericTable(:, originalParameterColumnID).* handles.filteredNumericTable(:, originalParameterColumnID_S)/100);
            else
                groupedTable(:, 3) = accumarray(index, handles.filteredNumericTable(:, 1) .* handles.filteredNumericTable(:, originalParameterColumnID));
                groupedTable(:, 4) = accumarray(index, handles.filteredNumericTable(:, 2) .* handles.filteredNumericTable(:, originalParameterColumnID));
            end
        end
        groupedTable(isnan(groupedTable)) = 0;
        if parameterColumnID == 8
            formattedGroupedTable(:, 6 + padding) = strread(sprintf(' %.2f%%', groupedTable(:, 3) * 100), '%s', 'delimiter', ' ');
            formattedGroupedTable(:, 7 + padding) = strread(sprintf(' %.2f%%', groupedTable(:, 4) * 100), '%s', 'delimiter', ' ');
            if strcmp(type, 'Result')
                formattedGroupedTable(:, 6) = strread(sprintf(' %.2f%%', accumarray(index, handles.lastSolution + handles.filteredNumericTable(:, 2)) * 100), '%s', 'delimiter', ' ');
                formattedGroupedTable(:, 9) = strread(sprintf(' %.2f%%', accumarray(index, (handles.lastSolution + handles.filteredNumericTable(:, 2)) .* handles.filteredNumericTable(:, originalParameterColumnID)) * 100), '%s', 'delimiter', ' ');
            end
        else
            formattedGroupedTable(:, 6 + padding) = strread(sprintf(' %.3f', groupedTable(:, 3)), '%s', 'delimiter', ' ');
            formattedGroupedTable(:, 7 + padding) = strread(sprintf(' %.3f', groupedTable(:, 4)), '%s', 'delimiter', ' ');
            if strcmp(type, 'Result')
                formattedGroupedTable(:, 6) = strread(sprintf(' %.2f%%', accumarray(index, handles.lastSolution + handles.filteredNumericTable(:, 2)) * 100), '%s', 'delimiter', ' ');
                if parameterColumnID==11
                    formattedGroupedTable(:, 9) = strread(sprintf(' %.3f', accumarray(index, (handles.lastSolution + handles.filteredNumericTable(:, 2)) .* handles.filteredNumericTable(:, originalParameterColumnID).* handles.filteredNumericTable(:, originalParameterColumnID_S)/100)), '%s', 'delimiter', ' ');
                else
                    formattedGroupedTable(:, 9) = strread(sprintf(' %.3f', accumarray(index, (handles.lastSolution + handles.filteredNumericTable(:, 2)) .* handles.filteredNumericTable(:, originalParameterColumnID))), '%s', 'delimiter', ' ');
                    
                end
            end
        end
        formattedGroupedTable(:, 4) = strread(sprintf(' %.2f%%', groupedTable(:, 1) * 100), '%s', 'delimiter', ' ');
        formattedGroupedTable(:, 5) = strread(sprintf(' %.2f%%', groupedTable(:, 2) * 100), '%s', 'delimiter', ' ');
    end
    formattedGroupedTable(:, 2) = arrayfun(@(x) Support.separatethousands(x, ',', 0), groupedTable(:, 5), 'UniformOutput', 0);
    formattedGroupedTable(:, 3) = arrayfun(@(x) Support.separatethousands(x, ',', 0), groupedTable(:, 6), 'UniformOutput', 0);
    
    % Eliminate rows that there is not relevant info
    unusedRows = (groupedTable(:, 1) == 0 & groupedTable(:, 2) == 0);
    formattedGroupedTable(unusedRows, :) = [];
    
    if strcmp(type, 'Constraint')
        % If the selected parameter is the weight, we have special
        % constraints
        if parameterColumnID == 1
            benchGreaterThanPort = (groupedTable(:, 1) >= groupedTable(:, 2) & groupedTable(:, 5) <= groupedTable(:, 6));
            portGreaterThanBench = (groupedTable(:, 1) <= groupedTable(:, 2) & groupedTable(:, 5) <= groupedTable(:, 6));
            
            minValues(benchGreaterThanPort, 1) = min(groupedTable(benchGreaterThanPort, 1) - maxDeviation / 100, groupedTable(benchGreaterThanPort, 2));
            maxValues(portGreaterThanBench, 1) = max(groupedTable(portGreaterThanBench, 1) + maxDeviation / 100, groupedTable(portGreaterThanBench, 2));
            minValues(benchGreaterThanPort == 0, 1) = groupedTable(benchGreaterThanPort == 0, 1) - deviation / 100;
            maxValues(portGreaterThanBench == 0, 1) = groupedTable(portGreaterThanBench == 0, 1) + deviation / 100;
            
            minValues = strread(sprintf(' %.2f%%', max(minValues * 100, 0)), '%s', 'delimiter', ' ');
            maxValues = strread(sprintf(' %.2f%%', maxValues * 100), '%s', 'delimiter', ' ');
        elseif parameterColumnID == 8
            minValues = strread(sprintf(' %.2f%%', max(-deviation / 100+ groupedTable(:, 3), 0) * 100), '%s', 'delimiter', ' ');
            maxValues = strread(sprintf(' %.2f%%', (deviation / 100+ groupedTable(:, 3)) * 100), '%s', 'delimiter', ' ');
        else
            minValues = strread(sprintf(' %.3f', max(-deviation + groupedTable(:, 3), 0)), '%s', 'delimiter', ' ');
            maxValues = strread(sprintf(' %.3f', deviation + groupedTable(:, 3)), '%s', 'delimiter', ' ');
        end
        
        
        % Security/group mapping table
        handles.currentSecurityGroupMapping = zeros(nGroups, nSecurities);
        for group=1:nGroups
            handles.currentSecurityGroupMapping(group, :) = (index == group)';
        end
        
        handles.currentSecurityGroupMapping(unusedRows, :) = [];
        minValues(unusedRows, :) = [];
        maxValues(unusedRows, :) = [];
        
        % Formatting for weights
        if (parameterColumnID == 1)
            columnNames = {char(groupColumnName(groupColumnID + 1)), 'Buy Size', 'Min Size', char(strcat({'BM '}, parameterColumnName(parameterColumnID + 1))), char(strcat({'Port '}, parameterColumnName(parameterColumnID + 1))), char(strcat({'Min '}, parameterColumnName(parameterColumnID + 1))), char(strcat({'Max '}, parameterColumnName(parameterColumnID + 1))), 'Constraint?'};
            editableColumns = [false(1, 5), true(1, 3)];
        else
            columnNames = {char(groupColumnName(groupColumnID + 1)), 'Buy Size', 'Min Size' ,'BM Wts', 'Port Wts', char(strcat({'BM '}, parameterColumnName(parameterColumnID + 1))), char(strcat({'Port '}, parameterColumnName(parameterColumnID + 1))), char(strcat({'Min '}, parameterColumnName(parameterColumnID + 1))), char(strcat({'Max '}, parameterColumnName(parameterColumnID + 1))), 'Constraint?'};
            editableColumns = [false(1, 7), true(1, 3)];
        end
        
        % Fill table
        optic={false};
        if get(handles.OptiSelectAllCons, 'Value')==1
            optic={true};
        end;
        
        if ~isnan(str2double(strrep(get(handles.MinConstraintAll, 'String'), '%', '')));
            minAllValue = str2double(strrep(get(handles.MinConstraintAll, 'String'), '%', ''));
            tempminValues=repmat(minAllValue,size(minValues,1),1);
            if (parameterColumnID == 1 || parameterColumnID == 7)
                minValues = strread(sprintf(' %.2f%%', tempminValues), '%s', 'delimiter', ' ');
            else
                minValues = strread(sprintf(' %.3f', tempminValues), '%s', 'delimiter', ' ');
            end
        end;
        if ~isnan(str2double(strrep(get(handles.MaxConstraintAll, 'String'), '%', '')));
            maxAllValue = str2double(strrep(get(handles.MaxConstraintAll, 'String'), '%', ''));
            tempmaxValues=repmat(maxAllValue,size(maxValues,1),1);
            maxValues = strread(sprintf(' %.2f%%', tempmaxValues), '%s', 'delimiter', ' ');
            if (parameterColumnID == 1 || parameterColumnID == 7)
                maxValues = strread(sprintf(' %.2f%%', tempmaxValues), '%s', 'delimiter', ' ');
            else
                maxValues = strread(sprintf(' %.3f', tempmaxValues), '%s', 'delimiter', ' ');
            end
        end;
        
        %minValue = str2double(strrep(get(handles.minimumAmountBox, 'String'), '%', '')) / 100
        additionalColumns = [minValues, maxValues, repmat(optic, size(formattedGroupedTable, 1), 1)];
        set(handles.groupingTable, 'Data', [formattedGroupedTable, additionalColumns], 'ColumnName', columnNames, 'ColumnEditable', editableColumns);
    elseif strcmp(type, 'Result')
        % Formatting for weights
        if (parameterColumnID == 1)
            columnNames = {char(groupColumnName(groupColumnID + 1)), 'Buy Size', 'Min Size', char(strcat({'BM '}, parameterColumnName(parameterColumnID + 1))), char(strcat({'Old Port '}, parameterColumnName(parameterColumnID + 1))), char(strcat({'New Port '}, parameterColumnName(parameterColumnID + 1)))};
            editableColumns = false(1, 5);
        else
            columnNames = {char(groupColumnName(groupColumnID + 1)), 'Buy Size', 'Min Size' ,'BM Wts', 'Old Port Wts', 'New Port Wts', char(strcat({'BM '}, parameterColumnName(parameterColumnID + 1))), char(strcat({'Old Port '}, parameterColumnName(parameterColumnID + 1))), char(strcat({'New Port '}, parameterColumnName(parameterColumnID + 1)))};
            editableColumns = false(1, 7);
        end
        
        % Fill table
        set(handles.resultGroupingTable, 'Data', formattedGroupedTable, 'ColumnName', columnNames, 'ColumnEditable', editableColumns);
    end
    
else
    if strcmp(type, 'Constraint')
        set(handles.groupingTable, 'Data', [], 'ColumnName', [], 'ColumnEditable', []);
    elseif strcmp(type, 'Result')
        set(handles.resultGroupingTable, 'Data', [], 'ColumnName', [], 'ColumnEditable', []);
    end
end
end