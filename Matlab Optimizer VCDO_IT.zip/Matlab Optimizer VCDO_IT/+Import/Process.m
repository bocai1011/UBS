% String unified data format:
% Name (BBG) | ISIN | GIM2 Symbol | Ticker | Currency | Selected columns
%      1     |  2   |     3       |   4    |    5     |     6...n

% Numeric unified data format:
% Benchmark Weight (%) | Portfolio Weight (%) |  Maturity  |MV x BM wgt | Yield (%)| Duration | Spread | KRD 0.5Y/2Y | KRD 5Y | KRD 10Y | KRD 20Y/30Y | Bid (BBG) | Ask (BBG) | Min Piece (BBG) | Amt Outstanding (BBG) | Issue Date (BBG) | Tkt Tot Amount (BBG)
%           1          |            2         |       3    |       4    |      5   |  6       |  7     |     8       |    9   |   10    |       11    |   12      |   13      |      14         |       15              |       16         |         17

function handles = Process(handles)

    % Clear info for next ones
    handles = Support.ClearForm(handles, 'Filter');

    % Get all the form information
    maturityColumnID = get(handles.maturityColumnPopup, 'Value') - 1;
    ISINColumnID = get(handles.ISINColumnPopup, 'Value') - 1;
    GIM2SymbolColumnID = get(handles.GIM2SymbolColumnPopup, 'Value') - 1;
    tickerColumnID = get(handles.tickerColumnPopup, 'Value') - 1;
    yieldColumnID = get(handles.yieldColumnPopup, 'Value') - 1;
    durationColumnID = get(handles.durationColumnPopup, 'Value') - 1;
    spreadColumnID = get(handles.spreadColumnPopup, 'Value') - 1;
    currencyColumnID = get(handles.currencyColumnPopup, 'Value') - 1;
    KRD05ColumnID = get(handles.KRD05ColumnPopup, 'Value') - 1;
    KRD2ColumnID = get(handles.KRD2ColumnPopup, 'Value') - 1;
    KRD5ColumnID = get(handles.KRD5ColumnPopup, 'Value') - 1;
    KRD10ColumnID = get(handles.KRD10ColumnPopup, 'Value') - 1;
    KRD20ColumnID = get(handles.KRD20ColumnPopup, 'Value') - 1;
    KRD30ColumnID = get(handles.KRD30ColumnPopup, 'Value') - 1;
    weightColumnID = get(handles.weightColumnPopup, 'Value') - 1;
    handles.currentPortfolioSize = str2double(get(handles.currentPortfolioSizeBox, 'String')) * 1000000;
    handles.newPortfolioSize = str2double(get(handles.newPortfolioSizeBox, 'String')) * 1000000;
    handles.fileWeights = get(handles.weightsTable, 'Data');
    selectedColumnsID = get(handles.filterFieldsList,'Value');
    selectedColumnsID = selectedColumnsID(selectedColumnsID ~= 1) - 1;
    nRowsBench = size(handles.benchmarkRawData, 1);
    nRowsPort = size(handles.portfolioRawData, 1);
    lastColumn = size(handles.benchmarkRawData , 2);

    % Check for errors
    if maturityColumnID == 0 || ISINColumnID == 0 || GIM2SymbolColumnID == 0 || tickerColumnID == 0 || yieldColumnID == 0 || durationColumnID == 0 || spreadColumnID == 0 || currencyColumnID == 0 || KRD05ColumnID == 0 || KRD2ColumnID == 0 || KRD5ColumnID == 0 || KRD10ColumnID == 0 || KRD20ColumnID == 0 || KRD30ColumnID == 0 || weightColumnID == 0
        errordlg('All columns must be selected');
        error('All columns must be selected');
    end
    if handles.newPortfolioSize == 0
        errordlg('New portfolio size is zero');
        error('New portfolio size is zero');
    end
    
    columnNumb = size(selectedColumnsID,2);
    fprintf('Selected Columns %d \n', columnNumb);
    fprintf('Selected Columns %g \n', selectedColumnsID);
    fprintf('Number of columns in the frame is %d \n', currencyColumnID);
    fprintf('Number of columns in the frame is %d \n',  handles.currencySpotCurrencies);

    % impute missing values  "N/A" in benchmark data with 1.

    % Substitutes 'N/A's for 0 on the number columns
    %numericColumns = [maturityColumnID, yieldColumnID, durationColumnID, spreadColumnID, KRD05ColumnID, KRD2ColumnID, KRD5ColumnID, KRD10ColumnID, KRD20ColumnID, KRD30ColumnID, weightColumnID];


    %handles.benchmarkRawData(strcmp(handles.benchmarkRawData(:,1), 'N/A'),handles.benchmarkRawData(:,1)) = 'BBG Data not available';






    %knnimpute(handles.benchmarkRawData)

    if strcmp(handles.benchmarkRawData(1,1), 'N/A')
        errordlg('Data not downloaded from Bloomberg');
        error('Data not downloaded from Bloomberg');
    end

    % Makes copies from the original
    benchmarktemp = handles.benchmarkRawData;
    portfolioTemp = handles.portfolioRawData;

    % Get the columns that will be used
    %fprintf('Selected column id is %10g \n', selectedColumnsID);
    % Additional columns not being populated
    additionalColumns = [selectedColumnsID(selectedColumnsID ~= 1 & selectedColumnsID ~= maturityColumnID & selectedColumnsID ~= ISINColumnID & selectedColumnsID ~= GIM2SymbolColumnID  & selectedColumnsID ~= tickerColumnID & selectedColumnsID ~= yieldColumnID & selectedColumnsID ~= durationColumnID & selectedColumnsID ~= spreadColumnID & selectedColumnsID ~= currencyColumnID & selectedColumnsID ~= KRD05ColumnID & selectedColumnsID ~= KRD2ColumnID & selectedColumnsID ~= KRD5ColumnID & selectedColumnsID ~= KRD10ColumnID & selectedColumnsID ~= KRD20ColumnID & selectedColumnsID ~= KRD30ColumnID & selectedColumnsID ~= weightColumnID & selectedColumnsID ~= lastColumn - 6 & selectedColumnsID ~= lastColumn - 5 & selectedColumnsID ~= lastColumn - 4 & selectedColumnsID ~= lastColumn - 3 & selectedColumnsID ~= lastColumn - 2 & selectedColumnsID ~= lastColumn - 1)];
    %additionalColumns = ["Exposure Country","Country_Sector","Market Sector"]
    nAdditionalColumns = size(additionalColumns, 2);

    fprintf('Size of additional columns is %d \n', nAdditionalColumns);

    % Normalize weights
    handles.fileWeights(:, 2) = num2cell(cell2mat(handles.fileWeights(:, 2)) / sum(cell2mat(handles.fileWeights(:, 2))));

    % Weight the weights
    for file=1:size(handles.fileWeights, 1)
        benchmarktemp(cell2mat(benchmarktemp(:, size(benchmarktemp, 2))) == file, weightColumnID) = num2cell(cell2mat(benchmarktemp(cell2mat(benchmarktemp(:, size(benchmarktemp, 2))) == file, weightColumnID)) * cell2mat(handles.fileWeights(file, 2)));
    end
    % Format the maturity date
    benchmarktemp(:, maturityColumnID) = num2cell(datenum(benchmarktemp(:, maturityColumnID)));

    if nRowsPort ~= 0
         % The same, but for the portfolio if needed
        portfolioTemp(:, maturityColumnID) = num2cell(datenum(portfolioTemp(:, maturityColumnID)));

        % Join tables
        [allNames, ~, newOrder] = unique([benchmarktemp(:, 1); portfolioTemp(:, 1)]);
        if get(handles.aggsimnames, 'Value')==0
            allNames=[benchmarktemp(:, 1); portfolioTemp(:, 1)];
            newOrder=1:1:length([benchmarktemp(:, 1); portfolioTemp(:, 1)]);
            newOrder=newOrder';
        end;
        accumSumBench = accumarray(newOrder, cell2mat([benchmarktemp(:, weightColumnID); zeros(nRowsPort, 1)]));
        accumSumPort = accumarray(newOrder, cell2mat([zeros(nRowsBench, 1); portfolioTemp(:, weightColumnID)]));
        indexBench = newOrder(1:size(benchmarktemp(:, 1), 1));
        indexPort = newOrder(size(benchmarktemp(:, 1), 1) + 1:end);
    else
        [allNames, ~, newOrder] = unique(benchmarktemp(:, 1));
        if get(handles.aggsimnames, 'Value')==0
            allNames=benchmarktemp(:, 1);
            newOrder=1:1:length(benchmarktemp(:, 1));
            newOrder=newOrder';
        end;
        accumSumBench = accumarray(newOrder, cell2mat(benchmarktemp(:, weightColumnID)));
        indexBench = newOrder;
    end

    % Substitutes 'N/A's for 0 on the number columns
    numericColumns = [maturityColumnID, yieldColumnID, durationColumnID, spreadColumnID, KRD05ColumnID, KRD2ColumnID, KRD5ColumnID, KRD10ColumnID, KRD20ColumnID, KRD30ColumnID, weightColumnID];
    for column=1:size(numericColumns, 2)
        benchmarktemp(strcmp(benchmarktemp(:, numericColumns(column)), 'N/A'), numericColumns(column)) = {0};
        if nRowsPort ~= 0
            portfolioTemp(strcmp(portfolioTemp(:, numericColumns(column)), 'N/A'), numericColumns(column)) = {0};
        end
    end

    % Allocates table
    handles.unifiedStringTable = cell(size(allNames, 1), nAdditionalColumns + 5);
    handles.unifiedNumericTable = zeros(size(allNames, 1), 17);
    handles.unifiedStringTable(:) = {'N/A'};

    % Copies data for the string table
    handles.unifiedStringTable(:, 1) = allNames;
    handles.unifiedStringTable(indexBench, 2) = benchmarktemp(:, ISINColumnID);
    handles.unifiedStringTable(indexBench, 3) = benchmarktemp(:, GIM2SymbolColumnID);
    handles.unifiedStringTable(indexBench, 4) = benchmarktemp(:, tickerColumnID);
    handles.unifiedStringTable(indexBench, 5) = benchmarktemp(:, currencyColumnID);
    for field=1:nAdditionalColumns
        handles.unifiedStringTable(indexBench, 5 + field) = benchmarktemp(:, additionalColumns(field));
        if nRowsPort ~= 0
            handles.unifiedStringTable(indexPort, 5 + field) = portfolioTemp(:, additionalColumns(field));
        end
    end
    if nRowsPort ~= 0
        handles.unifiedStringTable(indexPort, 2) = portfolioTemp(:, ISINColumnID);
        handles.unifiedStringTable(indexPort, 3) = portfolioTemp(:, GIM2SymbolColumnID);
        handles.unifiedStringTable(indexPort, 4) = portfolioTemp(:, tickerColumnID);
        handles.unifiedStringTable(indexPort, 5) = portfolioTemp(:, currencyColumnID);
    end

    handles.currencySpotCurrencies = [handles.currencySpotCurrencies; 'USD'];
    handles.currencySpotValues = [handles.currencySpotValues; 1];
    fprintf('Number of columns in the frame is %d \n', currencyColumnID);
    fprintf('Number of columns in the frame is %d \n',  handles.currencySpotCurrencies);

    % Get conversion values
    [~, index] = ismember(benchmarktemp(:, currencyColumnID), handles.currencySpotCurrencies);
    conversion = handles.currencySpotValues(index);

    % Copies data for the numeric table
    handles.unifiedNumericTable(:, 1) = accumSumBench;
    handles.unifiedNumericTable(indexBench, 3) = cell2mat(benchmarktemp(:, maturityColumnID));
    handles.unifiedNumericTable(indexBench, 4) = cell2mat(benchmarktemp(:, weightColumnID)) * handles.newPortfolioSize
    ;
    handles.unifiedNumericTable(indexBench, 5: 6) = cell2mat(benchmarktemp(:, [yieldColumnID, durationColumnID]));
    [~, map] = ismember(benchmarktemp(:, currencyColumnID), handles.currencySpotCurrencies);
    if get(handles.AfterTaxYield, 'Value')==1
        set(handles.spreadText, 'String','AT Yield');
    handles.unifiedNumericTable(indexBench, 7) = cell2mat(benchmarktemp(:, spreadColumnID));
    else
    % Matrix multiplication for currency conversion for non USD exposure.
    %handles.unifiedNumericTable(indexBench, 7) = cell2mat(benchmarktemp(:, spreadColumnID)) .* strcmp(benchmarktemp(:, currencyColumnID), 'USD') + ((cell2mat(benchmarktemp(:, yieldColumnID)) - handles.yieldValues(map) / 100) .* (strcmp(benchmarktemp(:, currencyColumnID), 'USD') == 0)) * 10000;
    handles.unifiedNumericTable(indexBench, 7) = cell2mat(benchmarktemp(:, spreadColumnID));
    end
    handles.unifiedNumericTable(indexBench, 8) = cell2mat(benchmarktemp(:, KRD05ColumnID)) + cell2mat(benchmarktemp(:, KRD2ColumnID));
    handles.unifiedNumericTable(indexBench, 9: 10) = cell2mat(benchmarktemp(:, [KRD5ColumnID, KRD10ColumnID]));
    handles.unifiedNumericTable(indexBench, 11) = cell2mat(benchmarktemp(:, KRD20ColumnID));
    handles.unifiedNumericTable(indexBench, 12) = cell2mat(benchmarktemp(:, KRD30ColumnID));
    handles.unifiedNumericTable(indexBench, 13:16) = cell2mat(benchmarktemp(:, lastColumn - 6:lastColumn - 3)) ./ repmat(conversion, 1, 4);

    fprintf('lastColumn is %d \n', lastColumn);
    fprintf('Currency spot rates is %d \n',  handles.currencySpotCurrencies);
    temp = benchmarktemp(1,lastColumn - 2)
    fprintf('lastColumn -2 is %d \n', temp{1});

    benchmarktemp(:, lastColumn - 2) = num2cell(datenum(benchmarktemp(:, lastColumn - 2)));
    handles.unifiedNumericTable(indexBench, 17) = cell2mat(benchmarktemp(:, lastColumn - 2));
    handles.unifiedNumericTable(indexBench, 18) = cell2mat(benchmarktemp(:, lastColumn - 1)) / 1000000 ./ conversion;

    if nRowsPort ~= 0
        conversion = handles.currencySpotValues(cellfun(@(x) find(strcmp(x, handles.currencySpotCurrencies)), portfolioTemp(:, currencyColumnID)));
        handles.unifiedNumericTable(:, 2) = accumSumPort * handles.currentPortfolioSize / handles.newPortfolioSize;
        handles.unifiedNumericTable(indexPort, 3) = cell2mat(portfolioTemp(:, maturityColumnID));
        handles.unifiedNumericTable(indexPort, 5: 6) = cell2mat(portfolioTemp(:, [yieldColumnID, durationColumnID]));
        [~, map] = ismember(portfolioTemp(:, currencyColumnID), handles.currencySpotCurrencies);
        if get(handles.AfterTaxYield, 'Value')==1
        handles.unifiedNumericTable(indexPort, 7) = cell2mat(portfolioTemp(:, spreadColumnID));
        else
        %handles.unifiedNumericTable(indexPort, 7) = cell2mat(portfolioTemp(:, spreadColumnID)) .* strcmp(portfolioTemp(:, currencyColumnID), 'USD') + ((cell2mat(portfolioTemp(:, yieldColumnID)) - handles.yieldValues(map) / 100) .* (strcmp(portfolioTemp(:, currencyColumnID), 'USD') == 0)) * 10000;
        handles.unifiedNumericTable(indexPort, 7) = cell2mat(portfolioTemp(:, spreadColumnID));
        end;
        handles.unifiedNumericTable(indexPort, 8) = cell2mat(portfolioTemp(:, KRD05ColumnID)) + cell2mat(portfolioTemp(:, KRD2ColumnID));
        handles.unifiedNumericTable(indexPort, 9: 10) = cell2mat(portfolioTemp(:, [KRD5ColumnID, KRD10ColumnID]));
        handles.unifiedNumericTable(indexPort, 11) = cell2mat(portfolioTemp(:, KRD20ColumnID));
        handles.unifiedNumericTable(indexPort, 12) = cell2mat(portfolioTemp(:, KRD30ColumnID));
        handles.unifiedNumericTable(indexPort, 13:16) = cell2mat(portfolioTemp(:, lastColumn - 6:lastColumn - 3)) ./ repmat(conversion, 1, 4);
        portfolioTemp(:, lastColumn - 2) = num2cell(datenum(portfolioTemp(:, lastColumn - 2)));
        handles.unifiedNumericTable(indexPort, 17) = cell2mat(portfolioTemp(:, lastColumn - 2));
        handles.unifiedNumericTable(indexPort, 18) = cell2mat(portfolioTemp(:, lastColumn - 1)) / 1000000 ./ conversion;
    end

    % Setting GUI parameters

    handles.unifiedColumnNames = [handles.allColumnNames(1), {'ISIN', 'GIM2 Symbol', 'Ticker', 'Currency'}, handles.allColumnNames(additionalColumns), {'BM Wgt', 'Port Wgt', 'Maturity', 'New Port Value x BM Wgt', 'Yield', 'Duration', 'Spread', 'KRD 0.5Y/2Y', 'KRD 5Y', 'KRD 10Y', 'KRD 20Y',' KRD 30Y'}, handles.allColumnNames(lastColumn - 6:lastColumn - 1)];
    %handles.unifiedColumnNames = [handles.allColumnNames(1),{'ISIN', 'GIM2 Symbol', 'Ticker','Currency','Exposure Country','Country_Sector',}, handles.allColumnNames(additionalColumns), {'BM Wgt', 'Port Wgt', 'Maturity', 'New Port Value x BM Wgt', 'Yield', 'Duration', 'Spread', 'KRD 0.5Y/2Y', 'KRD 5Y', 'KRD 10Y', 'KRD 20Y',' KRD 30Y', 'Bid (BBG)', 'Ask (BBG)', 'Min Piece (BBG)','Amt Outstanding (BBG)','Issue Date (BBG)', 'Tkt Tot Amount (BBG)'} ];

    set(handles.selectedFieldsTable, 'Data', [handles.unifiedStringTable, Filter.FormatTable(handles.unifiedNumericTable)], 'ColumnName', handles.unifiedColumnNames);
    set(handles.sortByPopup1, 'String', [{''}, handles.unifiedColumnNames], 'Value', 1);
    set(handles.sortByPopup2, 'String', [{''}, handles.unifiedColumnNames], 'Enable', 'off', 'Value', 1);
    set(handles.sortByPopup3, 'String', [{''}, handles.unifiedColumnNames], 'Enable', 'off', 'Value', 1);
    if nAdditionalColumns > 0
        set(handles.filterPopup1, 'String', [{''}, handles.unifiedColumnNames(4:nAdditionalColumns + 5)], 'Value', 1);
        set(handles.filterPopup2, 'String', [{''}, handles.unifiedColumnNames(4:nAdditionalColumns + 5)], 'Enable', 'off', 'Value', 1);
    else
        set(handles.filterPopup1, 'String', {''}, 'Value', 1);
        set(handles.filterPopup2, 'String', {''}, 'Enable', 'off', 'Value', 1);
    end
    set(handles.filterEqualsList1, 'String', {''}, 'Enable', 'off', 'Value', 1);
    set(handles.filterEqualsList2, 'String', {''}, 'Enable', 'off', 'Value', 1);

    % Hide all
    set(handles.importedDataPanel, 'Visible', 'off');
    set(handles.optimizationPanel, 'Visible', 'off');
    set(handles.resultsPanel, 'Visible', 'off');
    set(handles.filterDataPanel, 'Visible', 'on');

    % Copy for filter
    handles.filteredStringTable = handles.unifiedStringTable;
    handles.filteredNumericTable = handles.unifiedNumericTable;

end
