function handles = GetBBGData(handles)
    clc
    % Get all the form info
    ISINColumnID = get(handles.ISINColumnPopup, 'Value') - 1;
    currencyColumnID = get(handles.currencyColumnPopup, 'Value') - 1;
    nBench = size(handles.benchmarkRawData, 1);
    nPort = size(handles.portfolioRawData, 1);
    nColumns = size(handles.benchmarkRawData,  2);
    nTotal = 2 * (nBench + nPort);
    
    % Checks if a file has been imported
    if isfield(handles, 'benchmarkRawData') == 0
        errordlg('No benchmark file imported');
        error('No benchmark file imported');
    end
    
    % Check if the ISIN column was changed
    if ISINColumnID == 0
        errordlg('No ISIN column selected');
        error('No ISIN column selected');
    end
    
    % Download from BBG
    bar = waitbar(0, 'Initializing waitbar...');
    benchmarkBBGData = [GetBBG(strcat('/ISIN/', handles.benchmarkRawData(:,ISINColumnID))', {'SECURITY_DES', 'PX_BID', 'PX_ASK', 'MIN_PIECE', 'AMT_OUTSTANDING'}, bar, 0, nBench / nTotal), ...
    GetBBG(strcat('/ISIN/', handles.benchmarkRawData(:,ISINColumnID))', {'ISSUE_DT', 'TKT_TOTAL'}, bar, nBench / nTotal, 2 * nBench / nTotal)];
    Derivtemp=benchmarkBBGData(:,2)
    Derivtemp=cell2mat(Derivtemp)
    Derivtemp=isnan(Derivtemp)
    if sum(Derivtemp)~0
    msgbox('Check Rows in Benchmark File for Derivatives/ Data');
    BenchRowsCheck=find(Derivtemp==1)
    TempCellArray=[{'Temp'} {99.65} {100} {100} {1.0e+12} {today()-365} {1.0e+06}];
    for kkts=1:1:length(BenchRowsCheck)
    benchmarkBBGData(BenchRowsCheck(kkts),:)=TempCellArray;
    benchmarkBBGData(BenchRowsCheck(kkts),1)=handles.benchmarkRawData(BenchRowsCheck(kkts),2);
    end
    end;
    % Rebalance case
    if nPort ~= 0
        portfolioBBGData = [GetBBG(strcat('/ISIN/', handles.portfolioRawData(:,ISINColumnID))', {'SECURITY_DES', 'PX_BID', 'PX_ASK', 'MIN_PIECE', 'AMT_OUTSTANDING'}, bar, 2 * nBench / nTotal, 1 - nPort / nTotal), ...
            GetBBG(strcat('/ISIN/', handles.portfolioRawData(:,ISINColumnID))', {'ISSUE_DT', 'TKT_TOTAL'}, bar, 1 - nPort / nTotal, 1)];
    Derivtemp=portfolioBBGData(:,2);
    Derivtemp=cell2mat(Derivtemp);
    Derivtemp=isnan(Derivtemp);
    if sum(Derivtemp)~0
    msgbox('Check Rows in Portfolio File for Derivatives/ Data');
    PortRowsCheck=find(Derivtemp==1)
    TempCellArray=[{'Temp'} {100} {100} {100} {1.0e+12} {today()-365} {1.0e+06}];
    for kkts=1:1:length(PortRowsCheck)
    portfolioBBGData(PortRowsCheck(kkts),:)=TempCellArray;
    portfolioBBGData(PortRowsCheck(kkts),1)=handles.portfolioRawData(PortRowsCheck(kkts),2);
    end;
    end;    
    end
    
    % Updates table with information
    handles.benchmarkRawData(:, 1) = benchmarkBBGData(:, 1);
    handles.benchmarkRawData(:, nColumns - 6:nColumns - 1) = benchmarkBBGData(:, 2:7);
    handles.benchmarkRawData(:, nColumns - 2) = num2cell(cell2mat(benchmarkBBGData(:, 6)), 2);
    
    if nPort ~= 0
        handles.portfolioRawData(:, 1) = portfolioBBGData(:, 1);
        handles.portfolioRawData(:, nColumns - 6:nColumns - 1) = portfolioBBGData(:, 2:7);
        handles.portfolioRawData(:, nColumns - 2) = num2cell(cell2mat(portfolioBBGData(:, 6)), 2);
    end
    
    % Downloads currency info
    CurrTemp=[]
    if size(handles.portfolioRawData)~=0 
        CurrTemp=handles.portfolioRawData(:, currencyColumnID);
    end;
    usedCurrencies = unique([handles.benchmarkRawData(:, currencyColumnID); CurrTemp]);
    usedCurrencies = usedCurrencies(strcmp(usedCurrencies, 'USD') == 0);
    if isempty(usedCurrencies) == 0
        handles.currencySpotCurrencies = usedCurrencies;
        handles.currencySpotValues = cell2mat(GetBBG(strcat('USD', usedCurrencies, {' Curncy'})', {'PX_LAST'}, bar, 1, 1));
    end
     handles.currencySpotCurrencies = [handles.currencySpotCurrencies; 'USD'];
     handles.currencySpotValues = [handles.currencySpotValues; 1];     
     %usedCurrencies
     %handles.yieldBBGSymbols
     % Downloads rates info
     if isempty(usedCurrencies) == 0
         [~, index] = ismember(usedCurrencies, handles.yieldBBGSymbols(:, 1));
         if ismember(0, index)
            errordlg('One of the required rates was not found on the yieldBBGSymbols.txt file');
            error('One of the required rates was not found on the yieldBBGSymbols.txt file');
         end
         handles.yieldValues = cell2mat(GetBBG(strcat(handles.yieldBBGSymbols(index, 2), {' Curncy'})', {'PX_LAST'}, bar, 1, 1));
     end
     handles.yieldValues = [handles.yieldValues; 0];
     
    close(bar);
    
    % Shows new table
    set(handles.importedBenchmarkTable, 'Data', handles.benchmarkRawData);
    set(handles.importedPortfolioTable, 'Data', handles.portfolioRawData);
    
end

function data = GetBBG(ISINs, fields, bar, startPercentage, endPercentage)
    
    % Calculates number of securities
    nSecurities = size(ISINs, 2);
    nFields = size(fields, 2);
    nPages = floor(nSecurities / 10);
    nOut = nSecurities - (nPages * 10);
    
    % Allocates space
    data = cell(nSecurities, nFields);
    
    connection = blp;
    % For all the pages
    for page=1:nPages
        perc = startPercentage + (endPercentage - startPercentage) / nPages * page;
        waitbar(perc, bar, strcat('Downloading Bloomberg data: ', sprintf(' %.2f%%',perc * 100)));

        dataPage = getdata(connection, ISINs(1 + 10 * (page - 1):10 * page), fields);
        for column=1:nFields
            fieldName = fields(column);
            fieldName = fieldName{1};
            if iscell(dataPage.(fieldName)) == 0
                dataPage.(fieldName) = num2cell(dataPage.(fieldName));
            end
            data(1 + 10 * (page - 1):10 * page, column) = dataPage.(fieldName);
        end
    end
    
    % For the items not in the pages
    if nOut ~= 0
        dataPage = getdata(connection, ISINs(1 + 10 * nPages:nSecurities), fields);
        for column=1:nFields
            fieldName = fields(column);
            fieldName = fieldName{1};
            if iscell(dataPage.(fieldName)) == 0
                dataPage.(fieldName) = num2cell(dataPage.(fieldName));
            end
            data(1 + 10 * nPages:nSecurities, column) = dataPage.(fieldName);
        end
    end
    close(connection);
end

