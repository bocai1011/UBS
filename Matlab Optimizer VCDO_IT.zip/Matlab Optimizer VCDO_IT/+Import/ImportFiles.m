% Raw data format:
%     1      |     2...n      |   n + 1   |    n + 2  |      n + 3      |           n + 4       |      n + 5       |         n + 6        |    n + 7
% Name (BBG) | Data from file | Bid (BBG) | Ask (BBG) | Min Piece (BBG) | Amt Outstanding (BBG) | Issue Date (BBG) | Tkt Tot Amount (BBG) | FileNumber

function handles = ImportFiles(handles)

    % Clear variables and GUI
    handles = Support.ClearForm(handles, 'All');

    % Get the type of optimization
    selection = questdlg('Please select the type of optimization to be performed', 'Select optimization', 'Initial Funding', 'Subsequent Rebalance','Cancel', 'Initial Funding');

    % Case cancel is not selected
    if strcmp(selection, 'Cancel') == 0

        % Gets the number of files to be imported
        nFiles = str2double(inputdlg('Enter the number of benchmark files that will be imported', 'Number of files', 1, {'1'}));

        % Imports benchmark files
        handles.benchmarkRawData = [];
        files = cell(nFiles, 2);
        for fileID=1:nFiles
            [data, handles.allColumnNames , files(fileID, 1), handles.defaultFolder] = ImportAndFormat(['Please select the benchmark file ',int2str(fileID)], fileID, handles.defaultFolder);
            handles.benchmarkRawData = [handles.benchmarkRawData; data];
            files(fileID, 2) = {1};
        end

        % Imports portfolio files
        handles.portfolioRawData = [];
        if strcmp(selection, 'Subsequent Rebalance')
            [handles.portfolioRawData, ~, ~, handles.defaultFolder] = ImportAndFormat('Please select the portfolio file', 1, handles.defaultFolder);
            handles.portfolioRawData = handles.portfolioRawData(:,1:end-1);
        end

        % Fills data
        set(handles.importedBenchmarkTable, 'Data', handles.benchmarkRawData, 'ColumnName', handles.allColumnNames );
        set(handles.importedPortfolioTable, 'Data', handles.portfolioRawData, 'ColumnName', handles.allColumnNames (:,1:end-1));
        set(handles.weightsTable, 'Data', files);
        set(handles.filterFieldsList, 'String', [' ', handles.allColumnNames(1:end-1)], 'max',size(handles.allColumnNames , 2) - 1);
        set(handles.maturityColumnPopup, 'String', [' ', handles.allColumnNames(1:end-1)], 'Value', handles.defaultColumnIDs(1) + 1);
        set(handles.ISINColumnPopup, 'String', [' ', handles.allColumnNames(1:end-1)], 'Value', handles.defaultColumnIDs(2) + 1);
        set(handles.GIM2SymbolColumnPopup, 'String', [' ', handles.allColumnNames(1:end-1)], 'Value', handles.defaultColumnIDs(3) + 1);
        set(handles.tickerColumnPopup, 'String', [' ', handles.allColumnNames(1:end-1)], 'Value', handles.defaultColumnIDs(4) + 1);
        set(handles.yieldColumnPopup, 'String', [' ', handles.allColumnNames(1:end-1)], 'Value', handles.defaultColumnIDs(5) + 1);
        set(handles.durationColumnPopup, 'String', [' ', handles.allColumnNames(1:end-1)], 'Value', handles.defaultColumnIDs(6) + 1);
        set(handles.spreadColumnPopup, 'String', [' ', handles.allColumnNames(1:end-1)], 'Value', handles.defaultColumnIDs(7) + 1);
        set(handles.currencyColumnPopup, 'String', [' ', handles.allColumnNames(1:end-1)], 'Value', handles.defaultColumnIDs(8) + 1);
        set(handles.KRD05ColumnPopup, 'String', [' ', handles.allColumnNames(1:end-1)], 'Value', handles.defaultColumnIDs(9) + 1);
        set(handles.KRD2ColumnPopup, 'String', [' ', handles.allColumnNames(1:end-1)], 'Value', handles.defaultColumnIDs(10) + 1);
        set(handles.KRD5ColumnPopup, 'String', [' ', handles.allColumnNames(1:end-1)], 'Value', handles.defaultColumnIDs(11) + 1);
        set(handles.KRD10ColumnPopup, 'String', [' ', handles.allColumnNames(1:end-1)], 'Value', handles.defaultColumnIDs(12) + 1);
        set(handles.KRD20ColumnPopup, 'String', [' ', handles.allColumnNames(1:end-1)], 'Value', handles.defaultColumnIDs(13) + 1);
        set(handles.KRD30ColumnPopup, 'String', [' ', handles.allColumnNames(1:end-1)], 'Value', handles.defaultColumnIDs(14) + 1);
        set(handles.weightColumnPopup, 'String', [' ', handles.allColumnNames(1:end-1)], 'Value', handles.defaultColumnIDs(15) + 1);
    end
end

function [formattedData, columnNames, fileName, defaultFolder] = ImportAndFormat(title, fileIndex, defaultFolder)

    % Gets file location
    [fileName, defaultFolder] = uigetfile({'*.xls*', 'Excel Workbook'}, title, defaultFolder);

    % Reads file
    [~, ~, rawData] = xlsread(strcat(defaultFolder, fileName));

    % Erases false ends
    while isnan(rawData{size(rawData, 1), 1})
        rawData(size(rawData, 1), :) = [];
    end
    while isnan(rawData{7, size(rawData, 2)})
        rawData(:, size(rawData, 2)) = [];
    end

    % File parameters
    nRows = size(rawData, 1) - 13;
    nColumns = size(rawData, 2);
    fprintf('Number of columns in the frame is %d \n', nColumns);
    formattedData = cell(nRows, nColumns);
    %columnNames = cell(1, nColumns + 8);
    columnNames = cell(1, nColumns);
    formattedData(:) = {'N/A'};

    % Checks if the cell (13, 1) has 'HOLDINGS'
    if strcmpi(strtrim(rawData(13, 1)), 'Holdings') == 0
        errordlg('Input file is in an incorrect format');
        error('Input file is in an incorrect format');
    end

    % Fills column names
    %columnNames(:) = [{'Name (BBG)'}, rawData(7, 1:nColumns), {'Bid (BBG)', 'Ask (BBG)', 'Min Piece (BBG)', 'Amt Outstanding (BBG)', 'Issue Date (BBG)', 'Tkt Tot Amount (BBG)', 'FileNumber'}];
    columnNames(:) = [rawData(7, 2:nColumns), {'FileNumber'}];



    % Fills matrix
    fprintf('Size of formatted data is %d \n', size(formattedData,2));
    fprintf('Size of raw data is %d \n', size(rawData,2));
    formattedData(:,1:nColumns - 1) = rawData(14:nRows + 13, 2:nColumns);
    formattedData(cellfun(@(x) any(isnan(x)), formattedData)) = {'N/A'} ;
    formattedData(:, nColumns) = {fileIndex};

    % Erases the ones with empty names
    formattedData(:, strcmp(strtrim(columnNames), '')) = [];
    columnNames(:, strcmp(strtrim(columnNames), '')) = [];

    fileName = cellstr(fileName);

end
