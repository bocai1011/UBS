function formattedTable = FormatTable(numericTable)

    formattedTable = cell(size(numericTable, 1), size(numericTable, 2));
    
    if size(numericTable, 1) ~= 0
        formattedTable(:, 1) = strread(sprintf(' %.2f%%', numericTable(:, 1) * 100), '%s', 'delimiter', ' ');
        formattedTable(:, 2) = strread(sprintf(' %.2f%%', numericTable(:, 2) * 100), '%s', 'delimiter', ' ');
        formattedTable(:, 3) = cellstr(datestr(numericTable(:, 3), 'mm/dd/yyyy'));
        formattedTable(:, 4) = arrayfun(@(x) Support.separatethousands(x, ',', 0), numericTable(:, 4), 'UniformOutput', 0);
        formattedTable(:, 5) = strread(sprintf(' %.2f%%', numericTable(:, 5) * 100), '%s', 'delimiter', ' ');
        formattedTable(:, 6) = strread(sprintf(' %.2f', numericTable(:, 6)), '%s', 'delimiter', ' ');
        formattedTable(:, 7) = arrayfun(@(x) Support.separatethousands(x, ',', 2), numericTable(:, 7), 'UniformOutput', 0);
        formattedTable(:, 8) = strread(sprintf(' %.2f', numericTable(:, 8)), '%s', 'delimiter', ' ');
        formattedTable(:, 9) = strread(sprintf(' %.2f', numericTable(:, 9)), '%s', 'delimiter', ' ');
        formattedTable(:, 10) = strread(sprintf(' %.2f', numericTable(:, 10)), '%s', 'delimiter', ' ');
        formattedTable(:, 11) = strread(sprintf(' %.2f', numericTable(:, 11)), '%s', 'delimiter', ' ');
        formattedTable(:, 12) = strread(sprintf(' %.2f', numericTable(:, 12)), '%s', 'delimiter', ' ');
        formattedTable(:, 13) = arrayfun(@(x) Support.separatethousands(x, ',', 2), numericTable(:, 13), 'UniformOutput', 0);
        formattedTable(:, 14) = arrayfun(@(x) Support.separatethousands(x, ',', 2), numericTable(:, 14), 'UniformOutput', 0);
        formattedTable(:, 15) = arrayfun(@(x) Support.separatethousands(x, ',', 0), numericTable(:, 15), 'UniformOutput', 0);
        formattedTable(:, 16) = arrayfun(@(x) Support.separatethousands(x, ',', 0), numericTable(:, 16), 'UniformOutput', 0);
        formattedTable(:, 17) = cellstr(datestr(numericTable(:, 17), 'mm/dd/yyyy'));
        formattedTable(:, 18) = arrayfun(@(x) Support.separatethousands(x, ',', 2), numericTable(:, 18), 'UniformOutput', 0);
    end
end