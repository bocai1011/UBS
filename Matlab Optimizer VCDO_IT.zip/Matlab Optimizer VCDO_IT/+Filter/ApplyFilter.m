function handles = ApplyFilter(handles)

    sort1 = get(handles.sortByPopup1,'Value') - 1;
    sort2 = get(handles.sortByPopup2,'Value') - 1; 
    sort3 = get(handles.sortByPopup3,'Value') - 1; 
    
    filter1 = get(handles.filterPopup1,'Value') - 1;
    filter2 = get(handles.filterPopup2,'Value') - 1; 
    equalsValue1 = get(handles.filterEqualsList1, 'Value');
    equalsNames1 = get(handles.filterEqualsList1, 'String');
    equalsValue2 = get(handles.filterEqualsList2, 'Value');
    equalsNames2 = get(handles.filterEqualsList2, 'String');
    handles.filteredStringTable = handles.unifiedStringTable;
    handles.filteredNumericTable = handles.unifiedNumericTable;
    
	if filter2 ~= 0
        equalsChoice1 = equalsNames1(equalsValue1);
        equalsChoice2 = equalsNames2(equalsValue2);
        handles.filteredStringTable = [];
        handles.filteredNumericTable = [];
        filteredStringTableTemp = [];
        filteredNumericTableTemp = [];
        for choice = 1:size(equalsChoice1, 1)
            selectedIndex = strcmp(handles.unifiedStringTable(:, filter1 + 3), equalsChoice1(choice));
            filteredStringTableTemp = [filteredStringTableTemp; handles.unifiedStringTable(selectedIndex, :)];
            filteredNumericTableTemp = [filteredNumericTableTemp; handles.unifiedNumericTable(selectedIndex, :)];
        end
        for choice = 1:size(equalsChoice2, 1)
            selectedIndex = strcmp(filteredStringTableTemp(:, filter2 + 3), equalsChoice2(choice));
            handles.filteredStringTable = [handles.filteredStringTable; filteredStringTableTemp(selectedIndex, :)];
            handles.filteredNumericTable = [handles.filteredNumericTable; filteredNumericTableTemp(selectedIndex, :)];
        end
	elseif filter1 ~= 0
        handles.filteredStringTable = [];
        handles.filteredNumericTable = [];
        equalsChoice1 = equalsNames1(equalsValue1);
        for choice = 1:size(equalsChoice1, 1)
            selectedIndex = strcmp(handles.unifiedStringTable(:, filter1 + 3), equalsChoice1(choice));
            handles.filteredStringTable = [handles.filteredStringTable; handles.unifiedStringTable(selectedIndex, :)];
            handles.filteredNumericTable = [handles.filteredNumericTable; handles.unifiedNumericTable(selectedIndex, :)];
        end
	end
    
    if (sort3 ~= 0 || sort2 ~= 0 || sort1 ~= 0) && (size(handles.filteredStringTable, 1) ~= 0)
        if sort3 ~= 0
            [~, index] = sortrows([handles.filteredStringTable, num2cell(handles.filteredNumericTable)], [sort1, sort2, sort3]);
        elseif sort2 ~= 0
            [~, index] = sortrows([handles.filteredStringTable, num2cell(handles.filteredNumericTable)], [sort1, sort2]);
        elseif sort1 ~= 0
            [~, index] = sortrows([handles.filteredStringTable, num2cell(handles.filteredNumericTable)], sort1);
        end
        handles.filteredStringTable = handles.filteredStringTable(index, :);
        handles.filteredNumericTable = handles.filteredNumericTable(index, :);
    end
    
    set(handles.selectedFieldsTable, 'Data', [handles.filteredStringTable, Filter.FormatTable(handles.filteredNumericTable)]);
    
    % Reorder to be saved
    [~, index] = sortrows(handles.filteredStringTable, 1);
    handles.filteredStringTable = handles.filteredStringTable(index, :);
    handles.filteredNumericTable = handles.filteredNumericTable(index, :);
    
end